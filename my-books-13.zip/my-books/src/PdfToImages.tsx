import { useEffect, useMemo, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { FileRec, getBlob } from './db';
import { NeedPassword, openPdf, PDFDoc, fmtSize } from './pdf';
import { Cancelled, ImgOpts, OutFile, parseRange, pdfToImages, zipFiles } from './convert';
import { saveImagesToGallery, saveToDevice } from './storage';
import { useBack } from './back';
import { t } from './i18n';
import { Dialog, Icon, MiniSpin, PressButton, Segmented, Sheet, Working } from './ui';

function PageCell({ doc, n, ratio, on, onToggle, root }: { doc: PDFDoc; n: number; ratio: number; on: boolean; onToggle: () => void; root: RefObject<HTMLElement> }) {
  const wrap = useRef<HTMLButtonElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const [vis, setVis] = useState(false);

  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVis(e.isIntersecting), { root: root.current, rootMargin: '100% 0px' });
    io.observe(el);
    return () => io.disconnect();
  }, [root]);

  useEffect(() => {
    const c = cv.current;
    if (!c) return;
    if (!vis) {
      c.width = 0;
      c.height = 0;
      return;
    }
    let dead = false;
    let task: any = null;
    (async () => {
      try {
        const page = await doc.getPage(n);
        if (dead) return;
        const v0 = page.getViewport({ scale: 1 });
        const vp = page.getViewport({ scale: 200 / v0.width });
        const off = document.createElement('canvas');
        off.width = Math.floor(vp.width);
        off.height = Math.floor(vp.height);
        const ctx = off.getContext('2d')!;
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, off.width, off.height);
        task = page.render({ canvasContext: ctx, viewport: vp });
        await task.promise;
        if (dead) return;
        c.width = off.width;
        c.height = off.height;
        c.getContext('2d')!.drawImage(off, 0, 0);
        off.width = 0;
        page.cleanup();
      } catch {
        /* cancelled or failed: leave the cell blank */
      }
    })();
    return () => {
      dead = true;
      try {
        task?.cancel();
      } catch {
        /* ignore */
      }
    };
  }, [vis, doc, n]);

  return (
    <button ref={wrap} className={'pcell' + (on ? ' on' : '')} style={{ aspectRatio: `1 / ${ratio}` }} onClick={onToggle} aria-pressed={on} aria-label={`Page ${n}`}>
      <canvas ref={cv} />
      <span className="pnum">{n}</span>
      <div className={'chk' + (on ? ' on' : '')}>{on && <Icon n="check" size={14} sw={3} />}</div>
    </button>
  );
}

export default function PdfToImages({ file, onClose, say }: { file: FileRec; onClose: () => void; say: (m: string) => void }) {
  const [doc, setDoc] = useState<PDFDoc | null>(null);
  const [dims, setDims] = useState({ w: 595, h: 842 });
  const [fail, setFail] = useState(false);
  const [pw, setPw] = useState<null | { id: number; wrong: boolean; resolve: (v: string | null) => void }>(null);
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [range, setRange] = useState('');
  const [fromP, setFromP] = useState('');
  const [toP, setToP] = useState('');
  const [firstErr, setFirstErr] = useState('');
  const [optsOpen, setOptsOpen] = useState(false);
  const [opts, setOpts] = useState<ImgOpts>({ format: 'png', dpi: 150 });
  const [phase, setPhase] = useState<'pick' | 'working' | 'done'>('pick');
  const [prog, setProg] = useState(0);
  const [count, setCount] = useState(0);
  const [result, setResult] = useState<{ files: OutFile[]; bytes: number; count: number } | null>(null);
  const [saving, setSaving] = useState<null | 'gallery' | 'zip' | 'file'>(null);
  const [saveProg, setSaveProg] = useState(0);
  const scroller = useRef<HTMLElement>(null);
  const cancel = useRef(false);
  const total = doc?.numPages ?? 0;
  const base = file.name.replace(/\.pdf$/i, '');

  useBack(true, () => {
    if (phase === 'working') cancel.current = true;
    else onClose();
  });

  useEffect(() => {
    let dead = false;
    let d: PDFDoc | null = null;
    (async () => {
      try {
        const blob = await getBlob(file.id);
        if (!blob) throw new Error('missing');
        d = await openPdf(blob, (wrong) => new Promise((res) => setPw({ id: Date.now(), wrong, resolve: res })));
        if (dead) {
          d.destroy();
          return;
        }
        const p = await d.getPage(1);
        const v = p.getViewport({ scale: 1 });
        p.cleanup();
        setDims({ w: v.width, h: v.height });
        setDoc(d);
      } catch (e) {
        if (dead) return;
        if (e instanceof NeedPassword) onClose();
        else setFail(true);
      }
    })();
    return () => {
      dead = true;
      d?.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file.id]);

  const rangeErr = useMemo(() => (doc ? parseRange(range, total).error : ''), [range, total, doc]);
  const all = () => Array.from({ length: total }, (_, i) => i + 1);
  const setManual = (s: Set<number>) => {
    setSel(s);
    setRange('');
    setFromP('');
    setToP('');
    setFirstErr('');
  };
  const onRange = (text: string) => {
    setRange(text);
    setFromP('');
    setToP('');
    setFirstErr('');
    const r = parseRange(text, total);
    if (!r.error && text.trim()) setSel(new Set(r.pages));
  };
  // "From page X to page Y": selects X..Y. The images are always made (and saved) from the first page to the last.
  const checkFromTo = (a: string, b: string): { ok: boolean; from: number; to: number; err: string } => {
    const from = parseInt(a, 10);
    const to = parseInt(b, 10);
    const bad = (n: number) => !Number.isInteger(n) || n < 1 || n > total;
    if (bad(from) || bad(to)) return { ok: false, from, to, err: t('numberRange', { total }) };
    if (from > to) return { ok: false, from, to, err: t('fromAfterTo') };
    return { ok: true, from, to, err: '' };
  };
  const applyFromTo = (a: string, b: string) => {
    const r = checkFromTo(a, b);
    setRange('');
    if (r.ok) {
      setSel(new Set(Array.from({ length: r.to - r.from + 1 }, (_, i) => r.from + i)));
      setFirstErr('');
    } else {
      setSel(new Set()); // never convert a stale selection while the two numbers are wrong
      setFirstErr(r.err);
    }
  };
  // Western digits only (Arabic-Indic digits typed on an Arabic keyboard are converted).
  const digits = (v: string) =>
    v
      .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
      .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
      .replace(/\D/g, '')
      .slice(0, 5);
  const onFrom = (v: string) => {
    const x = digits(v);
    setFromP(x);
    setFirstErr('');
    if (x && toP) applyFromTo(x, toP);
  };
  const onTo = (v: string) => {
    const x = digits(v);
    setToP(x);
    setFirstErr('');
    if (fromP && x) applyFromTo(fromP, x);
  };
  const selectFromTo = () => {
    if (!fromP && !toP) return setFirstErr(t('numberRange', { total }));
    const a = fromP || '1'; // only "to" filled: start from page 1
    const b = toP || String(total); // only "from" filled: go to the last page
    setFromP(a);
    setToP(b);
    applyFromTo(a, b);
  };
  const toggle = (n: number) => {
    const s = new Set(sel);
    s.has(n) ? s.delete(n) : s.add(n);
    setManual(s);
  };

  const pxPerPage = ((dims.w * opts.dpi) / 72) * ((dims.h * opts.dpi) / 72);
  const heavy = sel.size * pxPerPage > 150_000_000;

  const run = async () => {
    if (!doc || !sel.size) return;
    const pages = [...sel].sort((a, b) => a - b);
    setOptsOpen(false);
    setCount(pages.length);
    setProg(0);
    cancel.current = false;
    setPhase('working');
    await new Promise<void>((r2) => requestAnimationFrame(() => setTimeout(r2, 60)));
    try {
      const files = await pdfToImages(doc, pages, base, opts, setProg, () => cancel.current);
      setResult({ files, count: files.length, bytes: files.reduce((sum, f) => sum + f.blob.size, 0) });
      setPhase('done');
    } catch (e) {
      say(e instanceof Cancelled ? t('cancelled') : t('convFail'));
      setPhase('pick');
    }
  };

  // 1) normal image files, straight into the gallery
  const saveGallery = async () => {
    if (!result || saving) return;
    setSaving('gallery');
    setSaveProg(0);
    try {
      const r = await saveImagesToGallery(result.files, setSaveProg);
      say(r.mode === 'gallery' ? t('savedGallery', { n: result.count }) : r.mode === 'shared' ? t('chooseSave') : t('downloadStarted'));
    } catch {
      say(t('saveFail'));
    } finally {
      setSaving(null);
    }
  };

  // 2) one ZIP (only when the user asks for it), or 3) the single image as a file
  const saveAsFile = async (kind: 'zip' | 'file') => {
    if (!result || saving) return;
    setSaving(kind);
    const guard = setTimeout(() => setSaving(null), 20000);
    try {
      const blob = kind === 'zip' ? await zipFiles(result.files) : result.files[0].blob;
      const name = kind === 'zip' ? `${base}-images.zip` : result.files[0].name;
      const r = await saveToDevice(name, blob);
      say(r.mode === 'saved' ? t('savedTo', { path: r.path }) : r.mode === 'shared' ? t('chooseSave') : t('downloadStarted'));
    } catch {
      say(t('saveFail'));
    } finally {
      clearTimeout(guard);
      setSaving(null);
    }
  };

  return (
    <>
      <header className="hdr">
        <PressButton className="ib" aria-label="Back" onClick={onClose}><Icon n="back" /></PressButton>
        <div className="title small">{t('pdfToImages')}</div>
        <div className="ib" />
      </header>

      {!doc && !fail && !pw && <div className="pane"><div className="empty"><div className="spin" /></div></div>}
      {fail && (
        <div className="pane"><div className="empty"><h3>{t('fileOpenFail')}</h3><PressButton className="dbtn primary" style={{ marginTop: 16 }} onClick={onClose}>{t('back')}</PressButton></div></div>
      )}

      {doc && (
        <>
          <main className="pane" ref={scroller}>
            <div className="chips">
              <PressButton className="chip" onClick={() => setManual(new Set(all()))}>{t('all')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set())}>{t('selNone')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set(all().filter((n) => !sel.has(n))))}>{t('invert')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set(all().filter((n) => n % 2 === 1)))}>{t('odd')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set(all().filter((n) => n % 2 === 0)))}>{t('even')}</PressButton>
            </div>
            <div className="field">
              <input className="dinput" inputMode="text" placeholder={t('pagesPlaceholder')} dir="ltr" value={range} onChange={(e) => onRange(e.target.value)} />
            </div>
            {rangeErr && <div className="ferr">{rangeErr}</div>}
            <div className="field">
              <input className="dinput num" inputMode="numeric" placeholder={t('fromPage')} dir="ltr" value={fromP} onChange={(e) => onFrom(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && selectFromTo()} />
              <input className="dinput num" inputMode="numeric" placeholder={t('toPage')} dir="ltr" value={toP} onChange={(e) => onTo(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && selectFromTo()} />
              <PressButton className="dbtn" onClick={selectFromTo}>{t('select')}</PressButton>
            </div>
            {firstErr && <div className="ferr">{firstErr}</div>}
            <div className="fcount">{t('nOfTotalSelected', { n: sel.size, total })}</div>
            <div className="pgrid">
              {Array.from({ length: total }, (_, i) => (
                <PageCell key={i} doc={doc} n={i + 1} ratio={dims.h / dims.w} on={sel.has(i + 1)} onToggle={() => toggle(i + 1)} root={scroller} />
              ))}
            </div>
          </main>
          <div className="actbar">
            <div className="grow">{t('nPages', { n: sel.size })}</div>
            <PressButton className="dbtn primary" disabled={!sel.size} onClick={() => setOptsOpen(true)}>{t('convert')}</PressButton>
          </div>
        </>
      )}

      {phase === 'pick' && (
      <AnimatePresence>
        {optsOpen && (
          <Sheet key="opts" title={t('exportOptions')} onClose={() => setOptsOpen(false)}>
            <div className="flabel">{t('format')}</div>
            <Segmented value={opts.format} onChange={(v) => setOpts({ ...opts, format: v })} options={[{ v: 'png', label: 'PNG' }, { v: 'jpg', label: 'JPG' }]} />
            <div className="flabel">{t('quality')}</div>
            <Segmented value={opts.dpi} onChange={(v) => setOpts({ ...opts, dpi: v })} options={[{ v: 72, label: t('dpiLow') }, { v: 150, label: t('dpiHigh') }, { v: 300, label: t('dpiVeryHigh') }]} />
            {heavy && <div className="warn">{t('heavyWarn', { n: sel.size })}</div>}
            <p className="hint" style={{ paddingInlineStart: 4 }}>{sel.size === 1 ? t('onePageHint') : t('severalHint')}</p>
            <PressButton className="dbtn primary wide" onClick={run}>{t('convertN', { n: sel.size })}</PressButton>
          </Sheet>
        )}
      </AnimatePresence>
      )}

      <AnimatePresence>
        {pw && (
          <Dialog
            key={'pw' + pw.id}
            spec={{
              title: pw.wrong ? t('wrongPassword') : t('passwordRequired'),
              message: pw.wrong ? t('tryAgain') : t('pdfProtected'),
              input: { type: 'password', placeholder: t('password') },
              ok: t('open'),
              onOk: (v) => {
                if (!v) return t('enterPassword');
                pw.resolve(v);
                setPw(null);
              },
              onCancel: () => {
                pw.resolve(null);
                setPw(null);
              },
            }}
            onClose={() => {}}
          />
        )}
      </AnimatePresence>

      {phase === 'working' && (
        <div className="veil">
          <div className="wcard">
            <Working icon="image" title={t('converting')} label={t('pageXofY', { x: Math.min(prog + 1, count), y: count })} value={count ? prog / count : 0} />
            <PressButton className="dbtn wide" onClick={() => (cancel.current = true)}>{t('cancel')}</PressButton>
          </div>
        </div>
      )}

      {phase === 'done' && result && (
        <div className="veil">
          <motion.div className="wcard" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: 'spring', stiffness: 380, damping: 30 }}>
            <div className="okico"><Icon n="check" size={30} sw={3} /></div>
            <div className="dtitle">{result.count === 1 ? t('imageReady') : t('imagesReady', { n: result.count })}</div>
            <p className="dmsg">{t('nImages', { n: result.count })} · {fmtSize(result.bytes)}</p>
            <PressButton className="dbtn primary wide" disabled={!!saving} onClick={saveGallery}>{t('saveGallery')}</PressButton>
            <PressButton className="dbtn wide" disabled={!!saving} onClick={() => saveAsFile(result.count > 1 ? 'zip' : 'file')}>
              {saving === 'zip' || saving === 'file' ? <><MiniSpin />{t('saving')}</> : result.count > 1 ? t('saveZip') : t('saveFile')}
            </PressButton>
            <PressButton className="dbtn wide" onClick={() => setPhase('pick')}>{t('convertMore')}</PressButton>
            <PressButton className="dbtn wide" onClick={onClose}>{t('done')}</PressButton>
          </motion.div>
        </div>
      )}

      {saving === 'gallery' && result && (
        <div className="veil">
          <div className="wcard">
            <Working icon="image" title={t('savingGallery')} label={t('imageXofY', { x: Math.min(saveProg + 1, result.count), y: result.count })} value={result.count ? saveProg / result.count : 0} />
          </div>
        </div>
      )}
    </>
  );
}
