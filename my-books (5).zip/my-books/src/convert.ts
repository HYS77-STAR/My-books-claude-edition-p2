import { EncryptedPDFError, PDFArray, PDFDict, PDFDocument, PDFName } from 'pdf-lib';
import JSZip from 'jszip';
import type { PDFDoc } from './pdf';
import { t } from './i18n';

export class Cancelled extends Error {}
const tick = () => new Promise<void>((r) => setTimeout(r, 0));
const toBlob = (c: HTMLCanvasElement, type: string, q?: number) => new Promise<Blob | null>((res) => c.toBlob((b) => res(b), type, q));

// ---------------------------------------------------------------- images -> PDF
export interface ImgItem { id: string; file: File; thumb: string; rot: number }
export interface PdfOpts { size: 'a4' | 'original'; margin: 0 | 18 | 36; quality: 'high' | 'medium' | 'low' }
const Q = { high: { q: 0.92, side: 2500 }, medium: { q: 0.8, side: 2000 }, low: { q: 0.6, side: 1500 } };

interface Bmp { src: CanvasImageSource; w: number; h: number; close: () => void }

/** Decodes an image and applies its EXIF orientation. Throws for unsupported formats. */
export async function decodeImage(file: File): Promise<Bmp> {
  try {
    const b = await createImageBitmap(file, { imageOrientation: 'from-image' } as ImageBitmapOptions);
    return { src: b, w: b.width, h: b.height, close: () => b.close() };
  } catch {
    const url = URL.createObjectURL(file);
    try {
      const img = new Image();
      img.src = url;
      await img.decode();
      return { src: img, w: img.naturalWidth, h: img.naturalHeight, close: () => {} };
    } finally {
      URL.revokeObjectURL(url);
    }
  }
}

export async function imageThumb(file: File): Promise<string> {
  const b = await decodeImage(file);
  const k = Math.min(1, 220 / Math.max(b.w, b.h));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(b.w * k));
  c.height = Math.max(1, Math.round(b.h * k));
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(b.src, 0, 0, c.width, c.height);
  b.close();
  const blob = await toBlob(c, 'image/jpeg', 0.7);
  c.width = 0;
  if (!blob) throw new Error('thumb');
  return URL.createObjectURL(blob);
}

function rasterize(b: Bmp, rot: number, maxSide: number) {
  const swap = rot % 180 !== 0;
  const w0 = swap ? b.h : b.w;
  const h0 = swap ? b.w : b.h;
  const k = Math.min(1, maxSide / Math.max(w0, h0)); // big photos are downscaled to save memory
  const w = Math.max(1, Math.round(w0 * k));
  const h = Math.max(1, Math.round(h0 * k));
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate((rot * Math.PI) / 180);
  ctx.drawImage(b.src, (-b.w * k) / 2, (-b.h * k) / 2, b.w * k, b.h * k);
  ctx.restore();
  return c;
}

export async function imagesToPdf(items: ImgItem[], o: PdfOpts, onProgress: (done: number) => void, cancelled: () => boolean): Promise<Blob> {
  const pdf = await PDFDocument.create();
  const { q, side } = Q[o.quality];
  const m = o.margin;
  for (let i = 0; i < items.length; i++) {
    if (cancelled()) throw new Cancelled();
    onProgress(i);
    await tick();
    const b = await decodeImage(items[i].file); // one image in memory at a time
    const c = rasterize(b, items[i].rot, side);
    b.close();
    const iw = c.width;
    const ih = c.height;
    const blob = await toBlob(c, 'image/jpeg', q);
    c.width = 0;
    if (!blob) throw new Error('encode');
    const img = await pdf.embedJpg(new Uint8Array(await blob.arrayBuffer()));
    let pw: number, ph: number, dw: number, dh: number, x: number, y: number;
    if (o.size === 'a4') {
      const land = iw > ih;
      pw = land ? 841.89 : 595.28;
      ph = land ? 595.28 : 841.89;
      const k = Math.min((pw - 2 * m) / iw, (ph - 2 * m) / ih);
      dw = iw * k;
      dh = ih * k;
      x = (pw - dw) / 2;
      y = (ph - dh) / 2;
    } else {
      dw = iw * 0.75;
      dh = ih * 0.75;
      pw = dw + 2 * m;
      ph = dh + 2 * m;
      x = m;
      y = m;
    }
    pdf.addPage([pw, ph]).drawImage(img, { x, y, width: dw, height: dh });
  }
  onProgress(items.length);
  const bytes = await pdf.save();
  return new Blob([bytes as unknown as BlobPart], { type: 'application/pdf' });
}

// ---------------------------------------------------------------- PDF -> images
export interface ImgOpts { format: 'png' | 'jpg'; dpi: 72 | 150 | 300 }
// The three quality levels shown to the user (low / high / very high) map to these resolutions.
const jpgQuality = (dpi: number) => (dpi <= 72 ? 0.8 : dpi <= 150 ? 0.9 : 0.95);
const MAX_PX = 25_000_000; // per-page canvas cap so phones don't run out of memory
export interface OutFile { name: string; blob: Blob }

/** Parses "1-5, 8, 10-12" (Arabic digits allowed) into sorted page numbers. */
export function parseRange(text: string, total: number): { pages: number[]; error: string } {
  const src = text
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .trim();
  if (!src) return { pages: [], error: '' };
  const set = new Set<number>();
  for (const part of src.split(/[,،;\s]+/).filter(Boolean)) {
    const m = part.match(/^(\d+)(?:[-–](\d+))?$/);
    if (!m) return { pages: [], error: t('rangeBad', { part }) };
    const a = +m[1];
    const b = m[2] ? +m[2] : a;
    if (a < 1 || b < 1 || a > total || b > total) return { pages: [], error: t('rangeBounds', { total }) };
    if (a > b) return { pages: [], error: t('rangeBack', { part, rev: `${b}-${a}` }) };
    for (let p = a; p <= b; p++) set.add(p);
  }
  return { pages: [...set].sort((x, y) => x - y), error: '' };
}

export async function pdfToImages(doc: PDFDoc, pages: number[], base: string, o: ImgOpts, onProgress: (done: number) => void, cancelled: () => boolean): Promise<OutFile[]> {
  const ext = o.format === 'png' ? 'png' : 'jpg';
  const mime = o.format === 'png' ? 'image/png' : 'image/jpeg';
  const files: OutFile[] = [];
  const pad = String(doc.numPages).length;
  for (let i = 0; i < pages.length; i++) {
    if (cancelled()) throw new Cancelled();
    onProgress(i);
    await tick();
    const page = await doc.getPage(pages[i]);
    const v0 = page.getViewport({ scale: 1 });
    let scale = o.dpi / 72;
    const px = v0.width * scale * v0.height * scale;
    if (px > MAX_PX) scale *= Math.sqrt(MAX_PX / px);
    const vp = page.getViewport({ scale });
    const c = document.createElement('canvas');
    c.width = Math.floor(vp.width);
    c.height = Math.floor(vp.height);
    const ctx = c.getContext('2d');
    if (!ctx) throw new Error('canvas');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    page.cleanup();
    const blob = await toBlob(c, mime, o.format === 'jpg' ? jpgQuality(o.dpi) : undefined);
    c.width = 0; // free memory right after each page
    if (!blob) throw new Error('encode');
    files.push({ name: `${base}-page-${String(pages[i]).padStart(pad, '0')}.${ext}`, blob });
  }
  onProgress(pages.length);
  return files;
}

/** Packs images into one ZIP, only when the user asks for it. */
export async function zipFiles(files: OutFile[]): Promise<Blob> {
  const zip = new JSZip();
  files.forEach((f) => zip.file(f.name, f.blob));
  return zip.generateAsync({ type: 'blob', compression: 'STORE' });
}

// ---------------------------------------------------------------- merge PDFs
export interface MergeSrc { id: string; name: string; load: () => Promise<Blob | null> }
/** `why`: read = the stored copy is missing, parse = damaged / not supported, protected = password-protected. */
export class MergeError extends Error {
  constructor(public fileName: string, public why: 'read' | 'parse' | 'protected') {
    super(why);
  }
}

/** True if the file declares encryption (in the trailer at the end of the file, or in the first-page trailer of a linearized one). */
async function looksEncrypted(blob: Blob): Promise<boolean> {
  try {
    const dec = new TextDecoder('latin1');
    const tail = dec.decode(await blob.slice(Math.max(0, blob.size - 16384)).arrayBuffer());
    if (tail.includes('/Encrypt')) return true;
    return dec.decode(await blob.slice(0, 16384).arrayBuffer()).includes('/Encrypt');
  } catch {
    return false;
  }
}

/**
 * Links that jump to another page of the SAME file would break once the file is merged, and pdf-lib would drag the pages they
 * point to along as hidden copies (making the result much bigger). So those links are dropped; web links and other kinds stay.
 */
function dropInternalLinks(doc: PDFDocument) {
  const SUBTYPE = PDFName.of('Subtype');
  const LINK = PDFName.of('Link');
  const DEST = PDFName.of('Dest');
  const ACTION = PDFName.of('A');
  const S = PDFName.of('S');
  const GOTO = PDFName.of('GoTo');
  for (const page of doc.getPages()) {
    try {
      const annots = page.node.lookupMaybe(PDFName.of('Annots'), PDFArray);
      if (!annots) continue;
      for (let i = annots.size() - 1; i >= 0; i--) {
        const a = annots.lookupMaybe(i, PDFDict);
        if (!a || a.lookup(SUBTYPE) !== LINK) continue;
        const act = a.lookupMaybe(ACTION, PDFDict);
        if (a.has(DEST) || (act && act.lookup(S) === GOTO)) annots.remove(i);
      }
    } catch {
      /* best effort: a page we cannot inspect is simply copied as it is */
    }
  }
}

/** Joins the PDFs, in the given order, into one new PDF. `onProgress(filesDone, pagesDone)` is called before each file and at the end. */
export async function mergePdfs(srcs: MergeSrc[], title: string, onProgress: (files: number, pages: number) => void, cancelled: () => boolean): Promise<Blob> {
  const out = await PDFDocument.create();
  let pages = 0;
  for (let i = 0; i < srcs.length; i++) {
    if (cancelled()) throw new Cancelled();
    onProgress(i, pages);
    await tick();
    const s = srcs[i];
    const blob = await s.load();
    if (!blob) throw new MergeError(s.name, 'read');
    let doc: PDFDocument;
    try {
      doc = await PDFDocument.load(new Uint8Array(await blob.arrayBuffer()), { updateMetadata: false, throwOnInvalidObject: false });
    } catch (e) {
      // pdf-lib cannot read encrypted files (not even ones that open without a password, such as copy/print-restricted books).
      throw new MergeError(s.name, e instanceof EncryptedPDFError || (await looksEncrypted(blob)) ? 'protected' : 'parse');
    }
    dropInternalLinks(doc);
    // All the pages of one file are copied in ONE call, so fonts and images they share are stored only once.
    let copied;
    try {
      copied = await out.copyPages(doc, doc.getPageIndices());
    } catch {
      throw new MergeError(s.name, 'parse');
    }
    copied.forEach((p) => out.addPage(p));
    pages += copied.length;
    await tick();
  }
  if (!pages) throw new Error('empty');
  if (cancelled()) throw new Cancelled();
  onProgress(srcs.length, pages);
  await tick();
  const now = new Date();
  out.setTitle(title);
  out.setProducer('MY BOOKS');
  out.setCreator('MY BOOKS');
  out.setCreationDate(now);
  out.setModificationDate(now);
  const bytes = await out.save();
  return new Blob([bytes as unknown as BlobPart], { type: 'application/pdf' });
}
