import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const CHUNK = 768 * 1024; // multiple of 3 so base64 chunks concatenate cleanly; small = light bridge messages

const toB64 = (b: Blob) =>
  new Promise<string>((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1] || '');
    r.onerror = () => rej(r.error);
    r.readAsDataURL(b);
  });

const safeName = (n: string) => n.replace(/[\\/:*?"<>|]+/g, '_').trim() || 'file';

async function writeChunked(path: string, blob: Blob, directory: Directory) {
  let uri = '';
  for (let o = 0; o === 0 || o < blob.size; o += CHUNK) {
    const data = await toB64(blob.slice(o, o + CHUNK));
    if (o > 0) await new Promise<void>((r) => setTimeout(r, 0)); // keep the UI responsive
    if (o === 0) {
      const r = await Filesystem.writeFile({ path, data, directory, recursive: true });
      uri = r.uri;
    } else {
      await Filesystem.appendFile({ path, data, directory });
    }
  }
  return uri;
}

export type SaveResult = { mode: 'saved' | 'shared' | 'download'; path: string };

/** Copies a file (PDF, image or ZIP) out of the app into the device's files. `name` must include its extension. */
export async function saveToDevice(name: string, blob: Blob): Promise<SaveResult> {
  const fname = safeName(name);
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return { mode: 'download', path: fname };
  }
  try {
    await writeChunked(`MyBooks/${fname}`, blob, Directory.Documents);
    return { mode: 'saved', path: `Documents/MyBooks/${fname}` };
  } catch {
    // Some Android versions block direct writes to Documents: fall back to the share sheet.
    const uri = await writeChunked(fname, blob, Directory.Cache);
    await Share.share({ title: fname, url: uri, dialogTitle: 'Save file' });
    return { mode: 'shared', path: fname };
  }
}
