import { useEffect, useMemo, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { FileRec, getBlob } from './db';
import { NeedPassword, openPdf, PDFDoc, fmtSize } from './pdf';
import { Cancelled, ImgOpts, parseRange, pdfToImages } from './convert';
import { saveToDevice } from './storage';
import { useBack } from './back';
import { t } from './i18n';
import { Dialog, Icon, PressButton, Segmented, Sheet } from './ui';

function PageCell({ doc, n, ratio, on, onToggle, root }: { doc: PDFDoc; n: number; ratio: number; on: boolean; onToggle: () => void; root: RefObject<HTMLElement> }) {
  const wrap = useRef<HTMLButtonElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const [vis, setVis] = useState(false);

  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVis(e.isIntersecting), { root: root.current, rootMargin: '100% 0px' });
    io.observe(el);
    return () => io.disconnect();
  }, [root]);

  useEffect(() => {
    const c = cv.current;
    if (!c) return;
    if (!vis) {
      c.width = 0;
      c.height = 0;
      return;
    }
    let dead = false;
    let task: any = null;
    (async () => {
      try {
        const page = await doc.getPage(n);
        if (dead) return;
        const v0 = page.getViewport({ scale: 1 });
        const vp = page.getViewport({ scale: 200 / v0.width });
        const off = document.createElement('canvas');
        off.width = Math.floor(vp.width);
        off.height = Math.floor(vp.height);
        const ctx = off.getContext('2d')!;
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, off.width, off.height);
        task = page.render({ canvasContext: ctx, viewport: vp });
        await task.promise;
        if (dead) return;
        c.width = off.width;
        c.height = off.height;
        c.getContext('2d')!.drawImage(off, 0, 0);
        off.width = 0;
        page.cleanup();
      } catch {
        /* cancelled or failed: leave the cell blank */
      }
    })();
    return () => {
      dead = true;
      try {
        task?.cancel();
      } catch {
        /* ignore */
      }
    };
  }, [vis, doc, n]);

  return (
    <button ref={wrap} className={'pcell' + (on ? ' on' : '')} style={{ aspectRatio: `1 / ${ratio}` }} onClick={onToggle} aria-pressed={on} aria-label={`Page ${n}`}>
      <canvas ref={cv} />
      <span className="pnum">{n}</span>
      <div className={'chk' + (on ? ' on' : '')}>{on && <Icon n="check" size={14} sw={3} />}</div>
    </button>
  );
}

export default function PdfToImages({ file, onClose, say }: { file: FileRec; onClose: () => void; say: (m: string) => void }) {
  const [doc, setDoc] = useState<PDFDoc | null>(null);
  const [dims, setDims] = useState({ w: 595, h: 842 });
  const [fail, setFail] = useState(false);
  const [pw, setPw] = useState<null | { id: number; wrong: boolean; resolve: (v: string | null) => void }>(null);
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [range, setRange] = useState('');
  const [firstN, setFirstN] = useState('');
  const [firstErr, setFirstErr] = useState('');
  const [optsOpen, setOptsOpen] = useState(false);
  const [opts, setOpts] = useState<ImgOpts>({ format: 'png', quality: 'high', dpi: 150 });
  const [phase, setPhase] = useState<'pick' | 'working' | 'done'>('pick');
  const [prog, setProg] = useState(0);
  const [count, setCount] = useState(0);
  const [result, setResult] = useState<{ blob: Blob; name: string; count: number } | null>(null);
  const [saving, setSaving] = useState(false);
  const scroller = useRef<HTMLElement>(null);
  const cancel = useRef(false);
  const total = doc?.numPages ?? 0;
  const base = file.name.replace(/\.pdf$/i, '');

  useBack(true, () => {
    if (phase === 'working') cancel.current = true;
    else onClose();
  });

  useEffect(() => {
    let dead = false;
    let d: PDFDoc | null = null;
    (async () => {
      try {
        const blob = await getBlob(file.id);
        if (!blob) throw new Error('missing');
        d = await openPdf(blob, (wrong) => new Promise((res) => setPw({ id: Date.now(), wrong, resolve: res })));
        if (dead) {
          d.destroy();
          return;
        }
        const p = await d.getPage(1);
        const v = p.getViewport({ scale: 1 });
        p.cleanup();
        setDims({ w: v.width, h: v.height });
        setDoc(d);
      } catch (e) {
        if (dead) return;
        if (e instanceof NeedPassword) onClose();
        else setFail(true);
      }
    })();
    return () => {
      dead = true;
      d?.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file.id]);

  const rangeErr = useMemo(() => (doc ? parseRange(range, total).error : ''), [range, total, doc]);
  const all = () => Array.from({ length: total }, (_, i) => i + 1);
  const setManual = (s: Set<number>) => {
    setSel(s);
    setRange('');
    setFirstErr('');
  };
  const onRange = (text: string) => {
    setRange(text);
    setFirstErr('');
    const r = parseRange(text, total);
    if (!r.error && text.trim()) setSel(new Set(r.pages));
  };
  const selectFirst = () => {
    const n = parseInt(firstN, 10);
    if (!n || n < 1 || n > total) {
      setFirstErr(t('numberRange', { total }));
      return;
    }
    setManual(new Set(all().slice(0, n)));
  };
  const toggle = (n: number) => {
    const s = new Set(sel);
    s.has(n) ? s.delete(n) : s.add(n);
    setManual(s);
  };

  const pxPerPage = ((dims.w * opts.dpi) / 72) * ((dims.h * opts.dpi) / 72);
  const heavy = sel.size * pxPerPage > 150_000_000;

  const run = async () => {
    if (!doc || !sel.size) return;
    const pages = [...sel].sort((a, b) => a - b);
    setOptsOpen(false);
    setCount(pages.length);
    setProg(0);
    cancel.current = false;
    setPhase('working');
    await new Promise<void>((r2) => requestAnimationFrame(() => setTimeout(r2, 60)));
    try {
      const r = await pdfToImages(doc, pages, base, opts, setProg, () => cancel.current);
      setResult({ ...r, count: pages.length });
      setPhase('done');
    } catch (e) {
      say(e instanceof Cancelled ? t('cancelled') : t('convFail'));
      setPhase('pick');
    }
  };

  const save = async () => {
    if (!result || saving) return;
    setSaving(true);
    const guard = setTimeout(() => setSaving(false), 8000);
    try {
      const r = await saveToDevice(result.name, result.blob);
      say(r.mode === 'saved' ? t('savedTo', { path: r.path }) : r.mode === 'shared' ? t('chooseSave') : t('downloadStarted'));
    } catch {
      say(t('saveFail'));
    } finally {
      clearTimeout(guard);
      setSaving(false);
    }
  };

  return (
    <>
      <header className="hdr">
        <PressButton className="ib" aria-label="Back" onClick={onClose}><Icon n="back" /></PressButton>
        <div className="title small">{t('pdfToImages')}</div>
        <div className="ib" />
      </header>

      {!doc && !fail && !pw && <div className="pane"><div className="empty"><div className="spin" /></div></div>}
      {fail && (
        <div className="pane"><div className="empty"><h3>{t('fileOpenFail')}</h3><PressButton className="dbtn primary" style={{ marginTop: 16 }} onClick={onClose}>{t('back')}</PressButton></div></div>
      )}

      {doc && (
        <>
          <main className="pane" ref={scroller}>
            <div className="chips">
              <PressButton className="chip" onClick={() => setManual(new Set(all()))}>{t('all')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set())}>{t('none')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set(all().filter((n) => !sel.has(n))))}>{t('invert')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set(all().filter((n) => n % 2 === 1)))}>{t('odd')}</PressButton>
              <PressButton className="chip" onClick={() => setManual(new Set(all().filter((n) => n % 2 === 0)))}>{t('even')}</PressButton>
            </div>
            <div className="field">
              <input className="dinput" inputMode="text" placeholder={t('pagesPlaceholder')} dir="ltr" value={range} onChange={(e) => onRange(e.target.value)} />
            </div>
            {rangeErr && <div className="ferr">{rangeErr}</div>}
            <div className="field">
              <input className="dinput" inputMode="numeric" placeholder={t('firstNPlaceholder', { total })} dir="ltr" value={firstN} onChange={(e) => { setFirstN(e.target.value); setFirstErr(''); }} onKeyDown={(e) => e.key === 'Enter' && selectFirst()} />
              <PressButton className="dbtn" onClick={selectFirst}>{t('select')}</PressButton>
            </div>
            {firstErr && <div className="ferr">{firstErr}</div>}
            <div className="fcount">{t('nOfTotalSelected', { n: sel.size, total })}</div>
            <div className="pgrid">
              {Array.from({ length: total }, (_, i) => (
                <PageCell key={i} doc={doc} n={i + 1} ratio={dims.h / dims.w} on={sel.has(i + 1)} onToggle={() => toggle(i + 1)} root={scroller} />
              ))}
            </div>
          </main>
          <div className="actbar">
            <div className="grow">{t('nPages', { n: sel.size })}</div>
            <PressButton className="dbtn primary" disabled={!sel.size} onClick={() => setOptsOpen(true)}>{t('convert')}</PressButton>
          </div>
        </>
      )}

      {phase === 'pick' && (
      <AnimatePresence>
        {optsOpen && (
          <Sheet key="opts" title={t('exportOptions')} onClose={() => setOptsOpen(false)}>
            <div className="flabel">{t('format')}</div>
            <Segmented value={opts.format} onChange={(v) => setOpts({ ...opts, format: v })} options={[{ v: 'png', label: 'PNG' }, { v: 'jpg', label: 'JPG' }]} />
            {opts.format === 'jpg' && (
              <>
                <div className="flabel">{t('quality')}</div>
                <Segmented value={opts.quality} onChange={(v) => setOpts({ ...opts, quality: v })} options={[{ v: 'high', label: t('qHigh') }, { v: 'medium', label: t('qMedium') }, { v: 'low', label: t('qLow') }]} />
              </>
            )}
            <div className="flabel">{t('resolution')}</div>
            <Segmented value={opts.dpi} onChange={(v) => setOpts({ ...opts, dpi: v })} options={[{ v: 72, label: '72 DPI' }, { v: 150, label: '150 DPI' }, { v: 300, label: '300 DPI' }]} />
            {heavy && <div className="warn">{t('heavyWarn', { n: sel.size, dpi: opts.dpi })}</div>}
            <p className="hint" style={{ paddingInlineStart: 4 }}>{sel.size === 1 ? t('onePageHint') : t('severalHint')}</p>
            <PressButton className="dbtn primary wide" onClick={run}>{t('convertN', { n: sel.size })}</PressButton>
          </Sheet>
        )}
      </AnimatePresence>
      )}

      <AnimatePresence>
        {pw && (
          <Dialog
            key={'pw' + pw.id}
            spec={{
              title: pw.wrong ? t('wrongPassword') : t('passwordRequired'),
              message: pw.wrong ? t('tryAgain') : t('pdfProtected'),
              input: { type: 'password', placeholder: t('password') },
              ok: t('open'),
              onOk: (v) => {
                if (!v) return t('enterPassword');
                pw.resolve(v);
                setPw(null);
              },
              onCancel: () => {
                pw.resolve(null);
                setPw(null);
              },
            }}
            onClose={() => {}}
          />
        )}
      </AnimatePresence>

      {phase === 'working' && (
        <div className="veil">
          <div className="wcard">
            <div className="dtitle">{t('converting')}</div>
            <p className="dmsg">{t('pageXofY', { x: Math.min(prog + 1, count), y: count })}</p>
            <div className="track"><motion.div className="bar" animate={{ width: `${count ? (prog / count) * 100 : 0}%` }} /></div>
            <PressButton className="dbtn wide" onClick={() => (cancel.current = true)}>{t('cancel')}</PressButton>
          </div>
        </div>
      )}

      {phase === 'done' && result && (
        <div className="veil">
          <motion.div className="wcard" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: 'spring', stiffness: 380, damping: 30 }}>
            <div className="okico"><Icon n="check" size={30} sw={3} /></div>
            <div className="dtitle">{result.count === 1 ? t('imageReady') : t('imagesReady', { n: result.count })}</div>
            <p className="dmsg">{result.name} · {fmtSize(result.blob.size)}</p>
            <PressButton className="dbtn primary wide" disabled={saving} onClick={save}>{saving ? t('saving') : t('saveToDevice')}</PressButton>
            <PressButton className="dbtn wide" onClick={() => setPhase('pick')}>{t('convertMore')}</PressButton>
            <PressButton className="dbtn wide" onClick={onClose}>{t('done')}</PressButton>
          </motion.div>
        </div>
      )}
    </>
  );
}
