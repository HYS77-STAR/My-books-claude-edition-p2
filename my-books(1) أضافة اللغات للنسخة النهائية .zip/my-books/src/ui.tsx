import { Component, ReactNode, useState } from 'react';
import { AnimatePresence, HTMLMotionProps, motion, useIsPresent } from 'framer-motion';
import { useBack } from './back';
import { t } from './i18n';

const P = {
  plus: 'M12 5v14M5 12h14',
  sliders: 'M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4',
  back: 'M15 18l-6-6 6-6',
  more: 'M12 5h.01M12 12h.01M12 19h.01',
  folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  file: 'M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3',
  check: 'M5 12l5 5 9-10',
  x: 'M6 6l12 12M18 6L6 18',
  save: 'M12 3v12M7 10l5 5 5-5M5 21h14',
  edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z',
  open: 'M5 12h14M13 6l6 6-6 6',
  book: 'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 19a2 2 0 0 1 2-2h13',
  rotate: 'M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5',
  grip: 'M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01',
  image: 'M4 5h16v14H4zM4 16l4-4 4 4 3-3 5 5M9 9h.01',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z',
};
export type IconName = keyof typeof P;

export function Icon({ n, size = 22, sw = 2 }: { n: IconName; size?: number; sw?: number }) {
  return (
    <svg className={n === 'back' || n === 'open' ? 'dir' : undefined} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
      <path d={P[n]} />
    </svg>
  );
}

export const spring = { type: 'spring', stiffness: 500, damping: 30 } as const;

export function PressButton(props: HTMLMotionProps<'button'>) {
  return <motion.button whileTap={{ scale: 0.92 }} transition={spring} {...props} />;
}

export function Opt({ icon, label, onClick, danger }: { icon: IconName; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <PressButton className={'opt' + (danger ? ' danger' : '')} onClick={onClick}>
      <Icon n={icon} />
      <span>{label}</span>
    </PressButton>
  );
}

export function Sheet({ onClose, title, children }: { onClose: () => void; title?: string; children: ReactNode }) {
  const present = useIsPresent(); // false while the exit animation runs
  useBack(present, onClose);
  return (
    <div className="layer">
      <motion.div className="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
      <motion.div
        className="sheet"
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', stiffness: 380, damping: 38 }}
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0, bottom: 0.5 }}
        onDragEnd={(_, i) => {
          if (i.offset.y > 90 || i.velocity.y > 600) onClose();
        }}
      >
        <div className="grab" />
        {title && <div className="stitle">{title}</div>}
        {children}
      </motion.div>
    </div>
  );
}

export interface DialogSpec {
  title: string;
  message?: string;
  input?: { type?: string; initial?: string; placeholder?: string };
  ok: string;
  danger?: boolean;
  onOk: (value: string) => string | void | Promise<string | void>;
  onCancel?: () => void;
}

export function Dialog({ spec, onClose }: { spec: DialogSpec; onClose: () => void }) {
  const [v, setV] = useState(spec.input?.initial ?? '');
  const [err, setErr] = useState('');
  const [work, setWork] = useState(false);
  const cancel = () => {
    spec.onCancel?.();
    onClose();
  };
  const present = useIsPresent();
  useBack(present, cancel);
  const submit = async () => {
    if (work) return;
    setWork(true);
    let e: string | void = undefined;
    try {
      e = await spec.onOk(v);
    } catch {
      e = t('wentWrong');
    }
    setWork(false);
    if (e) setErr(e);
    else onClose();
  };
  return (
    <div className="layer center">
      <motion.div className="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={cancel} />
      <motion.div className="dlg" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.94 }} transition={{ type: 'spring', stiffness: 420, damping: 32 }}>
        <div className="dtitle">{spec.title}</div>
        {spec.message && <p className="dmsg">{spec.message}</p>}
        {spec.input && (
          <input
            className="dinput"
            autoFocus
            type={spec.input.type || 'text'}
            inputMode={spec.input.type === 'number' ? 'numeric' : undefined}
            placeholder={spec.input.placeholder}
            value={v}
            onChange={(e) => {
              setV(e.target.value);
              setErr('');
            }}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
          />
        )}
        {err && <div className="derr">{err}</div>}
        <div className="dbtns">
          <PressButton className="dbtn" onClick={cancel}>{t('cancel')}</PressButton>
          <PressButton className={'dbtn primary' + (spec.danger ? ' danger' : '')} onClick={submit}>{spec.ok}</PressButton>
        </div>
      </motion.div>
    </div>
  );
}

export function Toast({ msg }: { msg: string | null }) {
  return (
    <AnimatePresence>
      {msg && (
        <motion.div className="toast" initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }} transition={{ type: 'spring', stiffness: 400, damping: 30 }}>
          {msg}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Segmented<T extends string | number>({ id, value, options, onChange }: { id?: string; value: T; options: { v: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className={'seg' + (id ? '' : ' plain')}>
      {options.map((o) => (
        <button key={String(o.v)} className={o.v === value ? 'on' : ''} onClick={() => onChange(o.v)}>
          {id && o.v === value && <motion.span layoutId={id} className="segbg" transition={spring} />}
          <span className="segl">{o.label}</span>
        </button>
      ))}
    </div>
  );
}

/** If a screen crashes while rendering, show a way out instead of leaving the app stuck. */
export class Boundary extends Component<{ onClose: () => void; children: ReactNode }, { bad: boolean }> {
  state = { bad: false };
  static getDerivedStateFromError() {
    return { bad: true };
  }
  render() {
    if (!this.state.bad) return this.props.children;
    return (
      <div className="center-fill col" style={{ position: 'absolute', inset: 0 }}>
        <p>{t('screenCrash')}</p>
        <PressButton className="dbtn primary" onClick={this.props.onClose}>{t('close')}</PressButton>
      </div>
    );
  }
}
