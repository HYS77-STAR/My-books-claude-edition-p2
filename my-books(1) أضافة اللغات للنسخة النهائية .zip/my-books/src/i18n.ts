import { useSyncExternalStore } from 'react';

export type Lang = 'en' | 'ar' | 'zh' | 'es' | 'pt' | 'fr';

/** Every language is written in its own language, so anyone can find theirs. */
export const LANGS: { code: Lang; name: string; mono: string; rtl: boolean; title: string; cont: string }[] = [
  { code: 'en', name: 'English', mono: 'En', rtl: false, title: 'Choose your language', cont: 'Continue' },
  { code: 'ar', name: 'العربية', mono: 'ع', rtl: true, title: 'اختر لغتك', cont: 'متابعة' },
  { code: 'zh', name: '中文 (简体)', mono: '中', rtl: false, title: '选择你的语言', cont: '继续' },
  { code: 'es', name: 'Español', mono: 'Es', rtl: false, title: 'Elige tu idioma', cont: 'Continuar' },
  { code: 'pt', name: 'Português', mono: 'Pt', rtl: false, title: 'Escolha seu idioma', cont: 'Continuar' },
  { code: 'fr', name: 'Français', mono: 'Fr', rtl: false, title: 'Choisissez votre langue', cont: 'Continuer' },
];

type V = string | ((p: any) => string);

// ---------------------------------------------------------------- English (the base)
const en = {
  cancel: 'Cancel', close: 'Close', back: 'Back', done: 'Done', open: 'Open', save: 'Save', delete: 'Delete', create: 'Create',
  retry: 'Retry', go: 'Go', select: 'Select', all: 'All', none: 'None', invert: 'Invert', odd: 'Odd', even: 'Even', convert: 'Convert',
  enterName: 'Enter a name.',
  loadFail: 'Could not load your library.',
  storageFull: 'Storage is full. Free some space and try again.',
  notPdf: (p: any) => `"${p.name}" is not a valid PDF and was skipped.`,
  importedN: (p: any) => (p.n === 1 ? 'Imported 1 book' : `Imported ${p.n} books`),
  renameBook: 'Rename book', bookExists: 'A book with this name already exists.',
  deleteBookQ: 'Delete this book?', deleteBooksQ: (p: any) => `Delete ${p.n} books?`,
  deleteMsg: 'This removes the copy stored inside the app. Your original files on the device are not touched.',
  deleted: 'Deleted',
  saveFail: 'Could not save the file.', savedTo: (p: any) => `Saved to ${p.path}`, chooseSave: 'Choose where to save the file', downloadStarted: 'Download started',
  newFolder: 'New folder', folderName: 'Folder name', folderExists: 'A folder with this name already exists.',
  renameFolder: 'Rename folder', deleteFolderQ: 'Delete this folder?',
  deleteFolderMsg: 'The books inside are kept. They just stop belonging to a folder.', deleteFolder: 'Delete folder',
  emptyBooksT: 'No books yet', emptyBooksX: 'Tap + to import PDF files. Each one is copied into the app.',
  emptyFoldersT: 'No folders yet', emptyFoldersX: 'Tap + and choose New folder to group your books.',
  emptyFolderT: 'This folder is empty', emptyFolderX: 'Tap + to add books from your library.',
  tabFiles: 'Files', tabFolders: 'Folders',
  importPdfs: 'Import PDF files', imagesToPdf: 'Images to PDF', pdfToImages: 'PDF to images',
  menuRename: 'Rename', menuMove: 'Move to folder', menuSave: 'Save a copy to device', menuConvert: 'Convert to images',
  moveToFolder: 'Move to folder', noFolder: 'No folder', moved: 'Moved', movedTo: (p: any) => `Moved to ${p.name}`,
  noFoldersHint: 'You have no folders yet. Create one from the + button.',
  addToFolder: 'Add books to this folder', allInFolder: 'All your books are already in this folder.',
  addN: (p: any) => `Add ${p.n}`, addedN: (p: any) => (p.n === 1 ? 'Added 1 book' : `Added ${p.n} books`),
  choosePdf: 'Choose a PDF to convert', importFirst: 'Import a PDF first.',
  nSelected: (p: any) => `${p.n} selected`, importingXofY: (p: any) => `Importing ${p.x} of ${p.y}`,
  settings: 'Settings', theme: 'Theme', themeHint: 'Light is white with black text. Dark is black with white text.',
  light: 'Light', dark: 'Dark', filesView: 'Files view', filesViewHint: 'Show your books as cards or as a list.',
  cards: 'Cards', list: 'List', gridSize: 'Grid size', gridHint: 'Fewer columns make bigger cards.',
  language: 'Language', languageHint: 'Choose the language of the app.',
  protectedLabel: 'Protected',
  nPages: (p: any) => (p.n === 1 ? '1 page' : `${p.n} pages`),
  nBooks: (p: any) => (p.n === 1 ? '1 book' : `${p.n} books`),
  nImages: (p: any) => (p.n === 1 ? '1 image' : `${p.n} images`),
  pageFail: 'This page could not be displayed', fileOpenFail: 'This file could not be opened.',
  goToPage: 'Go to page', enterPage: (p: any) => `Enter a page from 1 to ${p.total}.`,
  wrongPassword: 'Wrong password', passwordRequired: 'Password required', tryAgain: 'Try again.',
  pdfProtected: 'This PDF is protected.', password: 'Password', enterPassword: 'Enter the password.',
  defaultPdfName: 'Images', cancelled: 'Cancelled', createFail: 'Could not create the PDF. Try fewer or smaller images.',
  noImagesT: 'No images yet', noImagesX: 'Tap + to choose JPG, PNG or WebP images.',
  reorderHint: 'Drag the ⋮⋮ handle to reorder. Rotate or remove images before creating the PDF.',
  createPdf: 'Create PDF', pdfOptions: 'PDF options', pageSize: 'Page size', imageSize: 'Image size', margins: 'Margins',
  mSmall: 'Small', mMedium: 'Medium', quality: 'Quality', qHigh: 'High', qMedium: 'Medium', qLow: 'Low', fileName: 'File name',
  creating: 'Creating PDF', imageXofY: (p: any) => `Image ${p.x} of ${p.y}`, pdfCreated: 'PDF created', saving: 'Saving…',
  unsupported1: (p: any) => `"${p.name}" is not a supported image (use JPG, PNG or WebP).`,
  unsupportedN: (p: any) => `${p.n} files are not supported images and were skipped (use JPG, PNG or WebP).`,
  convFail: 'Conversion failed. Try a lower resolution or fewer pages.',
  pagesPlaceholder: 'Pages, e.g. 1-5, 8, 10-12', firstNPlaceholder: (p: any) => `First N pages (1–${p.total})`,
  numberRange: (p: any) => `Enter a number from 1 to ${p.total}.`,
  nOfTotalSelected: (p: any) => `${p.n} of ${p.total} pages selected`,
  exportOptions: 'Export options', format: 'Format', resolution: 'Resolution',
  heavyWarn: (p: any) => `${p.n} pages at ${p.dpi} DPI is a lot of data. It can be slow and use plenty of memory and storage. Lower the resolution if the conversion fails.`,
  onePageHint: 'One page is saved as a single image.', severalHint: 'Several pages are saved together in one ZIP file.',
  convertN: (p: any) => (p.n === 1 ? 'Convert 1 page' : `Convert ${p.n} pages`),
  converting: 'Converting', pageXofY: (p: any) => `Page ${p.x} of ${p.y}`, imageReady: 'Image ready',
  imagesReady: (p: any) => `${p.n} images ready`, saveToDevice: 'Save to device', convertMore: 'Convert more',
  rangeBad: (p: any) => `"${p.part}" is not a page number or range.`,
  rangeBounds: (p: any) => `Pages must be between 1 and ${p.total}.`,
  rangeBack: (p: any) => `"${p.part}" goes backwards. Write it as ${p.rev}.`,
  wentWrong: 'Something went wrong. Try again.', screenCrash: 'Something went wrong on this screen.',
};
export type Key = keyof typeof en;

// Arabic needs singular / dual / few / many forms.
const arN = (n: number, one: string, twoNom: string, twoGen: string, few: string, many: string, gen = false) => {
  if (n === 1) return one;
  if (n === 2) return gen ? twoGen : twoNom;
  const m = n % 100;
  return m >= 3 && m <= 10 ? `${n} ${few}` : `${n} ${many}`;
};
const arBooks = (n: number, gen = false) => arN(n, 'كتاب واحد', 'كتابان', 'كتابين', 'كتب', 'كتاباً', gen);
const arPages = (n: number, gen = false) => arN(n, 'صفحة واحدة', 'صفحتان', 'صفحتين', 'صفحات', 'صفحة', gen);
const arImages = (n: number, gen = false) => arN(n, 'صورة واحدة', 'صورتان', 'صورتين', 'صور', 'صورة', gen);

const ar: Partial<Record<Key, V>> = {
  cancel: 'إلغاء', close: 'إغلاق', back: 'رجوع', done: 'تم', open: 'فتح', save: 'حفظ', delete: 'حذف', create: 'إنشاء',
  retry: 'إعادة المحاولة', go: 'انتقال', select: 'تحديد', all: 'الكل', none: 'لا شيء', invert: 'عكس', odd: 'الفردية', even: 'الزوجية', convert: 'تحويل',
  enterName: 'أدخل اسماً.',
  loadFail: 'تعذّر تحميل مكتبتك.',
  storageFull: 'مساحة التخزين ممتلئة. حرّر بعض المساحة وحاول مرة أخرى.',
  notPdf: (p) => `«${p.name}» ليس ملف PDF صالحاً وتم تخطيه.`,
  importedN: (p) => `تم استيراد ${arBooks(p.n, true)}`,
  renameBook: 'إعادة تسمية الكتاب', bookExists: 'يوجد كتاب بهذا الاسم بالفعل.',
  deleteBookQ: 'حذف هذا الكتاب؟', deleteBooksQ: (p) => `حذف ${arBooks(p.n, true)}؟`,
  deleteMsg: 'سيتم حذف النسخة المخزّنة داخل التطبيق فقط. ملفاتك الأصلية على الجهاز لن تتأثر.',
  deleted: 'تم الحذف',
  saveFail: 'تعذّر حفظ الملف.', savedTo: (p) => `تم الحفظ في ${p.path}`, chooseSave: 'اختر مكان حفظ الملف', downloadStarted: 'بدأ التنزيل',
  newFolder: 'مجلد جديد', folderName: 'اسم المجلد', folderExists: 'يوجد مجلد بهذا الاسم بالفعل.',
  renameFolder: 'إعادة تسمية المجلد', deleteFolderQ: 'حذف هذا المجلد؟',
  deleteFolderMsg: 'ستبقى الكتب التي بداخله، وستصبح فقط بلا مجلد.', deleteFolder: 'حذف المجلد',
  emptyBooksT: 'لا توجد كتب بعد', emptyBooksX: 'اضغط + لاستيراد ملفات PDF. تُنسخ كل منها داخل التطبيق.',
  emptyFoldersT: 'لا توجد مجلدات بعد', emptyFoldersX: 'اضغط + ثم اختر «مجلد جديد» لتنظيم كتبك.',
  emptyFolderT: 'هذا المجلد فارغ', emptyFolderX: 'اضغط + لإضافة كتب من مكتبتك.',
  tabFiles: 'الملفات', tabFolders: 'المجلدات',
  importPdfs: 'استيراد ملفات PDF', imagesToPdf: 'تحويل الصور إلى PDF', pdfToImages: 'تحويل PDF إلى صور',
  menuRename: 'إعادة تسمية', menuMove: 'نقل إلى مجلد', menuSave: 'حفظ نسخة في الجهاز', menuConvert: 'تحويل إلى صور',
  moveToFolder: 'نقل إلى مجلد', noFolder: 'بلا مجلد', moved: 'تم النقل', movedTo: (p) => `تم النقل إلى ${p.name}`,
  noFoldersHint: 'ليس لديك مجلدات بعد. أنشئ واحداً من زر +.',
  addToFolder: 'إضافة كتب إلى هذا المجلد', allInFolder: 'كل كتبك موجودة في هذا المجلد بالفعل.',
  addN: (p) => `إضافة ${p.n}`, addedN: (p) => `تمت إضافة ${arBooks(p.n, true)}`,
  choosePdf: 'اختر ملف PDF لتحويله', importFirst: 'استورد ملف PDF أولاً.',
  nSelected: (p) => `تم تحديد ${p.n}`, importingXofY: (p) => `جارٍ الاستيراد ${p.x} من ${p.y}`,
  settings: 'الإعدادات', theme: 'المظهر', themeHint: 'الفاتح خلفيته بيضاء ونصه أسود. الداكن خلفيته سوداء ونصه أبيض.',
  light: 'فاتح', dark: 'داكن', filesView: 'عرض الملفات', filesViewHint: 'اعرض كتبك كبطاقات أو كقائمة.',
  cards: 'بطاقات', list: 'قائمة', gridSize: 'حجم الشبكة', gridHint: 'كلما قلّت الأعمدة كبرت البطاقات.',
  language: 'اللغة', languageHint: 'اختر لغة التطبيق.',
  protectedLabel: 'محمي',
  nPages: (p) => arPages(p.n), nBooks: (p) => arBooks(p.n), nImages: (p) => arImages(p.n),
  pageFail: 'تعذّر عرض هذه الصفحة', fileOpenFail: 'تعذّر فتح هذا الملف.',
  goToPage: 'الانتقال إلى صفحة', enterPage: (p) => `أدخل رقم صفحة من 1 إلى ${p.total}.`,
  wrongPassword: 'كلمة المرور خاطئة', passwordRequired: 'كلمة المرور مطلوبة', tryAgain: 'حاول مرة أخرى.',
  pdfProtected: 'هذا الملف محمي بكلمة مرور.', password: 'كلمة المرور', enterPassword: 'أدخل كلمة المرور.',
  defaultPdfName: 'صور', cancelled: 'تم الإلغاء', createFail: 'تعذّر إنشاء ملف PDF. جرّب صوراً أقل أو أصغر حجماً.',
  noImagesT: 'لا توجد صور بعد', noImagesX: 'اضغط + لاختيار صور JPG أو PNG أو WebP.',
  reorderHint: 'اسحب المقبض ⋮⋮ لإعادة الترتيب. دوّر الصور أو احذفها قبل إنشاء الملف.',
  createPdf: 'إنشاء PDF', pdfOptions: 'خيارات PDF', pageSize: 'حجم الصفحة', imageSize: 'حجم الصورة', margins: 'الهوامش',
  mSmall: 'صغيرة', mMedium: 'متوسطة', quality: 'الجودة', qHigh: 'عالية', qMedium: 'متوسطة', qLow: 'منخفضة', fileName: 'اسم الملف',
  creating: 'جارٍ إنشاء PDF', imageXofY: (p) => `الصورة ${p.x} من ${p.y}`, pdfCreated: 'تم إنشاء PDF', saving: 'جارٍ الحفظ…',
  unsupported1: (p) => `«${p.name}» ليست صورة مدعومة (استخدم JPG أو PNG أو WebP).`,
  unsupportedN: (p) => `${p.n} ملفات ليست صوراً مدعومة وتم تخطيها (استخدم JPG أو PNG أو WebP).`,
  convFail: 'فشل التحويل. جرّب دقة أقل أو صفحات أقل.',
  pagesPlaceholder: 'الصفحات، مثال: 1-5, 8, 10-12', firstNPlaceholder: (p) => `أول N صفحة (1–${p.total})`,
  numberRange: (p) => `أدخل رقماً من 1 إلى ${p.total}.`,
  nOfTotalSelected: (p) => `تم تحديد ${p.n} من ${p.total}`,
  exportOptions: 'خيارات التصدير', format: 'الصيغة', resolution: 'الدقة',
  heavyWarn: (p) => `حجم البيانات كبير: ${arPages(p.n)} بدقة ${p.dpi} DPI. قد يكون التحويل بطيئاً ويستهلك ذاكرة ومساحة كثيرة. خفّض الدقة إن فشل التحويل.`,
  onePageHint: 'تُحفظ الصفحة الواحدة كصورة منفردة.', severalHint: 'تُحفظ الصفحات المتعددة معاً في ملف ZIP واحد.',
  convertN: (p) => `تحويل ${arPages(p.n, true)}`,
  converting: 'جارٍ التحويل', pageXofY: (p) => `الصفحة ${p.x} من ${p.y}`, imageReady: 'الصورة جاهزة',
  imagesReady: (p) => (p.n === 2 ? 'صورتان جاهزتان' : `${p.n} ${p.n % 100 >= 3 && p.n % 100 <= 10 ? 'صور' : 'صورة'} جاهزة`),
  saveToDevice: 'حفظ في الجهاز', convertMore: 'تحويل المزيد',
  rangeBad: (p) => `«${p.part}» ليس رقم صفحة أو نطاقاً صحيحاً.`,
  rangeBounds: (p) => `يجب أن تكون الصفحات بين 1 و${p.total}.`,
  rangeBack: (p) => `النطاق «${p.part}» معكوس. اكتبه هكذا: ${p.rev}.`,
  wentWrong: 'حدث خطأ ما. حاول مرة أخرى.', screenCrash: 'حدث خطأ في هذه الشاشة.',
};

const zh: Partial<Record<Key, V>> = {
  cancel: '取消', close: '关闭', back: '返回', done: '完成', open: '打开', save: '保存', delete: '删除', create: '创建',
  retry: '重试', go: '前往', select: '选择', all: '全选', none: '全不选', invert: '反选', odd: '奇数页', even: '偶数页', convert: '转换',
  enterName: '请输入名称。',
  loadFail: '无法加载你的书库。',
  storageFull: '存储空间已满。请释放一些空间后重试。',
  notPdf: (p) => `“${p.name}”不是有效的 PDF，已跳过。`,
  importedN: (p) => `已导入 ${p.n} 本书`,
  renameBook: '重命名书籍', bookExists: '已存在同名书籍。',
  deleteBookQ: '删除这本书？', deleteBooksQ: (p) => `删除 ${p.n} 本书？`,
  deleteMsg: '这只会删除保存在应用内的副本，设备上的原始文件不受影响。',
  deleted: '已删除',
  saveFail: '无法保存文件。', savedTo: (p) => `已保存到 ${p.path}`, chooseSave: '请选择文件的保存位置', downloadStarted: '已开始下载',
  newFolder: '新建文件夹', folderName: '文件夹名称', folderExists: '已存在同名文件夹。',
  renameFolder: '重命名文件夹', deleteFolderQ: '删除此文件夹？',
  deleteFolderMsg: '文件夹内的书籍会保留，只是不再属于任何文件夹。', deleteFolder: '删除文件夹',
  emptyBooksT: '还没有书籍', emptyBooksX: '点按 + 导入 PDF 文件，每个文件都会复制到应用内。',
  emptyFoldersT: '还没有文件夹', emptyFoldersX: '点按 +，选择“新建文件夹”来整理你的书籍。',
  emptyFolderT: '此文件夹是空的', emptyFolderX: '点按 + 从书库中添加书籍。',
  tabFiles: '文件', tabFolders: '文件夹',
  importPdfs: '导入 PDF 文件', imagesToPdf: '图片转 PDF', pdfToImages: 'PDF 转图片',
  menuRename: '重命名', menuMove: '移到文件夹', menuSave: '保存副本到设备', menuConvert: '转换为图片',
  moveToFolder: '移到文件夹', noFolder: '无文件夹', moved: '已移动', movedTo: (p) => `已移到 ${p.name}`,
  noFoldersHint: '你还没有文件夹，可通过 + 按钮创建。',
  addToFolder: '添加书籍到此文件夹', allInFolder: '你的所有书籍都已在此文件夹中。',
  addN: (p) => `添加 ${p.n} 本`, addedN: (p) => `已添加 ${p.n} 本书`,
  choosePdf: '选择要转换的 PDF', importFirst: '请先导入一个 PDF。',
  nSelected: (p) => `已选择 ${p.n} 项`, importingXofY: (p) => `正在导入 ${p.x}/${p.y}`,
  settings: '设置', theme: '主题', themeHint: '浅色为白底黑字，深色为黑底白字。',
  light: '浅色', dark: '深色', filesView: '文件视图', filesViewHint: '以卡片或列表显示你的书籍。',
  cards: '卡片', list: '列表', gridSize: '网格大小', gridHint: '列数越少，卡片越大。',
  language: '语言', languageHint: '选择应用的语言。',
  protectedLabel: '受保护',
  nPages: (p) => `${p.n} 页`, nBooks: (p) => `${p.n} 本书`, nImages: (p) => `${p.n} 张图片`,
  pageFail: '无法显示此页', fileOpenFail: '无法打开此文件。',
  goToPage: '跳转到页码', enterPage: (p) => `请输入 1 到 ${p.total} 之间的页码。`,
  wrongPassword: '密码错误', passwordRequired: '需要密码', tryAgain: '请重试。',
  pdfProtected: '此 PDF 受密码保护。', password: '密码', enterPassword: '请输入密码。',
  defaultPdfName: '图片', cancelled: '已取消', createFail: '无法创建 PDF。请尝试减少图片数量或使用较小的图片。',
  noImagesT: '还没有图片', noImagesX: '点按 + 选择 JPG、PNG 或 WebP 图片。',
  reorderHint: '拖动 ⋮⋮ 手柄可调整顺序。创建 PDF 前可旋转或删除图片。',
  createPdf: '创建 PDF', pdfOptions: 'PDF 选项', pageSize: '页面大小', imageSize: '图片大小', margins: '页边距',
  mSmall: '小', mMedium: '中', quality: '质量', qHigh: '高', qMedium: '中', qLow: '低', fileName: '文件名',
  creating: '正在创建 PDF', imageXofY: (p) => `第 ${p.x} 张，共 ${p.y} 张`, pdfCreated: 'PDF 已创建', saving: '正在保存…',
  unsupported1: (p) => `“${p.name}”不是受支持的图片（请使用 JPG、PNG 或 WebP）。`,
  unsupportedN: (p) => `有 ${p.n} 个文件不是受支持的图片，已跳过（请使用 JPG、PNG 或 WebP）。`,
  convFail: '转换失败。请尝试降低分辨率或减少页数。',
  pagesPlaceholder: '页码，例如 1-5, 8, 10-12', firstNPlaceholder: (p) => `前 N 页（1–${p.total}）`,
  numberRange: (p) => `请输入 1 到 ${p.total} 之间的数字。`,
  nOfTotalSelected: (p) => `已选 ${p.n} / ${p.total} 页`,
  exportOptions: '导出选项', format: '格式', resolution: '分辨率',
  heavyWarn: (p) => `以 ${p.dpi} DPI 转换 ${p.n} 页数据量很大，可能较慢并占用大量内存和存储空间。如果转换失败，请降低分辨率。`,
  onePageHint: '单页将保存为一张图片。', severalHint: '多页将一起保存在一个 ZIP 文件中。',
  convertN: (p) => `转换 ${p.n} 页`,
  converting: '正在转换', pageXofY: (p) => `第 ${p.x} 页，共 ${p.y} 页`, imageReady: '图片已就绪',
  imagesReady: (p) => `${p.n} 张图片已就绪`, saveToDevice: '保存到设备', convertMore: '继续转换',
  rangeBad: (p) => `“${p.part}”不是有效的页码或范围。`,
  rangeBounds: (p) => `页码必须在 1 到 ${p.total} 之间。`,
  rangeBack: (p) => `范围“${p.part}”顺序颠倒，请写成 ${p.rev}。`,
  wentWrong: '出了点问题，请重试。', screenCrash: '此界面出现问题。',
};

const es: Partial<Record<Key, V>> = {
  cancel: 'Cancelar', close: 'Cerrar', back: 'Atrás', done: 'Listo', open: 'Abrir', save: 'Guardar', delete: 'Eliminar', create: 'Crear',
  retry: 'Reintentar', go: 'Ir', select: 'Seleccionar', all: 'Todo', none: 'Ninguno', invert: 'Invertir', odd: 'Impares', even: 'Pares', convert: 'Convertir',
  enterName: 'Introduce un nombre.',
  loadFail: 'No se pudo cargar tu biblioteca.',
  storageFull: 'El almacenamiento está lleno. Libera espacio e inténtalo de nuevo.',
  notPdf: (p) => `«${p.name}» no es un PDF válido y se omitió.`,
  importedN: (p) => (p.n === 1 ? '1 libro importado' : `${p.n} libros importados`),
  renameBook: 'Renombrar libro', bookExists: 'Ya existe un libro con este nombre.',
  deleteBookQ: '¿Eliminar este libro?', deleteBooksQ: (p) => `¿Eliminar ${p.n} libros?`,
  deleteMsg: 'Se elimina la copia guardada dentro de la app. Tus archivos originales en el dispositivo no se tocan.',
  deleted: 'Eliminado',
  saveFail: 'No se pudo guardar el archivo.', savedTo: (p) => `Guardado en ${p.path}`, chooseSave: 'Elige dónde guardar el archivo', downloadStarted: 'Descarga iniciada',
  newFolder: 'Nueva carpeta', folderName: 'Nombre de la carpeta', folderExists: 'Ya existe una carpeta con este nombre.',
  renameFolder: 'Renombrar carpeta', deleteFolderQ: '¿Eliminar esta carpeta?',
  deleteFolderMsg: 'Los libros que contiene se conservan; solo dejan de pertenecer a una carpeta.', deleteFolder: 'Eliminar carpeta',
  emptyBooksT: 'Aún no hay libros', emptyBooksX: 'Toca + para importar archivos PDF. Cada uno se copia dentro de la app.',
  emptyFoldersT: 'Aún no hay carpetas', emptyFoldersX: 'Toca + y elige «Nueva carpeta» para organizar tus libros.',
  emptyFolderT: 'Esta carpeta está vacía', emptyFolderX: 'Toca + para añadir libros de tu biblioteca.',
  tabFiles: 'Archivos', tabFolders: 'Carpetas',
  importPdfs: 'Importar archivos PDF', imagesToPdf: 'Imágenes a PDF', pdfToImages: 'PDF a imágenes',
  menuRename: 'Renombrar', menuMove: 'Mover a carpeta', menuSave: 'Guardar una copia en el dispositivo', menuConvert: 'Convertir a imágenes',
  moveToFolder: 'Mover a carpeta', noFolder: 'Sin carpeta', moved: 'Movido', movedTo: (p) => `Movido a ${p.name}`,
  noFoldersHint: 'Aún no tienes carpetas. Crea una con el botón +.',
  addToFolder: 'Añadir libros a esta carpeta', allInFolder: 'Todos tus libros ya están en esta carpeta.',
  addN: (p) => `Añadir ${p.n}`, addedN: (p) => (p.n === 1 ? '1 libro añadido' : `${p.n} libros añadidos`),
  choosePdf: 'Elige un PDF para convertir', importFirst: 'Importa un PDF primero.',
  nSelected: (p) => (p.n === 1 ? '1 seleccionado' : `${p.n} seleccionados`), importingXofY: (p) => `Importando ${p.x} de ${p.y}`,
  settings: 'Ajustes', theme: 'Tema', themeHint: 'Claro es blanco con texto negro. Oscuro es negro con texto blanco.',
  light: 'Claro', dark: 'Oscuro', filesView: 'Vista de archivos', filesViewHint: 'Muestra tus libros como tarjetas o como lista.',
  cards: 'Tarjetas', list: 'Lista', gridSize: 'Tamaño de la cuadrícula', gridHint: 'Menos columnas hacen tarjetas más grandes.',
  language: 'Idioma', languageHint: 'Elige el idioma de la app.',
  protectedLabel: 'Protegido',
  nPages: (p) => (p.n === 1 ? '1 página' : `${p.n} páginas`),
  nBooks: (p) => (p.n === 1 ? '1 libro' : `${p.n} libros`),
  nImages: (p) => (p.n === 1 ? '1 imagen' : `${p.n} imágenes`),
  pageFail: 'No se pudo mostrar esta página', fileOpenFail: 'No se pudo abrir este archivo.',
  goToPage: 'Ir a la página', enterPage: (p) => `Introduce una página de 1 a ${p.total}.`,
  wrongPassword: 'Contraseña incorrecta', passwordRequired: 'Se necesita contraseña', tryAgain: 'Inténtalo de nuevo.',
  pdfProtected: 'Este PDF está protegido.', password: 'Contraseña', enterPassword: 'Introduce la contraseña.',
  defaultPdfName: 'Imágenes', cancelled: 'Cancelado', createFail: 'No se pudo crear el PDF. Prueba con menos imágenes o más pequeñas.',
  noImagesT: 'Aún no hay imágenes', noImagesX: 'Toca + para elegir imágenes JPG, PNG o WebP.',
  reorderHint: 'Arrastra el control ⋮⋮ para reordenar. Gira o quita imágenes antes de crear el PDF.',
  createPdf: 'Crear PDF', pdfOptions: 'Opciones del PDF', pageSize: 'Tamaño de página', imageSize: 'Tamaño de imagen', margins: 'Márgenes',
  mSmall: 'Pequeños', mMedium: 'Medianos', quality: 'Calidad', qHigh: 'Alta', qMedium: 'Media', qLow: 'Baja', fileName: 'Nombre del archivo',
  creating: 'Creando PDF', imageXofY: (p) => `Imagen ${p.x} de ${p.y}`, pdfCreated: 'PDF creado', saving: 'Guardando…',
  unsupported1: (p) => `«${p.name}» no es una imagen compatible (usa JPG, PNG o WebP).`,
  unsupportedN: (p) => `${p.n} archivos no son imágenes compatibles y se omitieron (usa JPG, PNG o WebP).`,
  convFail: 'Error en la conversión. Prueba con menor resolución o menos páginas.',
  pagesPlaceholder: 'Páginas, p. ej. 1-5, 8, 10-12', firstNPlaceholder: (p) => `Primeras N páginas (1–${p.total})`,
  numberRange: (p) => `Introduce un número de 1 a ${p.total}.`,
  nOfTotalSelected: (p) => `${p.n} de ${p.total} páginas seleccionadas`,
  exportOptions: 'Opciones de exportación', format: 'Formato', resolution: 'Resolución',
  heavyWarn: (p) => `${p.n} páginas a ${p.dpi} DPI son muchos datos. Puede ser lento y usar mucha memoria y almacenamiento. Baja la resolución si falla la conversión.`,
  onePageHint: 'Una página se guarda como una sola imagen.', severalHint: 'Varias páginas se guardan juntas en un archivo ZIP.',
  convertN: (p) => (p.n === 1 ? 'Convertir 1 página' : `Convertir ${p.n} páginas`),
  converting: 'Convirtiendo', pageXofY: (p) => `Página ${p.x} de ${p.y}`, imageReady: 'Imagen lista',
  imagesReady: (p) => `${p.n} imágenes listas`, saveToDevice: 'Guardar en el dispositivo', convertMore: 'Convertir más',
  rangeBad: (p) => `«${p.part}» no es una página ni un rango válido.`,
  rangeBounds: (p) => `Las páginas deben estar entre 1 y ${p.total}.`,
  rangeBack: (p) => `«${p.part}» va al revés. Escríbelo como ${p.rev}.`,
  wentWrong: 'Algo salió mal. Inténtalo de nuevo.', screenCrash: 'Algo salió mal en esta pantalla.',
};

const pt: Partial<Record<Key, V>> = {
  cancel: 'Cancelar', close: 'Fechar', back: 'Voltar', done: 'Concluir', open: 'Abrir', save: 'Salvar', delete: 'Excluir', create: 'Criar',
  retry: 'Tentar novamente', go: 'Ir', select: 'Selecionar', all: 'Todas', none: 'Nenhuma', invert: 'Inverter', odd: 'Ímpares', even: 'Pares', convert: 'Converter',
  enterName: 'Digite um nome.',
  loadFail: 'Não foi possível carregar sua biblioteca.',
  storageFull: 'O armazenamento está cheio. Libere espaço e tente novamente.',
  notPdf: (p) => `«${p.name}» não é um PDF válido e foi ignorado.`,
  importedN: (p) => (p.n === 1 ? '1 livro importado' : `${p.n} livros importados`),
  renameBook: 'Renomear livro', bookExists: 'Já existe um livro com este nome.',
  deleteBookQ: 'Excluir este livro?', deleteBooksQ: (p) => `Excluir ${p.n} livros?`,
  deleteMsg: 'Isso remove a cópia guardada dentro do app. Seus arquivos originais no dispositivo não são afetados.',
  deleted: 'Excluído',
  saveFail: 'Não foi possível salvar o arquivo.', savedTo: (p) => `Salvo em ${p.path}`, chooseSave: 'Escolha onde salvar o arquivo', downloadStarted: 'Download iniciado',
  newFolder: 'Nova pasta', folderName: 'Nome da pasta', folderExists: 'Já existe uma pasta com este nome.',
  renameFolder: 'Renomear pasta', deleteFolderQ: 'Excluir esta pasta?',
  deleteFolderMsg: 'Os livros dentro dela são mantidos; apenas deixam de pertencer a uma pasta.', deleteFolder: 'Excluir pasta',
  emptyBooksT: 'Ainda não há livros', emptyBooksX: 'Toque em + para importar arquivos PDF. Cada um é copiado para dentro do app.',
  emptyFoldersT: 'Ainda não há pastas', emptyFoldersX: 'Toque em + e escolha «Nova pasta» para organizar seus livros.',
  emptyFolderT: 'Esta pasta está vazia', emptyFolderX: 'Toque em + para adicionar livros da sua biblioteca.',
  tabFiles: 'Arquivos', tabFolders: 'Pastas',
  importPdfs: 'Importar arquivos PDF', imagesToPdf: 'Imagens para PDF', pdfToImages: 'PDF para imagens',
  menuRename: 'Renomear', menuMove: 'Mover para pasta', menuSave: 'Salvar uma cópia no dispositivo', menuConvert: 'Converter em imagens',
  moveToFolder: 'Mover para pasta', noFolder: 'Sem pasta', moved: 'Movido', movedTo: (p) => `Movido para ${p.name}`,
  noFoldersHint: 'Você ainda não tem pastas. Crie uma pelo botão +.',
  addToFolder: 'Adicionar livros a esta pasta', allInFolder: 'Todos os seus livros já estão nesta pasta.',
  addN: (p) => `Adicionar ${p.n}`, addedN: (p) => (p.n === 1 ? '1 livro adicionado' : `${p.n} livros adicionados`),
  choosePdf: 'Escolha um PDF para converter', importFirst: 'Importe um PDF primeiro.',
  nSelected: (p) => (p.n === 1 ? '1 selecionado' : `${p.n} selecionados`), importingXofY: (p) => `Importando ${p.x} de ${p.y}`,
  settings: 'Configurações', theme: 'Tema', themeHint: 'Claro é branco com texto preto. Escuro é preto com texto branco.',
  light: 'Claro', dark: 'Escuro', filesView: 'Visualização dos arquivos', filesViewHint: 'Mostre seus livros como cartões ou lista.',
  cards: 'Cartões', list: 'Lista', gridSize: 'Tamanho da grade', gridHint: 'Menos colunas deixam os cartões maiores.',
  language: 'Idioma', languageHint: 'Escolha o idioma do app.',
  protectedLabel: 'Protegido',
  nPages: (p) => (p.n === 1 ? '1 página' : `${p.n} páginas`),
  nBooks: (p) => (p.n === 1 ? '1 livro' : `${p.n} livros`),
  nImages: (p) => (p.n === 1 ? '1 imagem' : `${p.n} imagens`),
  pageFail: 'Não foi possível exibir esta página', fileOpenFail: 'Não foi possível abrir este arquivo.',
  goToPage: 'Ir para a página', enterPage: (p) => `Digite uma página de 1 a ${p.total}.`,
  wrongPassword: 'Senha incorreta', passwordRequired: 'Senha necessária', tryAgain: 'Tente novamente.',
  pdfProtected: 'Este PDF é protegido.', password: 'Senha', enterPassword: 'Digite a senha.',
  defaultPdfName: 'Imagens', cancelled: 'Cancelado', createFail: 'Não foi possível criar o PDF. Tente menos imagens ou imagens menores.',
  noImagesT: 'Ainda não há imagens', noImagesX: 'Toque em + para escolher imagens JPG, PNG ou WebP.',
  reorderHint: 'Arraste a alça ⋮⋮ para reordenar. Gire ou remova imagens antes de criar o PDF.',
  createPdf: 'Criar PDF', pdfOptions: 'Opções do PDF', pageSize: 'Tamanho da página', imageSize: 'Tamanho da imagem', margins: 'Margens',
  mSmall: 'Pequenas', mMedium: 'Médias', quality: 'Qualidade', qHigh: 'Alta', qMedium: 'Média', qLow: 'Baixa', fileName: 'Nome do arquivo',
  creating: 'Criando PDF', imageXofY: (p) => `Imagem ${p.x} de ${p.y}`, pdfCreated: 'PDF criado', saving: 'Salvando…',
  unsupported1: (p) => `«${p.name}» não é uma imagem compatível (use JPG, PNG ou WebP).`,
  unsupportedN: (p) => `${p.n} arquivos não são imagens compatíveis e foram ignorados (use JPG, PNG ou WebP).`,
  convFail: 'A conversão falhou. Tente uma resolução menor ou menos páginas.',
  pagesPlaceholder: 'Páginas, ex.: 1-5, 8, 10-12', firstNPlaceholder: (p) => `Primeiras N páginas (1–${p.total})`,
  numberRange: (p) => `Digite um número de 1 a ${p.total}.`,
  nOfTotalSelected: (p) => `${p.n} de ${p.total} páginas selecionadas`,
  exportOptions: 'Opções de exportação', format: 'Formato', resolution: 'Resolução',
  heavyWarn: (p) => `${p.n} páginas a ${p.dpi} DPI geram muitos dados. Pode ficar lento e usar muita memória e armazenamento. Reduza a resolução se a conversão falhar.`,
  onePageHint: 'Uma página é salva como uma única imagem.', severalHint: 'Várias páginas são salvas juntas em um arquivo ZIP.',
  convertN: (p) => (p.n === 1 ? 'Converter 1 página' : `Converter ${p.n} páginas`),
  converting: 'Convertendo', pageXofY: (p) => `Página ${p.x} de ${p.y}`, imageReady: 'Imagem pronta',
  imagesReady: (p) => `${p.n} imagens prontas`, saveToDevice: 'Salvar no dispositivo', convertMore: 'Converter mais',
  rangeBad: (p) => `«${p.part}» não é uma página ou intervalo válido.`,
  rangeBounds: (p) => `As páginas devem estar entre 1 e ${p.total}.`,
  rangeBack: (p) => `O intervalo «${p.part}» está invertido. Escreva como ${p.rev}.`,
  wentWrong: 'Algo deu errado. Tente novamente.', screenCrash: 'Algo deu errado nesta tela.',
};

const fr: Partial<Record<Key, V>> = {
  cancel: 'Annuler', close: 'Fermer', back: 'Retour', done: 'Terminé', open: 'Ouvrir', save: 'Enregistrer', delete: 'Supprimer', create: 'Créer',
  retry: 'Réessayer', go: 'Aller', select: 'Sélectionner', all: 'Tout', none: 'Aucune', invert: 'Inverser', odd: 'Impaires', even: 'Paires', convert: 'Convertir',
  enterName: 'Saisissez un nom.',
  loadFail: 'Impossible de charger votre bibliothèque.',
  storageFull: 'Le stockage est plein. Libérez de l’espace puis réessayez.',
  notPdf: (p) => `« ${p.name} » n’est pas un PDF valide et a été ignoré.`,
  importedN: (p) => (p.n === 1 ? '1 livre importé' : `${p.n} livres importés`),
  renameBook: 'Renommer le livre', bookExists: 'Un livre portant ce nom existe déjà.',
  deleteBookQ: 'Supprimer ce livre ?', deleteBooksQ: (p) => `Supprimer ${p.n} livres ?`,
  deleteMsg: 'Cela supprime la copie stockée dans l’app. Vos fichiers d’origine sur l’appareil ne sont pas touchés.',
  deleted: 'Supprimé',
  saveFail: 'Impossible d’enregistrer le fichier.', savedTo: (p) => `Enregistré dans ${p.path}`, chooseSave: 'Choisissez où enregistrer le fichier', downloadStarted: 'Téléchargement lancé',
  newFolder: 'Nouveau dossier', folderName: 'Nom du dossier', folderExists: 'Un dossier portant ce nom existe déjà.',
  renameFolder: 'Renommer le dossier', deleteFolderQ: 'Supprimer ce dossier ?',
  deleteFolderMsg: 'Les livres qu’il contient sont conservés ; ils n’appartiennent simplement plus à un dossier.', deleteFolder: 'Supprimer le dossier',
  emptyBooksT: 'Aucun livre pour le moment', emptyBooksX: 'Appuyez sur + pour importer des PDF. Chacun est copié dans l’app.',
  emptyFoldersT: 'Aucun dossier pour le moment', emptyFoldersX: 'Appuyez sur + puis choisissez « Nouveau dossier » pour organiser vos livres.',
  emptyFolderT: 'Ce dossier est vide', emptyFolderX: 'Appuyez sur + pour ajouter des livres de votre bibliothèque.',
  tabFiles: 'Fichiers', tabFolders: 'Dossiers',
  importPdfs: 'Importer des PDF', imagesToPdf: 'Images vers PDF', pdfToImages: 'PDF vers images',
  menuRename: 'Renommer', menuMove: 'Déplacer vers un dossier', menuSave: 'Enregistrer une copie sur l’appareil', menuConvert: 'Convertir en images',
  moveToFolder: 'Déplacer vers un dossier', noFolder: 'Aucun dossier', moved: 'Déplacé', movedTo: (p) => `Déplacé vers ${p.name}`,
  noFoldersHint: 'Vous n’avez pas encore de dossier. Créez-en un avec le bouton +.',
  addToFolder: 'Ajouter des livres à ce dossier', allInFolder: 'Tous vos livres sont déjà dans ce dossier.',
  addN: (p) => `Ajouter ${p.n}`, addedN: (p) => (p.n === 1 ? '1 livre ajouté' : `${p.n} livres ajoutés`),
  choosePdf: 'Choisissez un PDF à convertir', importFirst: 'Importez d’abord un PDF.',
  nSelected: (p) => (p.n === 1 ? '1 sélectionné' : `${p.n} sélectionnés`), importingXofY: (p) => `Importation ${p.x} sur ${p.y}`,
  settings: 'Réglages', theme: 'Thème', themeHint: 'Clair : fond blanc, texte noir. Sombre : fond noir, texte blanc.',
  light: 'Clair', dark: 'Sombre', filesView: 'Affichage des fichiers', filesViewHint: 'Affichez vos livres en cartes ou en liste.',
  cards: 'Cartes', list: 'Liste', gridSize: 'Taille de la grille', gridHint: 'Moins de colonnes donnent des cartes plus grandes.',
  language: 'Langue', languageHint: 'Choisissez la langue de l’app.',
  protectedLabel: 'Protégé',
  nPages: (p) => (p.n === 1 ? '1 page' : `${p.n} pages`),
  nBooks: (p) => (p.n === 1 ? '1 livre' : `${p.n} livres`),
  nImages: (p) => (p.n === 1 ? '1 image' : `${p.n} images`),
  pageFail: 'Impossible d’afficher cette page', fileOpenFail: 'Impossible d’ouvrir ce fichier.',
  goToPage: 'Aller à la page', enterPage: (p) => `Saisissez une page de 1 à ${p.total}.`,
  wrongPassword: 'Mot de passe incorrect', passwordRequired: 'Mot de passe requis', tryAgain: 'Réessayez.',
  pdfProtected: 'Ce PDF est protégé.', password: 'Mot de passe', enterPassword: 'Saisissez le mot de passe.',
  defaultPdfName: 'Images', cancelled: 'Annulé', createFail: 'Impossible de créer le PDF. Essayez avec moins d’images ou des images plus petites.',
  noImagesT: 'Aucune image pour le moment', noImagesX: 'Appuyez sur + pour choisir des images JPG, PNG ou WebP.',
  reorderHint: 'Faites glisser la poignée ⋮⋮ pour réordonner. Faites pivoter ou retirez des images avant de créer le PDF.',
  createPdf: 'Créer le PDF', pdfOptions: 'Options du PDF', pageSize: 'Taille de page', imageSize: 'Taille de l’image', margins: 'Marges',
  mSmall: 'Petites', mMedium: 'Moyennes', quality: 'Qualité', qHigh: 'Haute', qMedium: 'Moyenne', qLow: 'Basse', fileName: 'Nom du fichier',
  creating: 'Création du PDF', imageXofY: (p) => `Image ${p.x} sur ${p.y}`, pdfCreated: 'PDF créé', saving: 'Enregistrement…',
  unsupported1: (p) => `« ${p.name} » n’est pas une image prise en charge (utilisez JPG, PNG ou WebP).`,
  unsupportedN: (p) => `${p.n} fichiers ne sont pas des images prises en charge et ont été ignorés (utilisez JPG, PNG ou WebP).`,
  convFail: 'Échec de la conversion. Essayez une résolution plus basse ou moins de pages.',
  pagesPlaceholder: 'Pages, p. ex. 1-5, 8, 10-12', firstNPlaceholder: (p) => `N premières pages (1–${p.total})`,
  numberRange: (p) => `Saisissez un nombre de 1 à ${p.total}.`,
  nOfTotalSelected: (p) => `${p.n} sur ${p.total} pages sélectionnées`,
  exportOptions: 'Options d’exportation', format: 'Format', resolution: 'Résolution',
  heavyWarn: (p) => `${p.n} pages à ${p.dpi} DPI représentent beaucoup de données. Cela peut être lent et utiliser beaucoup de mémoire et de stockage. Baissez la résolution si la conversion échoue.`,
  onePageHint: 'Une seule page est enregistrée comme une image unique.', severalHint: 'Plusieurs pages sont enregistrées ensemble dans un fichier ZIP.',
  convertN: (p) => (p.n === 1 ? 'Convertir 1 page' : `Convertir ${p.n} pages`),
  converting: 'Conversion en cours', pageXofY: (p) => `Page ${p.x} sur ${p.y}`, imageReady: 'Image prête',
  imagesReady: (p) => `${p.n} images prêtes`, saveToDevice: 'Enregistrer sur l’appareil', convertMore: 'Convertir d’autres',
  rangeBad: (p) => `« ${p.part} » n’est pas une page ou une plage valide.`,
  rangeBounds: (p) => `Les pages doivent être comprises entre 1 et ${p.total}.`,
  rangeBack: (p) => `La plage « ${p.part} » est inversée. Écrivez-la ainsi : ${p.rev}.`,
  wentWrong: 'Une erreur s’est produite. Réessayez.', screenCrash: 'Une erreur s’est produite sur cet écran.',
};

const dicts: Record<Lang, Partial<Record<Key, V>>> = { en, ar, zh, es, pt, fr };

// ---------------------------------------------------------------- state
const KEY = 'mybooks.lang';
const isLang = (v: unknown): v is Lang => LANGS.some((l) => l.code === v);
const stored = (): Lang | null => {
  try {
    const v = localStorage.getItem(KEY);
    return isLang(v) ? v : null;
  } catch {
    return null;
  }
};
const detect = (): Lang => {
  const n = (navigator.language || 'en').slice(0, 2).toLowerCase();
  return isLang(n) ? n : 'en';
};

let current: Lang = stored() ?? detect();
const listeners = new Set<() => void>();

function apply() {
  const l = LANGS.find((x) => x.code === current)!;
  document.documentElement.lang = current === 'zh' ? 'zh-Hans' : current;
  document.documentElement.dir = l.rtl ? 'rtl' : 'ltr';
}
apply();

export const getLang = () => current;
export const hasChosenLang = () => stored() !== null;
export const isRTL = () => LANGS.find((x) => x.code === current)!.rtl;

export function setLang(code: Lang) {
  current = code;
  try {
    localStorage.setItem(KEY, code);
  } catch {
    /* ignore */
  }
  apply();
  listeners.forEach((f) => f());
}

/** Re-renders the component whenever the language changes. */
export function useLang(): Lang {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => current,
  );
}

export function t(key: Key, p?: Record<string, any>): string {
  const v = (dicts[current][key] ?? en[key]) as V;
  return typeof v === 'function' ? v(p ?? {}) : v;
}
