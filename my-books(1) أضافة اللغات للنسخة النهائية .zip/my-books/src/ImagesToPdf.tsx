import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, Reorder, motion, useDragControls } from 'framer-motion';
import { FileRec, uid } from './db';
import { Cancelled, ImgItem, imageThumb, imagesToPdf, PdfOpts } from './convert';
import { fmtSize } from './pdf';
import { useBack } from './back';
import { Icon, PressButton, Segmented, Sheet } from './ui';
import { t } from './i18n';

const defaultName = () => `${t('defaultPdfName')} ${new Date().toISOString().slice(0, 10)}`;

function Row({ it, i, onRotate, onDelete }: { it: ImgItem; i: number; onRotate: () => void; onDelete: () => void }) {
  const controls = useDragControls();
  return (
    <Reorder.Item value={it} dragListener={false} dragControls={controls} className="irow" whileDrag={{ scale: 1.03, zIndex: 5, boxShadow: '0 14px 32px rgba(0,0,0,0.35)' }}>
      <div className="inum">{i + 1}</div>
      <div className="ithumb"><img src={it.thumb} alt="" draggable={false} style={{ transform: `rotate(${it.rot}deg)` }} /></div>
      <div className="rtext">
        <div className="cname">{it.file.name}</div>
        <div className="cmeta">{fmtSize(it.file.size)}</div>
      </div>
      <PressButton className="ib" aria-label="Rotate" onClick={onRotate}><Icon n="rotate" /></PressButton>
      <PressButton className="ib" aria-label="Remove" onClick={onDelete}><Icon n="trash" /></PressButton>
      <div className="handle" aria-label="Drag to reorder" onPointerDown={(e) => controls.start(e)} style={{ touchAction: 'none' }}><Icon n="grip" sw={3.5} /></div>
    </Reorder.Item>
  );
}

export default function ImagesToPdf({ initial, onClose, onCreate, onOpen, onSave, say }: {
  initial: File[];
  onClose: () => void;
  onCreate: (file: File) => Promise<FileRec | null>;
  onOpen: (rec: FileRec) => void;
  onSave: (rec: FileRec) => Promise<void> | void;
  say: (m: string) => void;
}) {
  const [items, setItems] = useState<ImgItem[]>([]);
  const [adding, setAdding] = useState(false);
  const [phase, setPhase] = useState<'edit' | 'working' | 'done'>('edit');
  const [prog, setProg] = useState(0);
  const [total, setTotal] = useState(0);
  const [sheet, setSheet] = useState(false);
  const [opts, setOpts] = useState<PdfOpts>({ size: 'a4', margin: 18, quality: 'high' });
  const [name, setName] = useState(defaultName());
  const [result, setResult] = useState<FileRec | null>(null);
  const [saving, setSaving] = useState(false);
  const [opening, setOpening] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const cancel = useRef(false);
  const itemsRef = useRef<ImgItem[]>([]);
  itemsRef.current = items;

  useBack(true, () => {
    if (phase === 'working') cancel.current = true;
    else onClose();
  });

  const addFiles = async (list: File[]) => {
    if (!list.length) return;
    setAdding(true);
    const bad: string[] = [];
    for (const f of list) {
      try {
        const thumb = await imageThumb(f);
        setItems((p) => [...p, { id: uid(), file: f, thumb, rot: 0 }]);
      } catch {
        bad.push(f.name);
      }
    }
    setAdding(false);
    if (bad.length) say(bad.length === 1 ? t('unsupported1', { name: bad[0] }) : t('unsupportedN', { n: bad.length }));
  };

  useEffect(() => {
    addFiles(initial);
    return () => itemsRef.current.forEach((i) => URL.revokeObjectURL(i.thumb));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const rotate = (id: string) => setItems((p) => p.map((x) => (x.id === id ? { ...x, rot: (x.rot + 90) % 360 } : x)));
  const remove = (id: string) =>
    setItems((p) => {
      const it = p.find((x) => x.id === id);
      if (it) URL.revokeObjectURL(it.thumb);
      return p.filter((x) => x.id !== id);
    });

  const create = async () => {
    const list = items;
    setSheet(false);
    setTotal(list.length);
    setProg(0);
    cancel.current = false;
    setPhase('working');
    await new Promise<void>((r) => requestAnimationFrame(() => setTimeout(r, 60)));
    try {
      const blob = await imagesToPdf(list, opts, setProg, () => cancel.current);
      const fname = (name.trim() || t('defaultPdfName')).replace(/\.pdf$/i, '') + '.pdf';
      const rec = await onCreate(new File([blob], fname, { type: 'application/pdf' }));
      if (!rec) {
        setPhase('edit');
        return;
      }
      setResult(rec);
      setPhase('done');
    } catch (e) {
      say(e instanceof Cancelled ? t('cancelled') : t('createFail'));
      setPhase('edit');
    }
  };

  return (
    <>
      <header className="hdr">
        <PressButton className="ib" aria-label="Back" onClick={onClose}><Icon n="back" /></PressButton>
        <div className="title small">{t('imagesToPdf')}</div>
        <PressButton className="ib" aria-label="Add images" onClick={() => input.current?.click()}><Icon n="plus" size={26} /></PressButton>
      </header>

      <main className="pane">
        {items.length === 0 ? (
          adding ? (
            <div className="empty"><div className="spin" /></div>
          ) : (
            <div className="empty">
              <div className="eico"><Icon n="image" size={40} sw={1.6} /></div>
              <h3>{t('noImagesT')}</h3>
              <p>{t('noImagesX')}</p>
            </div>
          )
        ) : (
          <>
            <p className="hint">{t('reorderHint')}</p>
            <Reorder.Group axis="y" values={items} onReorder={setItems} className="ilist">
              {items.map((it, i) => <Row key={it.id} it={it} i={i} onRotate={() => rotate(it.id)} onDelete={() => remove(it.id)} />)}
            </Reorder.Group>
            {adding && <div className="empty" style={{ padding: 16 }}><div className="spin" /></div>}
          </>
        )}
      </main>

      <div className="actbar">
        <div className="grow">{t('nImages', { n: items.length })}</div>
        <PressButton className="dbtn primary" disabled={!items.length || adding} onClick={() => setSheet(true)}>{t('createPdf')}</PressButton>
      </div>

      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={(e) => {
        const list = Array.from(e.target.files || []);
        e.target.value = '';
        addFiles(list);
      }} />

      {phase === 'edit' && (
      <AnimatePresence>
        {sheet && (
          <Sheet key="opts" title={t('pdfOptions')} onClose={() => setSheet(false)}>
            <div className="flabel">{t('pageSize')}</div>
            <Segmented value={opts.size} onChange={(v) => setOpts({ ...opts, size: v })} options={[{ v: 'a4', label: 'A4' }, { v: 'original', label: t('imageSize') }]} />
            <div className="flabel">{t('margins')}</div>
            <Segmented value={opts.margin} onChange={(v) => setOpts({ ...opts, margin: v })} options={[{ v: 0, label: t('none') }, { v: 18, label: t('mSmall') }, { v: 36, label: t('mMedium') }]} />
            <div className="flabel">{t('quality')}</div>
            <Segmented value={opts.quality} onChange={(v) => setOpts({ ...opts, quality: v })} options={[{ v: 'high', label: t('qHigh') }, { v: 'medium', label: t('qMedium') }, { v: 'low', label: t('qLow') }]} />
            <div className="flabel">{t('fileName')}</div>
            <input className="dinput plain" value={name} onChange={(e) => setName(e.target.value)} />
            <PressButton className="dbtn primary wide" style={{ marginTop: 18 }} onClick={create}>{t('createPdf')}</PressButton>
          </Sheet>
        )}
      </AnimatePresence>
      )}

      {phase === 'working' && (
        <div className="veil">
          <div className="wcard">
            <div className="dtitle">{t('creating')}</div>
            <p className="dmsg">{t('imageXofY', { x: Math.min(prog + 1, total), y: total })}</p>
            <div className="track"><motion.div className="bar" animate={{ width: `${total ? (prog / total) * 100 : 0}%` }} /></div>
            <PressButton className="dbtn wide" onClick={() => (cancel.current = true)}>{t('cancel')}</PressButton>
          </div>
        </div>
      )}

      {phase === 'done' && result && (
        <div className="veil">
          <motion.div className="wcard" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: 'spring', stiffness: 380, damping: 30 }}>
            <div className="okico"><Icon n="check" size={30} sw={3} /></div>
            <div className="dtitle">{t('pdfCreated')}</div>
            <p className="dmsg">{result.name} · {t('nPages', { n: result.pages })} · {fmtSize(result.size)}</p>
            <PressButton className="dbtn primary wide" disabled={opening} onClick={() => { if (opening) return; setOpening(true); onOpen(result); }}>{t('open')}</PressButton>
            <PressButton className="dbtn wide" disabled={saving} onClick={async () => {
              if (saving) return;
              setSaving(true);
              try {
                await Promise.race([Promise.resolve(onSave(result)), new Promise((r) => setTimeout(r, 8000))]);
              } finally {
                setSaving(false);
              }
            }}>{saving ? t('saving') : t('menuSave')}</PressButton>
            <PressButton className="dbtn wide" onClick={onClose}>{t('done')}</PressButton>
          </motion.div>
        </div>
      )}
    </>
  );
}
