import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';

const ICON = import.meta.env.BASE_URL + 'icon.png';
const LETTERS = 'MY BOOKS'.split('');

// "BOOKS" fades from blue to violet, matching the app's accent gradient.
const A = [61, 139, 255];
const B = [123, 77, 255];
const lerp = (a: number, b: number, t: number) => Math.round(a + (b - a) * t);
const colorOf = (i: number) => {
  if (i < 2) return '#ffffff';
  const t = (i - 3) / 4;
  return `rgb(${lerp(A[0], B[0], t)}, ${lerp(A[1], B[1], t)}, ${lerp(A[2], B[2], t)})`;
};

// Fixed pseudo-random sparkle field (same every launch, no layout cost).
const sparks = Array.from({ length: 16 }, (_, i) => {
  const r = (n: number) => {
    const x = Math.sin(i * 12.9898 + n * 78.233) * 43758.5453;
    return x - Math.floor(x);
  };
  return { x: 6 + r(1) * 88, y: 52 + r(2) * 40, s: 2 + r(3) * 3.5, d: 0.35 + r(4) * 1.1, t: 1.5 + r(5) * 1.2, rise: 90 + r(6) * 140, blue: r(7) > 0.5 };
});

export default function Splash({ onDone, onLeave }: { onDone: () => void; onLeave?: () => void }) {
  const reduce = useReducedMotion();
  const [leaving, setLeaving] = useState(false);
  const d = (s: number) => (reduce ? 0 : s);
  const done = useRef(onDone);
  done.current = onDone;

  // The black cover from index.html hands over to this splash without a flash.
  useLayoutEffect(() => {
    document.getElementById('boot')?.remove();
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setLeaving(true), reduce ? 900 : 2100);
    // Hard failsafe: the splash can never stay on screen, whatever happens to the animations.
    const hard = setTimeout(() => done.current(), reduce ? 2000 : 3600);
    return () => {
      clearTimeout(t);
      clearTimeout(hard);
    };
  }, [reduce]);

  useEffect(() => {
    if (!leaving) return;
    onLeave?.();
    const t = setTimeout(() => done.current(), 700);
    return () => clearTimeout(t);
  }, [leaving]);

  return (
    <motion.div
      className="splash"
      dir="ltr"
      initial={false}
      animate={{ opacity: leaving ? 0 : 1, scale: leaving ? 1.05 : 1 }}
      transition={{ duration: 0.5, ease: 'easeInOut' }}
      onAnimationComplete={() => leaving && onDone()}
      onClick={() => setLeaving(true)}
    >
      <motion.div className="orb o1" initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: [0, 0.9, 0.65], scale: [0.6, 1.15, 1], x: [0, 24, 0] }} transition={{ duration: 2.4, ease: 'easeOut' }} />
      <motion.div className="orb o2" initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: [0, 0.85, 0.6], scale: [0.6, 1.1, 1], x: [0, -24, 0] }} transition={{ duration: 2.4, delay: 0.15, ease: 'easeOut' }} />

      {!reduce && sparks.map((p, i) => (
        <motion.span
          key={i}
          className={'spark' + (p.blue ? '' : ' v')}
          style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.s, height: p.s }}
          initial={{ opacity: 0, y: 0, scale: 0.5 }}
          animate={{ opacity: [0, 1, 0], y: -p.rise, scale: [0.5, 1, 0.4] }}
          transition={{ delay: p.d, duration: p.t, ease: 'easeOut' }}
        />
      ))}

      <div className="scenter">
        <div className="sicon">
          {!reduce && [0, 1].map((k) => (
            <motion.span key={k} className="ring" initial={{ opacity: 0, scale: 1 }} animate={{ opacity: [0, 0.65, 0], scale: [1, 2.1] }} transition={{ delay: 0.5 + k * 0.45, duration: 1.3, ease: 'easeOut' }} />
          ))}
          <motion.div className="sbox" initial={{ opacity: 0, scale: 0.2, rotate: -16 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ delay: d(0.1), type: 'spring', stiffness: 210, damping: 15 }}>
            <img src={ICON} alt="" draggable={false} />
            {!reduce && <motion.span className="sheen" initial={{ x: '-140%' }} animate={{ x: '140%' }} transition={{ delay: 0.85, duration: 0.9, ease: 'easeInOut' }} />}
          </motion.div>
        </div>

        <div className="sname" aria-label="MY BOOKS">
          {LETTERS.map((ch, i) =>
            ch === ' ' ? (
              <span key={i} className="sl sp" />
            ) : (
              <motion.span
                key={i}
                className="sl"
                style={{ color: colorOf(i) }}
                initial={{ opacity: 0, y: 26, scale: 0.85 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: d(0.55 + i * 0.06), type: 'spring', stiffness: 260, damping: 18 }}
              >
                {ch}
              </motion.span>
            ),
          )}
        </div>
        <motion.div className="sline" initial={{ scaleX: 0, opacity: 0 }} animate={{ scaleX: 1, opacity: 1 }} transition={{ delay: d(1.15), duration: 0.6, ease: 'easeOut' }} />
      </div>
    </motion.div>
  );
}
