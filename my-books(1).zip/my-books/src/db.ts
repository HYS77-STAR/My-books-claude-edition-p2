import { openDB, IDBPDatabase } from 'idb';

export interface FileRec {
  id: string;
  name: string;
  size: number;
  pages: number;
  thumb: Blob | null;
  folderId: string | null;
  addedAt: number;
  lastPage: number;
  encrypted: boolean;
}
export interface FolderRec {
  id: string;
  name: string;
  createdAt: number;
}

// Big PDF blobs live in their own store so listing the library never loads them.
let dbp: Promise<IDBPDatabase> | null = null;
function db() {
  if (!dbp) {
    dbp = openDB('mybooks', 1, {
      upgrade(d) {
        d.createObjectStore('files', { keyPath: 'id' });
        d.createObjectStore('blobs', { keyPath: 'id' });
        d.createObjectStore('folders', { keyPath: 'id' });
      },
    });
  }
  return dbp;
}

export const uid = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : Date.now().toString(36) + Math.random().toString(36).slice(2);

export async function getFiles(): Promise<FileRec[]> {
  return (await db()).getAll('files');
}
export async function getFolders(): Promise<FolderRec[]> {
  return (await db()).getAll('folders');
}
export async function addFile(rec: FileRec, blob: Blob) {
  const d = await db();
  const tx = d.transaction(['files', 'blobs'], 'readwrite');
  await tx.objectStore('blobs').put({ id: rec.id, blob });
  await tx.objectStore('files').put(rec);
  await tx.done;
}
export async function getBlob(id: string): Promise<Blob | null> {
  const r = await (await db()).get('blobs', id);
  return r ? r.blob : null;
}
export async function updateFile(id: string, patch: Partial<FileRec>) {
  const d = await db();
  const tx = d.transaction('files', 'readwrite');
  const cur = await tx.store.get(id);
  if (cur) await tx.store.put({ ...cur, ...patch });
  await tx.done;
}
export async function deleteFiles(ids: string[]) {
  const d = await db();
  const tx = d.transaction(['files', 'blobs'], 'readwrite');
  for (const id of ids) {
    tx.objectStore('files').delete(id);
    tx.objectStore('blobs').delete(id);
  }
  await tx.done;
}
export async function setFolder(ids: string[], folderId: string | null) {
  const d = await db();
  const tx = d.transaction('files', 'readwrite');
  for (const id of ids) {
    const cur = await tx.store.get(id);
    if (cur) await tx.store.put({ ...cur, folderId });
  }
  await tx.done;
}
export async function addFolder(name: string) {
  const rec: FolderRec = { id: uid(), name, createdAt: Date.now() };
  await (await db()).put('folders', rec);
  return rec;
}
export async function renameFolder(id: string, name: string) {
  const d = await db();
  const cur = await d.get('folders', id);
  if (cur) await d.put('folders', { ...cur, name });
}
// Deleting a folder never deletes its files: they just become unfiled.
export async function deleteFolder(id: string) {
  const d = await db();
  const tx = d.transaction(['files', 'folders'], 'readwrite');
  let c = await tx.objectStore('files').openCursor();
  while (c) {
    if (c.value.folderId === id) await c.update({ ...c.value, folderId: null });
    c = await c.continue();
  }
  tx.objectStore('folders').delete(id);
  await tx.done;
}
