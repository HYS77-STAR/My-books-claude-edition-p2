import * as pdfjs from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

// Worker is bundled locally: no CDN, works offline.
pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

export type PDFDoc = pdfjs.PDFDocumentProxy;
export class NeedPassword extends Error {}

const assets = () => new URL('pdfjs/', document.baseURI).href;

export async function openPdf(
  blob: Blob,
  askPassword?: (wrong: boolean) => Promise<string | null>,
): Promise<PDFDoc> {
  // pdf.js transfers the buffer to its worker, so every open needs a fresh copy.
  const data = new Uint8Array(await blob.arrayBuffer());
  const task = pdfjs.getDocument({
    data,
    cMapUrl: assets() + 'cmaps/',
    cMapPacked: true,
    standardFontDataUrl: assets() + 'standard_fonts/',
  });
  let cancelled = false;
  task.onPassword = (update: (pw: string) => void, reason: number) => {
    if (!askPassword) {
      cancelled = true;
      task.destroy();
      return;
    }
    askPassword(reason === 2).then((pw) => {
      if (pw == null) {
        cancelled = true;
        task.destroy();
      } else update(pw);
    });
  };
  try {
    return await task.promise;
  } catch (e) {
    if (cancelled) throw new NeedPassword();
    throw e;
  }
}

export async function makeThumb(doc: PDFDoc): Promise<Blob | null> {
  const page = await doc.getPage(1);
  const v0 = page.getViewport({ scale: 1 });
  const vp = page.getViewport({ scale: 360 / v0.width });
  const c = document.createElement('canvas');
  c.width = Math.floor(vp.width);
  c.height = Math.floor(vp.height);
  const ctx = c.getContext('2d');
  if (!ctx) return null;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  page.cleanup();
  const blob = await new Promise<Blob | null>((res) => c.toBlob((b) => res(b), 'image/jpeg', 0.8));
  c.width = 0;
  return blob;
}

export function fmtSize(n: number) {
  if (n < 1024 * 1024) return Math.max(1, Math.round(n / 1024)) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
  return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB';
}
