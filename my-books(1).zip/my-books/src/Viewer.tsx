import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { FileRec, getBlob, updateFile } from './db';
import { NeedPassword, openPdf, PDFDoc } from './pdf';
import { Dialog, Icon, PressButton } from './ui';
import { useBack } from './back';
import { t } from './i18n';

const GAP = 10;
const SIDE = 16;
const MAX_PIXELS = 12_000_000; // caps canvas memory on weak phones

function PageView({ doc, n, width, ratio, root }: { doc: PDFDoc; n: number; width: number; ratio: number; root: RefObject<HTMLDivElement> }) {
  const wrap = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const [vis, setVis] = useState(false);
  const [err, setErr] = useState(false);
  const [tick, setTick] = useState(0);

  // Only pages near the screen are rendered; the rest release their canvas memory.
  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVis(e.isIntersecting), { root: root.current, rootMargin: '120% 0px' });
    io.observe(el);
    return () => io.disconnect();
  }, [root]);

  useEffect(() => {
    const c = cv.current;
    if (!c) return;
    if (!vis) {
      c.width = 0;
      c.height = 0;
      return;
    }
    if (width < 10) return;
    let dead = false;
    let task: any = null;
    (async () => {
      try {
        setErr(false);
        const page = await doc.getPage(n);
        if (dead) return;
        const base = page.getViewport({ scale: 1 });
        let pr = Math.min(window.devicePixelRatio || 1, 3);
        const h = (width * base.height) / base.width;
        const px = width * pr * h * pr;
        if (px > MAX_PIXELS) pr *= Math.sqrt(MAX_PIXELS / px);
        const vp = page.getViewport({ scale: (width / base.width) * pr });
        // Render off-screen first, then swap: no blank flash when zooming.
        const off = document.createElement('canvas');
        off.width = Math.floor(vp.width);
        off.height = Math.floor(vp.height);
        const ctx = off.getContext('2d');
        if (!ctx) throw new Error('canvas');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, off.width, off.height);
        task = page.render({ canvasContext: ctx, viewport: vp });
        await task.promise;
        if (dead) return;
        c.width = off.width;
        c.height = off.height;
        c.getContext('2d')!.drawImage(off, 0, 0);
        off.width = 0;
        page.cleanup();
      } catch (e: any) {
        if (!dead && e?.name !== 'RenderingCancelledException') setErr(true);
      }
    })();
    return () => {
      dead = true;
      try {
        task?.cancel();
      } catch {
        /* ignore */
      }
    };
  }, [vis, width, doc, n, tick]);

  return (
    <div ref={wrap} className="page" style={{ width, height: width * ratio }}>
      <canvas ref={cv} style={{ width: '100%', height: '100%' }} />
      {err && (
        <div className="perr">
          <span>{t('pageFail')}</span>
          <button onClick={() => setTick((n) => n + 1)}>{t('retry')}</button>
        </div>
      )}
    </div>
  );
}

export default function Viewer({ file, onClose }: { file: FileRec; onClose: () => void }) {
  const [doc, setDoc] = useState<PDFDoc | null>(null);
  const [ratios, setRatios] = useState<number[] | null>(null);
  const [fail, setFail] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [ui, setUi] = useState(true);
  const [cur, setCur] = useState(Math.max(1, file.lastPage || 1));
  const [w, setW] = useState(0);
  const [pw, setPw] = useState<null | { id: number; wrong: boolean; resolve: (v: string | null) => void }>(null);
  const [jump, setJump] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const pageEls = useRef<HTMLDivElement[]>([]);
  const zoomRef = useRef(1);
  zoomRef.current = zoom;
  const focus = useRef<{ fx: number; fy: number; ratio: number; sl: number; st: number } | null>(null);
  const restored = useRef(false);

  useBack(true, () => {
    if (!jump && !pw) onClose();
  });

  // Load the document and every page's size (so the layout never jumps).
  useEffect(() => {
    let dead = false;
    let d: PDFDoc | null = null;
    (async () => {
      try {
        const blob = await getBlob(file.id);
        if (!blob) throw new Error('missing');
        d = await openPdf(blob, (wrong) => new Promise((res) => setPw({ id: Date.now(), wrong, resolve: res })));
        if (dead) {
          d.destroy();
          return;
        }
        const total = d.numPages;
        const r: number[] = new Array(total);
        for (let i = 0; i < total; i += 40) {
          const cnt = Math.min(40, total - i);
          await Promise.all(
            Array.from({ length: cnt }, async (_, k) => {
              const p = await d!.getPage(i + k + 1);
              const v = p.getViewport({ scale: 1 });
              r[i + k] = v.height / v.width;
              p.cleanup();
            }),
          );
          if (dead) return;
        }
        setDoc(d);
        setRatios(r);
      } catch (e) {
        if (dead) return;
        if (e instanceof NeedPassword) onClose();
        else setFail(true);
      }
    })();
    return () => {
      dead = true;
      d?.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file.id]);

  useEffect(() => {
    const s = scroller.current;
    if (!s) return;
    const ro = new ResizeObserver(() => setW(s.clientWidth));
    ro.observe(s);
    setW(s.clientWidth);
    return () => ro.disconnect();
  }, []);

  // Restore the last page once sizes are known.
  useLayoutEffect(() => {
    if (!ratios || !w || restored.current) return;
    restored.current = true;
    const el = pageEls.current[Math.min(cur, ratios.length) - 1];
    if (el && scroller.current) scroller.current.scrollTop = el.offsetTop - 8;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ratios, w]);

  // Keep the pinch/double-tap focus point steady after the zoom changes.
  useLayoutEffect(() => {
    const f = focus.current;
    const s = scroller.current;
    if (!f || !s) return;
    focus.current = null;
    s.scrollLeft = (f.sl + f.fx) * f.ratio - f.fx;
    s.scrollTop = (f.st + f.fy) * f.ratio - f.fy;
  }, [zoom]);

  // Remember the last page.
  useEffect(() => {
    if (!restored.current) return;
    const t = setTimeout(() => updateFile(file.id, { lastPage: cur }).catch(() => {}), 700);
    return () => clearTimeout(t);
  }, [cur, file.id]);

  // Current page from scroll position.
  useEffect(() => {
    const s = scroller.current;
    if (!s || !ratios) return;
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const y = s.scrollTop + s.clientHeight * 0.3;
        const els = pageEls.current;
        let lo = 0;
        let hi = els.length - 1;
        while (lo < hi) {
          const mid = (lo + hi + 1) >> 1;
          if (els[mid] && els[mid].offsetTop <= y) lo = mid;
          else hi = mid - 1;
        }
        setCur(lo + 1);
      });
    };
    s.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      s.removeEventListener('scroll', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [ratios]);

  // Pinch zoom, double-tap zoom, single tap to show/hide the bars.
  useEffect(() => {
    const s = scroller.current;
    const c = content.current;
    if (!s || !c) return;
    let pinching = false, d0 = 1, z0 = 1, live = 1, cx = 0, cy = 0;
    let t0 = 0, x0 = 0, y0 = 0, moved = false, lastTap = 0, lx = 0, ly = 0;
    let single: ReturnType<typeof setTimeout> | undefined;
    const dist = (t: TouchList) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    const commit = (nz: number, fx: number, fy: number) => {
      nz = Math.min(5, Math.max(1, nz));
      const ratio = nz / zoomRef.current;
      if (Math.abs(ratio - 1) < 0.01) return;
      focus.current = { fx, fy, ratio, sl: s.scrollLeft, st: s.scrollTop };
      setZoom(nz);
    };
    const start = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        pinching = true;
        d0 = dist(e.touches) || 1;
        z0 = zoomRef.current;
        live = 1;
        const r = s.getBoundingClientRect();
        cx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left;
        cy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top;
        c.style.transformOrigin = `${cx + s.scrollLeft}px ${cy + s.scrollTop}px`;
        if (single) clearTimeout(single);
      } else if (e.touches.length === 1) {
        t0 = Date.now();
        x0 = e.touches[0].clientX;
        y0 = e.touches[0].clientY;
        moved = false;
      }
    };
    const move = (e: TouchEvent) => {
      if (pinching && e.touches.length === 2) {
        e.preventDefault();
        const target = Math.min(5, Math.max(1, (z0 * dist(e.touches)) / d0));
        live = target / z0;
        c.style.transform = `scale(${live})`;
      } else if (e.touches.length === 1 && Math.hypot(e.touches[0].clientX - x0, e.touches[0].clientY - y0) > 10) {
        moved = true;
      }
    };
    const end = (e: TouchEvent) => {
      if (pinching) {
        if (e.touches.length < 2) {
          pinching = false;
          c.style.transform = '';
          commit(z0 * live, cx, cy);
        }
        return;
      }
      if (e.touches.length === 0 && !moved && Date.now() - t0 < 300) {
        const t = e.changedTouches[0];
        const r = s.getBoundingClientRect();
        const x = t.clientX - r.left;
        const y = t.clientY - r.top;
        if (Date.now() - lastTap < 300 && Math.hypot(x - lx, y - ly) < 40) {
          if (single) clearTimeout(single);
          lastTap = 0;
          commit(zoomRef.current > 1.05 ? 1 : 2.5, x, y);
        } else {
          lastTap = Date.now();
          lx = x;
          ly = y;
          single = setTimeout(() => setUi((v) => !v), 300);
        }
      }
    };
    s.addEventListener('touchstart', start, { passive: true });
    s.addEventListener('touchmove', move, { passive: false });
    s.addEventListener('touchend', end, { passive: true });
    return () => {
      s.removeEventListener('touchstart', start);
      s.removeEventListener('touchmove', move);
      s.removeEventListener('touchend', end);
      if (single) clearTimeout(single);
    };
  }, [ratios]);

  const goTo = (n: number) => {
    if (!ratios) return;
    const p = Math.min(ratios.length, Math.max(1, n));
    const el = pageEls.current[p - 1];
    if (el && scroller.current) scroller.current.scrollTo({ top: el.offsetTop - 8, behavior: 'smooth' });
  };

  const pageW = Math.max(0, Math.floor(w * zoom) - SIDE);
  const total = ratios?.length ?? 0;

  return (
    <div className="viewer-in">
      <div ref={scroller} className="scroller" dir="ltr">
        {doc && ratios && (
          <div ref={content} className="content" style={{ width: w * zoom }}>
            {ratios.map((r, i) => (
              <div key={i} ref={(el) => { if (el) pageEls.current[i] = el; }} className="pagewrap" style={{ marginBottom: GAP }}>
                <PageView doc={doc} n={i + 1} width={pageW} ratio={r} root={scroller} />
              </div>
            ))}
          </div>
        )}
      </div>

      {!doc && !fail && !pw && <div className="center-fill"><div className="spin" /></div>}
      {fail && (
        <div className="center-fill col">
          <p>{t('fileOpenFail')}</p>
          <PressButton className="dbtn primary" onClick={onClose}>{t('back')}</PressButton>
        </div>
      )}

      <AnimatePresence>
        {ui && (
          <motion.div className="vbar" initial={{ y: -70, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -70, opacity: 0 }} transition={{ type: 'spring', stiffness: 420, damping: 36 }}>
            <PressButton className="ib" aria-label="Back" onClick={onClose}><Icon n="back" /></PressButton>
            <div className="vtitle">{file.name}</div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {ui && total > 0 && (
          <motion.button className="pill" dir="ltr" initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }} whileTap={{ scale: 0.94 }} onClick={() => setJump(true)}>
            {cur} / {total}
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {jump && (
          <Dialog
            key="jump"
            spec={{
              title: t('goToPage'),
              input: { type: 'number', placeholder: `1 – ${total}` },
              ok: t('go'),
              onOk: (v) => {
                const n = parseInt(v, 10);
                if (!n || n < 1 || n > total) return t('enterPage', { total });
                goTo(n);
              },
            }}
            onClose={() => setJump(false)}
          />
        )}
        {pw && (
          <Dialog
            key={"pw" + pw.id}
            spec={{
              title: pw.wrong ? t('wrongPassword') : t('passwordRequired'),
              message: pw.wrong ? t('tryAgain') : t('pdfProtected'),
              input: { type: 'password', placeholder: t('password') },
              ok: t('open'),
              onOk: (v) => {
                if (!v) return t('enterPassword');
                pw.resolve(v);
                setPw(null);
              },
              onCancel: () => {
                pw.resolve(null);
                setPw(null);
              },
            }}
            onClose={() => {}}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
