import { useEffect, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';

// Stack of "close" handlers. The Android back button always closes the top-most layer,
// and only exits the app when nothing is open.
const stack: Array<() => void> = [];

function push(fn: () => void) {
  stack.push(fn);
  return () => {
    const i = stack.lastIndexOf(fn);
    if (i >= 0) stack.splice(i, 1);
  };
}

if (Capacitor.isNativePlatform()) {
  try {
    App.addListener('backButton', () => {
      const fn = stack[stack.length - 1];
      if (fn) fn();
      else App.exitApp();
    });
  } catch {
    /* ignore */
  }
}

export function useBack(active: boolean, fn: () => void) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (!active) return;
    return push(() => ref.current());
  }, [active]);
}
