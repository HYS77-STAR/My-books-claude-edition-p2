import { useEffect, useRef, useState } from 'react';
import type { MouseEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import type { FileRec, FolderRec } from './db';
import { fmtSize } from './pdf';
import { t } from './i18n';
import { Icon, PressButton } from './ui';

function useLongPress(onLong: () => void, onTap: () => void) {
  const t = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fired = useRef(false);
  const clear = () => {
    if (t.current) clearTimeout(t.current);
  };
  return {
    onPointerDown: () => {
      fired.current = false;
      clear();
      t.current = setTimeout(() => {
        fired.current = true;
        onLong();
      }, 450);
    },
    onPointerUp: clear,
    onPointerLeave: clear,
    onPointerCancel: clear,
    onClick: () => {
      if (!fired.current) onTap();
    },
    onContextMenu: (e: MouseEvent) => e.preventDefault(),
  };
}

function Thumb({ blob }: { blob: Blob | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!blob) {
      setUrl(null);
      return;
    }
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return url ? <img src={url} alt="" draggable={false} /> : <div className="ph"><Icon n="file" size={28} /></div>;
}

const meta = (f: FileRec) => [f.encrypted ? t('protectedLabel') : f.pages ? t('nPages', { n: f.pages }) : '', fmtSize(f.size)].filter(Boolean).join(' · ');

interface GridProps {
  files: FileRec[];
  view: 'grid' | 'list';
  cols: number;
  sel: Set<string> | null;
  onTap: (f: FileRec) => void;
  onLong: (f: FileRec) => void;
  onMenu: (f: FileRec) => void;
}

function Check({ on }: { on: boolean }) {
  return <div className={'chk' + (on ? ' on' : '')}>{on && <Icon n="check" size={14} sw={3} />}</div>;
}

function FileCard({ f, i, sel, onTap, onLong, onMenu }: { f: FileRec; i: number; sel: Set<string> | null; onTap: () => void; onLong: () => void; onMenu: () => void }) {
  const lp = useLongPress(onLong, onTap);
  const d = Math.min(i, 10) * 0.025;
  return (
    <motion.div
      layout
      className="card"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      whileTap={{ scale: 0.96 }}
      transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: d }, scale: { type: 'spring', stiffness: 400, damping: 28, delay: d } }}
      {...lp}
    >
      <div className={'thumb' + (sel?.has(f.id) ? ' picked' : '')}>
        <Thumb blob={f.thumb} />
        {sel && <Check on={sel.has(f.id)} />}
        {!sel && (
          <button className="more" aria-label="Menu" onClick={(e) => { e.stopPropagation(); onMenu(); }} onPointerDown={(e) => e.stopPropagation()}>
            <Icon n="more" size={20} sw={3.5} />
          </button>
        )}
      </div>
      <div className="cname">{f.name}</div>
      <div className="cmeta">{meta(f)}</div>
    </motion.div>
  );
}

function FileRow({ f, i, sel, onTap, onLong, onMenu }: { f: FileRec; i: number; sel: Set<string> | null; onTap: () => void; onLong: () => void; onMenu: () => void }) {
  const lp = useLongPress(onLong, onTap);
  return (
    <motion.div
      layout
      className={'row' + (sel?.has(f.id) ? ' picked' : '')}
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 40, height: 0 }}
      whileTap={{ scale: 0.98 }}
      transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: Math.min(i, 10) * 0.025 } }}
      {...lp}
    >
      <div className="rthumb"><Thumb blob={f.thumb} /></div>
      <div className="rtext">
        <div className="cname">{f.name}</div>
        <div className="cmeta">{meta(f)}</div>
      </div>
      {sel ? <Check on={sel.has(f.id)} /> : (
        <PressButton className="ib" aria-label="Menu" onClick={(e) => { e.stopPropagation(); onMenu(); }} onPointerDown={(e) => e.stopPropagation()}>
          <Icon n="more" size={22} sw={3.5} />
        </PressButton>
      )}
    </motion.div>
  );
}

export function FileGrid({ files, view, cols, sel, onTap, onLong, onMenu }: GridProps) {
  if (view === 'list') {
    return (
      <div className="list">
        <AnimatePresence initial={false}>
          {files.map((f, i) => <FileRow key={f.id} f={f} i={i} sel={sel} onTap={() => onTap(f)} onLong={() => onLong(f)} onMenu={() => onMenu(f)} />)}
        </AnimatePresence>
      </div>
    );
  }
  return (
    <div className="grid" data-cols={cols} style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gap: cols >= 6 ? 8 : 14 }}>
      <AnimatePresence initial={false}>
        {files.map((f, i) => <FileCard key={f.id} f={f} i={i} sel={sel} onTap={() => onTap(f)} onLong={() => onLong(f)} onMenu={() => onMenu(f)} />)}
      </AnimatePresence>
    </div>
  );
}

export function FolderList({ folders, counts, onOpen }: { folders: FolderRec[]; counts: Record<string, number>; onOpen: (f: FolderRec) => void }) {
  return (
    <div className="list">
      <AnimatePresence initial={false}>
        {folders.map((f, i) => (
          <motion.div
            layout
            key={f.id}
            className="row"
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40, height: 0 }}
            whileTap={{ scale: 0.98 }}
            transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: Math.min(i, 10) * 0.025 } }}
            onClick={() => onOpen(f)}
          >
            <div className="fico"><Icon n="folder" size={26} /></div>
            <div className="rtext">
              <div className="cname">{f.name}</div>
              <div className="cmeta">{t('nBooks', { n: counts[f.id] || 0 })}</div>
            </div>
            <Icon n="open" size={20} />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
