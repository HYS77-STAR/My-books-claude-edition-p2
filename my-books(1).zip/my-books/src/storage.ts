import { Capacitor, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const CHUNK = 768 * 1024; // multiple of 3 so base64 chunks concatenate cleanly; small = light bridge messages

const toB64 = (b: Blob) =>
  new Promise<string>((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1] || '');
    r.onerror = () => rej(r.error);
    r.readAsDataURL(b);
  });

const safeName = (n: string) => n.replace(/[\\/:*?"<>|]+/g, '_').trim() || 'file';

async function writeChunked(path: string, blob: Blob, directory: Directory) {
  let uri = '';
  for (let o = 0; o === 0 || o < blob.size; o += CHUNK) {
    const data = await toB64(blob.slice(o, o + CHUNK));
    if (o > 0) await new Promise<void>((r) => setTimeout(r, 0)); // keep the UI responsive
    if (o === 0) {
      const r = await Filesystem.writeFile({ path, data, directory, recursive: true });
      uri = r.uri;
    } else {
      await Filesystem.appendFile({ path, data, directory });
    }
  }
  return uri;
}

export type SaveResult = { mode: 'saved' | 'shared' | 'download'; path: string };

/** Copies a file (PDF, image or ZIP) out of the app into the device's files. `name` must include its extension. */
export async function saveToDevice(name: string, blob: Blob): Promise<SaveResult> {
  const fname = safeName(name);
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return { mode: 'download', path: fname };
  }
  try {
    await writeChunked(`MyBooks/${fname}`, blob, Directory.Documents);
    return { mode: 'saved', path: `Documents/MyBooks/${fname}` };
  } catch {
    // Some Android versions block direct writes to Documents: fall back to the share sheet.
    const uri = await writeChunked(fname, blob, Directory.Cache);
    await Share.share({ title: fname, url: uri, dialogTitle: 'Save file' });
    return { mode: 'shared', path: fname };
  }
}

// ---------------------------------------------------------------- gallery
// A tiny native plugin (added to the Android project by scripts/patch-android.mjs) writes images
// into Pictures/MY BOOKS through MediaStore, so they appear in the gallery.
interface GallerySaverPlugin {
  save(o: { path: string; name: string; mime: string; album: string }): Promise<{ uri: string }>;
}
const GallerySaver = registerPlugin<GallerySaverPlugin>('GallerySaver');
const ALBUM = 'MY BOOKS';
const tick = () => new Promise<void>((r) => setTimeout(r, 0));

export type GalleryResult = { mode: 'gallery' | 'shared' | 'download' };

/** Saves normal image files (not a ZIP) to the gallery. Falls back to the share sheet if needed. */
export async function saveImagesToGallery(files: { name: string; blob: Blob }[], onProgress: (done: number) => void): Promise<GalleryResult> {
  if (!Capacitor.isNativePlatform()) {
    for (let i = 0; i < files.length; i++) {
      onProgress(i);
      const url = URL.createObjectURL(files[i].blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = safeName(files[i].name);
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      await new Promise((r) => setTimeout(r, 250));
    }
    onProgress(files.length);
    return { mode: 'download' };
  }

  const cached: string[] = []; // cache files that still need saving
  let done = 0;
  try {
    for (let i = 0; i < files.length; i++) {
      onProgress(i);
      await tick();
      const name = safeName(files[i].name);
      const tmp = `gallery-${Date.now()}-${i}-${name}`;
      const uri = await writeChunked(tmp, files[i].blob, Directory.Cache);
      cached.push(uri);
      await GallerySaver.save({ path: uri, name, mime: files[i].blob.type || 'image/png', album: ALBUM });
      await Filesystem.deleteFile({ path: tmp, directory: Directory.Cache }).catch(() => {});
      cached.pop();
      done++;
    }
    onProgress(files.length);
    return { mode: 'gallery' };
  } catch {
    // Native saver not available on this build / old Android: let the user pick where to save.
    for (let i = done + cached.length; i < files.length; i++) {
      const tmp = `gallery-share-${Date.now()}-${i}-${safeName(files[i].name)}`;
      cached.push(await writeChunked(tmp, files[i].blob, Directory.Cache));
    }
    await Share.share({ files: cached, dialogTitle: 'MY BOOKS' });
    return { mode: 'shared' };
  }
}
