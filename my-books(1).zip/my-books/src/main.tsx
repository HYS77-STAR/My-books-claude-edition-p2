import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import './back';

createRoot(document.getElementById('root')!).render(<App />);
