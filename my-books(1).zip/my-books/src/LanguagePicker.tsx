import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { LANGS, Lang, getLang, setLang } from './i18n';
import { Icon, PressButton, spring } from './ui';
import { useBack } from './back';

const container = {
  out: { opacity: 0 },
  in: { opacity: 1, transition: { staggerChildren: 0.08, delayChildren: 0.12 } },
  bye: { opacity: 0, scale: 1.04, transition: { duration: 0.4, ease: 'easeInOut' } },
};
const item = {
  out: { opacity: 0, y: 28, scale: 0.96 },
  in: { opacity: 1, y: 0, scale: 1, transition: spring },
  bye: { opacity: 0 },
};

/**
 * Full-screen language chooser.
 *  - mode "first": shown once, right after the splash, on the very first launch.
 *  - mode "change": opened from Settings (has a back button, nothing changes until you confirm).
 * Every language is written in its own language.
 */
export default function LanguagePicker({ mode, ready, onClose }: { mode: 'first' | 'change'; ready: boolean; onClose: () => void }) {
  const [sel, setSel] = useState<Lang>(getLang());
  const [touched, setTouched] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  const finish = (apply: boolean) => {
    if (leaving) return;
    if (apply) setLang(sel);
    setLeaving(true);
    // Never depends on the exit animation to unmount.
    setTimeout(() => closeRef.current(), 450);
  };

  // First launch: Back does nothing (a choice is needed). From Settings: Back closes without changing.
  useBack(true, () => {
    if (mode === 'change') finish(false);
  });

  // Block scrolling the page behind while this screen is open.
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const cur = LANGS.find((l) => l.code === sel)!;
  const state = leaving ? 'bye' : ready ? 'in' : 'out';

  return (
    <motion.div className="lscreen" dir="ltr" variants={container} initial="out" animate={state}>
      <div className="orb o1 drift" />
      <div className="orb o2 drift" />

      {mode === 'change' && (
        <motion.button className="lback" variants={item} onClick={() => finish(false)} aria-label="Back">
          <Icon n="back" />
        </motion.button>
      )}

      <div className="lcol">
        <motion.div className="lglobe" variants={item}>
          <Icon n="globe" size={34} sw={1.8} />
        </motion.div>

        {/* Until a language is tapped, the title cycles through every language. */}
        <motion.div className="ltitle" variants={item} aria-live="polite">
          {touched ? (
            <motion.span key={sel} className="lt-one" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} dir={cur.rtl ? 'rtl' : 'ltr'}>
              {cur.title}
            </motion.span>
          ) : (
            LANGS.map((l, i) => (
              <span key={l.code} className="lt-cycle" style={{ animationDelay: `${i * 1.9}s` }} dir={l.rtl ? 'rtl' : 'ltr'}>
                {l.title}
              </span>
            ))
          )}
        </motion.div>

        <div className="llist">
          {LANGS.map((l) => {
            const on = l.code === sel;
            return (
              <motion.button
                key={l.code}
                type="button"
                variants={item}
                whileTap={{ scale: 0.97 }}
                className={'lcard' + (on ? ' on' : '')}
                onClick={() => {
                  setSel(l.code);
                  setTouched(true);
                }}
                aria-pressed={on}
              >
                <span className="lmono">{l.mono}</span>
                <span className="lname" dir={l.rtl ? 'rtl' : 'ltr'} lang={l.code}>{l.name}</span>
                <span className="lchk">
                  {on && (
                    <motion.span initial={{ scale: 0, rotate: -40 }} animate={{ scale: 1, rotate: 0 }} transition={spring}>
                      <Icon n="check" size={18} sw={3} />
                    </motion.span>
                  )}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>

      <motion.div className="lfoot" variants={item}>
        <PressButton className="dbtn primary wide lgo" onClick={() => finish(true)}>
          <motion.span key={cur.code} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} dir={cur.rtl ? 'rtl' : 'ltr'} lang={cur.code}>
            {cur.cont}
          </motion.span>
        </PressButton>
      </motion.div>
    </motion.div>
  );
}
