import { PDFDocument } from 'pdf-lib';
import JSZip from 'jszip';
import type { PDFDoc } from './pdf';
import { t } from './i18n';

export class Cancelled extends Error {}
const tick = () => new Promise<void>((r) => setTimeout(r, 0));
const toBlob = (c: HTMLCanvasElement, type: string, q?: number) => new Promise<Blob | null>((res) => c.toBlob((b) => res(b), type, q));

// ---------------------------------------------------------------- images -> PDF
export interface ImgItem { id: string; file: File; thumb: string; rot: number }
export interface PdfOpts { size: 'a4' | 'original'; margin: 0 | 18 | 36; quality: 'high' | 'medium' | 'low' }
const Q = { high: { q: 0.92, side: 2500 }, medium: { q: 0.8, side: 2000 }, low: { q: 0.6, side: 1500 } };

interface Bmp { src: CanvasImageSource; w: number; h: number; close: () => void }

/** Decodes an image and applies its EXIF orientation. Throws for unsupported formats. */
export async function decodeImage(file: File): Promise<Bmp> {
  try {
    const b = await createImageBitmap(file, { imageOrientation: 'from-image' } as ImageBitmapOptions);
    return { src: b, w: b.width, h: b.height, close: () => b.close() };
  } catch {
    const url = URL.createObjectURL(file);
    try {
      const img = new Image();
      img.src = url;
      await img.decode();
      return { src: img, w: img.naturalWidth, h: img.naturalHeight, close: () => {} };
    } finally {
      URL.revokeObjectURL(url);
    }
  }
}

export async function imageThumb(file: File): Promise<string> {
  const b = await decodeImage(file);
  const k = Math.min(1, 220 / Math.max(b.w, b.h));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(b.w * k));
  c.height = Math.max(1, Math.round(b.h * k));
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(b.src, 0, 0, c.width, c.height);
  b.close();
  const blob = await toBlob(c, 'image/jpeg', 0.7);
  c.width = 0;
  if (!blob) throw new Error('thumb');
  return URL.createObjectURL(blob);
}

function rasterize(b: Bmp, rot: number, maxSide: number) {
  const swap = rot % 180 !== 0;
  const w0 = swap ? b.h : b.w;
  const h0 = swap ? b.w : b.h;
  const k = Math.min(1, maxSide / Math.max(w0, h0)); // big photos are downscaled to save memory
  const w = Math.max(1, Math.round(w0 * k));
  const h = Math.max(1, Math.round(h0 * k));
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate((rot * Math.PI) / 180);
  ctx.drawImage(b.src, (-b.w * k) / 2, (-b.h * k) / 2, b.w * k, b.h * k);
  ctx.restore();
  return c;
}

export async function imagesToPdf(items: ImgItem[], o: PdfOpts, onProgress: (done: number) => void, cancelled: () => boolean): Promise<Blob> {
  const pdf = await PDFDocument.create();
  const { q, side } = Q[o.quality];
  const m = o.margin;
  for (let i = 0; i < items.length; i++) {
    if (cancelled()) throw new Cancelled();
    onProgress(i);
    await tick();
    const b = await decodeImage(items[i].file); // one image in memory at a time
    const c = rasterize(b, items[i].rot, side);
    b.close();
    const iw = c.width;
    const ih = c.height;
    const blob = await toBlob(c, 'image/jpeg', q);
    c.width = 0;
    if (!blob) throw new Error('encode');
    const img = await pdf.embedJpg(new Uint8Array(await blob.arrayBuffer()));
    let pw: number, ph: number, dw: number, dh: number, x: number, y: number;
    if (o.size === 'a4') {
      const land = iw > ih;
      pw = land ? 841.89 : 595.28;
      ph = land ? 595.28 : 841.89;
      const k = Math.min((pw - 2 * m) / iw, (ph - 2 * m) / ih);
      dw = iw * k;
      dh = ih * k;
      x = (pw - dw) / 2;
      y = (ph - dh) / 2;
    } else {
      dw = iw * 0.75;
      dh = ih * 0.75;
      pw = dw + 2 * m;
      ph = dh + 2 * m;
      x = m;
      y = m;
    }
    pdf.addPage([pw, ph]).drawImage(img, { x, y, width: dw, height: dh });
  }
  onProgress(items.length);
  const bytes = await pdf.save();
  return new Blob([bytes as unknown as BlobPart], { type: 'application/pdf' });
}

// ---------------------------------------------------------------- PDF -> images
export interface ImgOpts { format: 'png' | 'jpg'; dpi: 72 | 150 | 300 }
// The three quality levels shown to the user (low / high / very high) map to these resolutions.
const jpgQuality = (dpi: number) => (dpi <= 72 ? 0.8 : dpi <= 150 ? 0.9 : 0.95);
const MAX_PX = 25_000_000; // per-page canvas cap so phones don't run out of memory
export interface OutFile { name: string; blob: Blob }

/** Parses "1-5, 8, 10-12" (Arabic digits allowed) into sorted page numbers. */
export function parseRange(text: string, total: number): { pages: number[]; error: string } {
  const t = text
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .trim();
  if (!t) return { pages: [], error: '' };
  const set = new Set<number>();
  for (const part of t.split(/[,،;\s]+/).filter(Boolean)) {
    const m = part.match(/^(\d+)(?:[-–](\d+))?$/);
    if (!m) return { pages: [], error: t('rangeBad', { part }) };
    const a = +m[1];
    const b = m[2] ? +m[2] : a;
    if (a < 1 || b < 1 || a > total || b > total) return { pages: [], error: t('rangeBounds', { total }) };
    if (a > b) return { pages: [], error: t('rangeBack', { part, rev: `${b}-${a}` }) };
    for (let p = a; p <= b; p++) set.add(p);
  }
  return { pages: [...set].sort((x, y) => x - y), error: '' };
}

export async function pdfToImages(doc: PDFDoc, pages: number[], base: string, o: ImgOpts, onProgress: (done: number) => void, cancelled: () => boolean): Promise<OutFile[]> {
  const ext = o.format === 'png' ? 'png' : 'jpg';
  const mime = o.format === 'png' ? 'image/png' : 'image/jpeg';
  const files: OutFile[] = [];
  const pad = String(doc.numPages).length;
  for (let i = 0; i < pages.length; i++) {
    if (cancelled()) throw new Cancelled();
    onProgress(i);
    await tick();
    const page = await doc.getPage(pages[i]);
    const v0 = page.getViewport({ scale: 1 });
    let scale = o.dpi / 72;
    const px = v0.width * scale * v0.height * scale;
    if (px > MAX_PX) scale *= Math.sqrt(MAX_PX / px);
    const vp = page.getViewport({ scale });
    const c = document.createElement('canvas');
    c.width = Math.floor(vp.width);
    c.height = Math.floor(vp.height);
    const ctx = c.getContext('2d');
    if (!ctx) throw new Error('canvas');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    page.cleanup();
    const blob = await toBlob(c, mime, o.format === 'jpg' ? jpgQuality(o.dpi) : undefined);
    c.width = 0; // free memory right after each page
    if (!blob) throw new Error('encode');
    files.push({ name: `${base}-page-${String(pages[i]).padStart(pad, '0')}.${ext}`, blob });
  }
  onProgress(pages.length);
  return files;
}

/** Packs images into one ZIP, only when the user asks for it. */
export async function zipFiles(files: OutFile[]): Promise<Blob> {
  const zip = new JSZip();
  files.forEach((f) => zip.file(f.name, f.blob));
  return zip.generateAsync({ type: 'blob', compression: 'STORE' });
}
