import { useLayoutEffect, useState } from 'react';

export type Theme = 'light' | 'dark';
export type View = 'grid' | 'list';
export interface Settings {
  theme: Theme;
  view: View;
  cols: number;
}

export const GRID_SIZES = [2, 3, 4, 6, 8];
const KEY = 'mybooks.settings';

function load(): Settings {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (s && (s.theme === 'light' || s.theme === 'dark')) {
      return {
        theme: s.theme,
        view: s.view === 'list' ? 'list' : 'grid',
        cols: GRID_SIZES.includes(s.cols) ? s.cols : 3,
      };
    }
  } catch {
    /* ignore */
  }
  const light = typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: light)').matches;
  return { theme: light ? 'light' : 'dark', view: 'grid', cols: 3 };
}

export function useSettings() {
  const [s, set] = useState<Settings>(load);
  useLayoutEffect(() => {
    document.documentElement.dataset.theme = s.theme;
    try {
      localStorage.setItem(KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
  }, [s]);
  return [s, (p: Partial<Settings>) => set((v) => ({ ...v, ...p }))] as const;
}
