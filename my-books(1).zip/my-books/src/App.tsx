import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'framer-motion';
import { addFile, addFolder, deleteFiles, deleteFolder, FileRec, FolderRec, getBlob, getFiles, getFolders, renameFolder, setFolder, uid, updateFile } from './db';
import { makeThumb, NeedPassword, openPdf } from './pdf';
import { saveToDevice } from './storage';
import { GRID_SIZES, useSettings } from './settings';
import { useBack } from './back';
import { Boundary, Dialog, DialogSpec, Icon, MiniSpin, Opt, PressButton, ProgressBar, Segmented, Sheet, Toast } from './ui';
import { FileGrid, FolderList } from './Cards';
import Viewer from './Viewer';
import ImagesToPdf from './ImagesToPdf';
import PdfToImages from './PdfToImages';
import Splash from './Splash';
import LanguagePicker from './LanguagePicker';
import { LANGS, hasChosenLang, isRTL, t, useLang } from './i18n';

const slide = { type: 'spring', stiffness: 380, damping: 38 } as const;

function uniqueName(name: string, taken: Set<string>) {
  const base = name.replace(/\.pdf$/i, '').trim() || 'Book';
  let n = base;
  let i = 2;
  while (taken.has(n.toLowerCase())) n = `${base} (${i++})`;
  taken.add(n.toLowerCase());
  return n;
}

function Empty({ icon, title, text }: { icon: 'book' | 'folder'; title: string; text: string }) {
  return (
    <motion.div className="empty" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <div className="eico"><Icon n={icon} size={40} sw={1.6} /></div>
      <h3>{title}</h3>
      <p>{text}</p>
    </motion.div>
  );
}

export default function App() {
  const [settings, setSettings] = useSettings();
  const [files, setFiles] = useState<FileRec[]>([]);
  const [folders, setFolders] = useState<FolderRec[]>([]);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<'files' | 'folders'>('files');
  const [showSettings, setShowSettings] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [viewing, setViewing] = useState<FileRec | null>(null);
  const [folderId, setFolderId] = useState<string | null>(null);
  const [folderMenu, setFolderMenu] = useState(false);
  const [menu, setMenu] = useState<FileRec | null>(null);
  const [moveIds, setMoveIds] = useState<string[] | null>(null);
  const [pickFor, setPickFor] = useState<string | null>(null);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [sel, setSel] = useState<Set<string> | null>(null);
  const [dialog, setDialog] = useState<DialogSpec | null>(null);
  const [tool, setTool] = useState<null | { kind: 'img'; files: File[] } | { kind: 'pdf'; file: FileRec }>(null);
  const [pickPdf, setPickPdf] = useState(false);
  const [splash, setSplash] = useState(true);
  const [splashLeaving, setSplashLeaving] = useState(false);
  const [langPick, setLangPick] = useState<null | 'first' | 'change'>(hasChosenLang() ? null : 'first');
  useLang(); // re-render everything when the language changes
  const rtl = isRTL();
  const imgInput = useRef<HTMLInputElement>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [busy, setBusy] = useState<{ label: string; done: number; total: number } | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const toastT = useRef<ReturnType<typeof setTimeout> | null>(null);
  const swipe = useRef<{ x: number; y: number } | null>(null);

  const say = useCallback((m: string) => {
    setToast(m);
    if (toastT.current) clearTimeout(toastT.current);
    toastT.current = setTimeout(() => setToast(null), 3200);
  }, []);

  const reload = useCallback(async () => {
    try {
      const [f, fo] = await Promise.all([getFiles(), getFolders()]);
      f.sort((a, b) => b.addedAt - a.addedAt);
      fo.sort((a, b) => a.name.localeCompare(b.name));
      setFiles(f);
      setFolders(fo);
    } catch {
      say(t('loadFail'));
    }
    setReady(true);
  }, [say]);

  useEffect(() => {
    reload();
    try {
      navigator.storage?.persist?.();
    } catch {
      /* ignore */
    }
  }, [reload]);

  useBack(sel !== null, () => setSel(null));

  const curFolder = folders.find((f) => f.id === folderId) || null;
  const inFolder = useMemo(() => (folderId ? files.filter((f) => f.folderId === folderId) : []), [files, folderId]);
  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    files.forEach((f) => f.folderId && (c[f.folderId] = (c[f.folderId] || 0) + 1));
    return c;
  }, [files]);

  const confirm = (spec: DialogSpec) => setDialog(spec);

  // ---------- actions ----------
  const importFiles = async (list: File[], quiet = false): Promise<FileRec[]> => {
    if (!list.length) return [];
    const taken = new Set(files.map((f) => f.name.toLowerCase()));
    const created: FileRec[] = [];
    let ok = 0;
    for (let i = 0; i < list.length; i++) {
      const f = list[i];
      setBusy({ label: f.name, done: i, total: list.length });
      try {
        let pages = 0;
        let thumb: Blob | null = null;
        let encrypted = false;
        try {
          const doc = await openPdf(f);
          pages = doc.numPages;
          thumb = await makeThumb(doc).catch(() => null);
          doc.destroy();
        } catch (e) {
          if (e instanceof NeedPassword) encrypted = true;
          else throw e;
        }
        const rec: FileRec = { id: uid(), name: uniqueName(f.name, taken), size: f.size, pages, thumb, folderId: null, addedAt: Date.now(), lastPage: 1, encrypted };
        // An independent copy of the bytes lives inside the app.
        await addFile(rec, new Blob([f], { type: 'application/pdf' }));
        ok++;
        created.push(rec);
      } catch (e: any) {
        if (e?.name === 'QuotaExceededError') {
          say(t('storageFull'));
          break;
        }
        say(t('notPdf', { name: f.name }));
      }
    }
    setBusy(null);
    await reload();
    if (ok && !quiet) say(t('importedN', { n: ok }));
    return created;
  };

  const rename = (f: FileRec) =>
    confirm({
      title: t('renameBook'),
      input: { initial: f.name },
      ok: t('save'),
      onOk: async (v) => {
        const name = v.trim();
        if (!name) return t('enterName');
        if (files.some((x) => x.id !== f.id && x.name.toLowerCase() === name.toLowerCase())) return t('bookExists');
        await updateFile(f.id, { name });
        await reload();
      },
    });

  const remove = (ids: string[]) =>
    confirm({
      title: ids.length === 1 ? t('deleteBookQ') : t('deleteBooksQ', { n: ids.length }),
      message: t('deleteMsg'),
      ok: t('delete'),
      danger: true,
      onOk: async () => {
        await deleteFiles(ids);
        setSel(null);
        await reload();
        say(t('deleted'));
      },
    });

  const saveCopy = async (f: FileRec) => {
    try {
      const blob = await getBlob(f.id);
      if (!blob) throw new Error('missing');
      const r = await saveToDevice(f.name.replace(/\.pdf$/i, '') + '.pdf', blob);
      say(r.mode === 'saved' ? t('savedTo', { path: r.path }) : r.mode === 'shared' ? t('chooseSave') : t('downloadStarted'));
    } catch {
      say(t('saveFail'));
    }
  };

  const newFolder = () =>
    confirm({
      title: t('newFolder'),
      input: { placeholder: t('folderName') },
      ok: t('create'),
      onOk: async (v) => {
        const name = v.trim();
        if (!name) return t('enterName');
        if (folders.some((f) => f.name.toLowerCase() === name.toLowerCase())) return t('folderExists');
        await addFolder(name);
        await reload();
        setTab('folders');
      },
    });

  const renameCurFolder = (fo: FolderRec) =>
    confirm({
      title: t('renameFolder'),
      input: { initial: fo.name },
      ok: t('save'),
      onOk: async (v) => {
        const name = v.trim();
        if (!name) return t('enterName');
        if (folders.some((f) => f.id !== fo.id && f.name.toLowerCase() === name.toLowerCase())) return t('folderExists');
        await renameFolder(fo.id, name);
        await reload();
      },
    });

  const removeFolder = (fo: FolderRec) =>
    confirm({
      title: t('deleteFolderQ'),
      message: t('deleteFolderMsg'),
      ok: t('delete'),
      danger: true,
      onOk: async () => {
        await deleteFolder(fo.id);
        setFolderId(null);
        await reload();
      },
    });

  const tap = (f: FileRec) => {
    if (sel) {
      const n = new Set(sel);
      n.has(f.id) ? n.delete(f.id) : n.add(f.id);
      setSel(n.size ? n : null);
    } else setViewing(f);
  };
  const long = (f: FileRec) => {
    if (!sel) setSel(new Set([f.id]));
  };

  const closeViewer = () => {
    setViewing(null);
    reload();
  };

  // ---------- pieces ----------
  const selBar = (
    <header className="hdr">
      <PressButton className="ib" aria-label="Cancel selection" onClick={() => setSel(null)}><Icon n="x" /></PressButton>
      <div className="title">{t('nSelected', { n: sel?.size ?? 0 })}</div>
      <div className="acts">
        {sel?.size === 1 && (
          <PressButton className="ib" aria-label="Options" onClick={() => setMenu(files.find((f) => f.id === [...sel][0]) || null)}><Icon n="more" sw={3.5} /></PressButton>
        )}
        <PressButton className="ib" aria-label="Move" onClick={() => sel && setMoveIds([...sel])}><Icon n="folder" /></PressButton>
        <PressButton className="ib" aria-label="Delete" onClick={() => sel && remove([...sel])}><Icon n="trash" /></PressButton>
      </div>
    </header>
  );

  const filesPane = !ready ? (
    <div className="grid" data-cols={settings.cols} style={{ gridTemplateColumns: `repeat(${settings.cols}, minmax(0,1fr))`, gap: settings.cols >= 6 ? 8 : 14 }}>
      {Array.from({ length: settings.cols * 2 }, (_, i) => <div key={i} className="skel" />)}
    </div>
  ) : files.length === 0 ? (
    <Empty icon="book" title={t('emptyBooksT')} text={t('emptyBooksX')} />
  ) : (
    <FileGrid files={files} view={settings.view} cols={settings.cols} sel={sel} onTap={tap} onLong={long} onMenu={setMenu} />
  );

  const foldersPane = folders.length === 0 ? (
    <Empty icon="folder" title={t('emptyFoldersT')} text={t('emptyFoldersX')} />
  ) : (
    <FolderList folders={folders} counts={counts} onOpen={(f) => setFolderId(f.id)} />
  );

  return (
    <MotionConfig reducedMotion="user">
      <div className="app">
        {sel && !folderId ? selBar : (
          <header className="hdr">
            <PressButton className="ib" aria-label="Settings" onClick={() => setShowSettings(true)}>
              <motion.span className="rot" animate={{ rotate: showSettings ? 90 : 0 }}><Icon n="sliders" /></motion.span>
            </PressButton>
            <div className="title">MY <b>BOOKS</b></div>
            <PressButton className="ib fill" aria-label="Add" onClick={() => setAddOpen((v) => !v)}>
              <motion.span className="rot" animate={{ rotate: addOpen ? 45 : 0 }}><Icon n="plus" size={26} sw={2.4} /></motion.span>
            </PressButton>
          </header>
        )}

        <div className="tabs">
          {(['files', 'folders'] as const).map((tb) => (
            <button key={tb} className={'tab' + (tab === tb ? ' on' : '')} onClick={() => setTab(tb)}>
              {tb === 'files' ? t('tabFiles') : t('tabFolders')}
              {tab === tb && <motion.span layoutId="tabind" className="tabind" transition={{ type: 'spring', stiffness: 500, damping: 36 }} />}
            </button>
          ))}
        </div>

        <main
          className="pane"
          onTouchStart={(e) => (swipe.current = { x: e.touches[0].clientX, y: e.touches[0].clientY })}
          onTouchEnd={(e) => {
            const s = swipe.current;
            swipe.current = null;
            if (!s) return;
            const dx = e.changedTouches[0].clientX - s.x;
            const dy = e.changedTouches[0].clientY - s.y;
            if (Math.abs(dx) > 80 && Math.abs(dy) < 50) setTab((rtl ? dx > 0 : dx < 0) ? 'folders' : 'files');
          }}
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.div key={tab} initial={{ opacity: 0, x: (tab === 'files' ? -28 : 28) * (rtl ? -1 : 1) }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: (tab === 'files' ? 28 : -28) * (rtl ? -1 : 1) }} transition={{ duration: 0.18 }}>
              {tab === 'files' ? filesPane : foldersPane}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <input ref={fileInput} type="file" accept="application/pdf,.pdf" multiple hidden onChange={(e) => {
        const list = Array.from(e.target.files || []);
        e.target.value = '';
        importFiles(list);
      }} />

      <input ref={imgInput} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={(e) => {
        const list = Array.from(e.target.files || []);
        e.target.value = '';
        if (list.length) setTool({ kind: 'img', files: list });
      }} />

      {/* Settings */}
      <AnimatePresence>
        {showSettings && <SettingsScreen key="settings" s={settings} set={setSettings} onClose={() => setShowSettings(false)} onLanguage={() => setLangPick('change')} />}
      </AnimatePresence>

      {/* Folder screen */}
      <AnimatePresence>
        {curFolder && (
          <motion.div key="folder" className="screen" initial={{ x: rtl ? '-100%' : '100%' }} animate={{ x: 0 }} exit={{ x: rtl ? '-100%' : '100%' }} transition={slide}>
            <FolderBack onBack={() => { setFolderId(null); setSel(null); }} />
            {sel ? selBar : (
              <header className="hdr">
                <PressButton className="ib" aria-label="Back" onClick={() => setFolderId(null)}><Icon n="back" /></PressButton>
                <div className="title small">{curFolder.name}</div>
                <div className="acts">
                  <PressButton className="ib" aria-label="Add books" onClick={() => { setPicked(new Set()); setPickFor(curFolder.id); }}><Icon n="plus" size={26} /></PressButton>
                  <PressButton className="ib" aria-label="Folder options" onClick={() => setFolderMenu(true)}><Icon n="more" sw={3.5} /></PressButton>
                </div>
              </header>
            )}
            <main className="pane">
              {inFolder.length === 0 ? (
                <Empty icon="folder" title={t('emptyFolderT')} text={t('emptyFolderX')} />
              ) : (
                <FileGrid files={inFolder} view={settings.view} cols={settings.cols} sel={sel} onTap={tap} onLong={long} onMenu={setMenu} />
              )}
            </main>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Converters */}
      <AnimatePresence>
        {tool && (
          <motion.div key="tool" className="screen" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={slide}>
            <Boundary onClose={() => setTool(null)}>
            {tool.kind === 'img' ? (
              <ImagesToPdf
                initial={tool.files}
                say={say}
                onClose={() => setTool(null)}
                onCreate={async (file) => (await importFiles([file], true))[0] || null}
                onOpen={(rec) => { setViewing(rec); setTimeout(() => setTool(null), 450); }}
                onSave={saveCopy}
              />
            ) : (
              <PdfToImages file={tool.file} say={say} onClose={() => setTool(null)} />
            )}
            </Boundary>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Viewer */}
      <AnimatePresence>
        {viewing && (
          <motion.div key="viewer" className="screen viewer" initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.97 }} transition={{ type: 'spring', stiffness: 380, damping: 36 }}>
            <Boundary onClose={closeViewer}><Viewer file={viewing} onClose={closeViewer} /></Boundary>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sheets */}
      <AnimatePresence>
        {addOpen && (
          <Sheet key="add" onClose={() => setAddOpen(false)}>
            <Opt icon="file" label={t('importPdfs')} onClick={() => { setAddOpen(false); fileInput.current?.click(); }} />
            <Opt icon="folder" label={t('newFolder')} onClick={() => { setAddOpen(false); newFolder(); }} />
            <Opt icon="image" label={t('imagesToPdf')} onClick={() => { setAddOpen(false); imgInput.current?.click(); }} />
            <Opt icon="file" label={t('pdfToImages')} onClick={() => { setAddOpen(false); if (!files.length) say(t('importFirst')); else setPickPdf(true); }} />
          </Sheet>
        )}
        {menu && (
          <Sheet key="menu" title={menu.name} onClose={() => setMenu(null)}>
            <Opt icon="open" label={t('open')} onClick={() => { const f = menu; setMenu(null); setSel(null); setViewing(f); }} />
            <Opt icon="edit" label={t('menuRename')} onClick={() => { const f = menu; setMenu(null); setSel(null); rename(f); }} />
            <Opt icon="folder" label={t('menuMove')} onClick={() => { const f = menu; setMenu(null); setMoveIds([f.id]); }} />
            <Opt icon="save" label={t('menuSave')} onClick={() => { const f = menu; setMenu(null); setSel(null); saveCopy(f); }} />
            <Opt icon="image" label={t('menuConvert')} onClick={() => { const f = menu; setMenu(null); setSel(null); setTool({ kind: 'pdf', file: f }); }} />
            <Opt icon="trash" label={t('delete')} danger onClick={() => { const f = menu; setMenu(null); remove([f.id]); }} />
          </Sheet>
        )}
        {moveIds && (
          <Sheet key="move" title={t('moveToFolder')} onClose={() => setMoveIds(null)}>
            <Opt icon="x" label={t('noFolder')} onClick={async () => { const ids = moveIds; setMoveIds(null); setSel(null); await setFolder(ids, null); await reload(); say(t('moved')); }} />
            {folders.map((fo) => (
              <Opt key={fo.id} icon="folder" label={fo.name} onClick={async () => { const ids = moveIds; setMoveIds(null); setSel(null); await setFolder(ids, fo.id); await reload(); say(t('movedTo', { name: fo.name })); }} />
            ))}
            {folders.length === 0 && <p className="hint">{t('noFoldersHint')}</p>}
          </Sheet>
        )}
        {pickFor && (
          <Sheet key="pick" title={t('addToFolder')} onClose={() => setPickFor(null)}>
            {files.filter((f) => f.folderId !== pickFor).length === 0 && <p className="hint">{t('allInFolder')}</p>}
            {files.filter((f) => f.folderId !== pickFor).map((f) => (
              <PressButton key={f.id} className="opt" onClick={() => setPicked((p) => { const n = new Set(p); n.has(f.id) ? n.delete(f.id) : n.add(f.id); return n; })}>
                <span className={'chk inline' + (picked.has(f.id) ? ' on' : '')}>{picked.has(f.id) && <Icon n="check" size={14} sw={3} />}</span>
                <span className="oname">{f.name}</span>
              </PressButton>
            ))}
            {picked.size > 0 && (
              <PressButton className="dbtn primary wide" onClick={async () => { const ids = [...picked]; const id = pickFor; setPickFor(null); await setFolder(ids, id); await reload(); say(t('addedN', { n: ids.length })); }}>
                {t('addN', { n: picked.size })}
              </PressButton>
            )}
          </Sheet>
        )}
        {pickPdf && (
          <Sheet key="pickpdf" title={t('choosePdf')} onClose={() => setPickPdf(false)}>
            {files.map((f) => (
              <Opt key={f.id} icon="file" label={f.name} onClick={() => { setPickPdf(false); setTool({ kind: 'pdf', file: f }); }} />
            ))}
          </Sheet>
        )}
        {folderMenu && curFolder && (
          <Sheet key="fmenu" title={curFolder.name} onClose={() => setFolderMenu(false)}>
            <Opt icon="edit" label={t('renameFolder')} onClick={() => { setFolderMenu(false); renameCurFolder(curFolder); }} />
            <Opt icon="trash" label={t('deleteFolder')} danger onClick={() => { setFolderMenu(false); removeFolder(curFolder); }} />
          </Sheet>
        )}
      </AnimatePresence>

      <AnimatePresence>{dialog && <Dialog key="dlg" spec={dialog} onClose={() => setDialog(null)} />}</AnimatePresence>

      <AnimatePresence>
        {busy && (
          <motion.div className="busy" initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}>
            <div className="brow"><MiniSpin /><div className="btxt">{t('importingXofY', { x: busy.done + 1, y: busy.total })}</div></div>
            <div className="bname">{busy.label}</div>
            <ProgressBar value={busy.done / busy.total} />
          </motion.div>
        )}
      </AnimatePresence>

      <Toast msg={toast} />
      {langPick && <LanguagePicker mode={langPick} ready={langPick === 'change' || !splash || splashLeaving} onClose={() => setLangPick(null)} />}
      {splash && <Splash onLeave={() => setSplashLeaving(true)} onDone={() => setSplash(false)} />}
    </MotionConfig>
  );
}

// Registers the Android back button for the folder screen (closes it first).
function FolderBack({ onBack }: { onBack: () => void }) {
  useBack(true, onBack);
  return null;
}

function SettingsScreen({ s, set, onClose, onLanguage }: { s: ReturnType<typeof useSettings>[0]; set: ReturnType<typeof useSettings>[1]; onClose: () => void; onLanguage: () => void }) {
  useBack(true, onClose);
  const lang = useLang();
  const edge = isRTL() ? '100%' : '-100%';
  return (
    <motion.div className="screen" initial={{ x: edge }} animate={{ x: 0 }} exit={{ x: edge }} transition={slide}>
      <header className="hdr">
        <PressButton className="ib" aria-label="Back" onClick={onClose}><Icon n="back" /></PressButton>
        <div className="title small">{t('settings')}</div>
        <div className="ib" />
      </header>
      <main className="pane sets">
        <section className="sec">
          <h3>{t('language')}</h3>
          <p>{t('languageHint')}</p>
          <PressButton className="langrow" onClick={onLanguage}>
            <Icon n="globe" />
            <span className="lrname" dir="auto">{LANGS.find((l) => l.code === lang)?.name}</span>
            <Icon n="open" size={18} />
          </PressButton>
        </section>
        <section className="sec">
          <h3>{t('theme')}</h3>
          <p>{t('themeHint')}</p>
          <Segmented id="theme" value={s.theme} onChange={(v) => set({ theme: v })} options={[{ v: 'light', label: t('light') }, { v: 'dark', label: t('dark') }]} />
        </section>
        <section className="sec">
          <h3>{t('filesView')}</h3>
          <p>{t('filesViewHint')}</p>
          <Segmented id="view" value={s.view} onChange={(v) => set({ view: v })} options={[{ v: 'grid', label: t('cards') }, { v: 'list', label: t('list') }]} />
        </section>
        <AnimatePresence initial={false}>
          {s.view === 'grid' && (
            <motion.section className="sec" key="grid" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} style={{ overflow: 'hidden' }}>
              <h3>{t('gridSize')}</h3>
              <p>{t('gridHint')}</p>
              <Segmented id="cols" value={s.cols} onChange={(v) => set({ cols: v })} options={GRID_SIZES.map((n) => ({ v: n, label: `${n}×${n}` }))} />
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </motion.div>
  );
}
