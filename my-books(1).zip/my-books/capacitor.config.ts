import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hussein.mybooks',
  appName: 'MY BOOKS',
  webDir: 'dist',
  backgroundColor: '#000000',
};

export default config;
