// Copies pdf.js cMaps and standard fonts into /public so they ship inside the app (fully offline).
import { cpSync, existsSync, mkdirSync } from 'node:fs';
const src = 'node_modules/pdfjs-dist';
const dst = 'public/pdfjs';
try {
  mkdirSync(dst, { recursive: true });
  for (const d of ['cmaps', 'standard_fonts']) {
    if (existsSync(`${src}/${d}`)) cpSync(`${src}/${d}`, `${dst}/${d}`, { recursive: true });
  }
} catch (e) {
  console.warn('pdf.js assets copy skipped:', e.message);
}
