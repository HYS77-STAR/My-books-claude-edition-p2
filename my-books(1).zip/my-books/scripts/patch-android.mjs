// Runs automatically after `npx cap sync android` (see "capacitor:sync:after" in package.json).
// It adds two small things to the generated Android project. Safe to run many times.
//   1) A black, icon-less system splash (Android 12+ shows one before the app starts).
//   2) A tiny native plugin, "GallerySaver", that saves images into the phone's gallery
//      (Pictures/MY BOOKS) through MediaStore.
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const res = 'android/app/src/main/res';
const javaRoot = 'android/app/src/main/java';

if (!existsSync('android')) {
  console.log('[patch-android] no android project yet, nothing to do');
  process.exit(0);
}

// ------------------------------------------------------------------ 1) system splash
function patchSplash() {
  if (!existsSync(res)) return console.warn('[patch-android] res folder not found, splash skipped');
  mkdirSync(`${res}/drawable`, { recursive: true });
  writeFileSync(
    `${res}/drawable/splash_empty.xml`,
    `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path android:fillColor="#00000000" android:pathData="M0,0h24v24h-24z" />
</vector>
`,
  );
  const file = `${res}/values/styles.xml`;
  if (!existsSync(file)) return console.warn('[patch-android] styles.xml not found, splash skipped');
  let xml = readFileSync(file, 'utf8');
  if (xml.includes('windowSplashScreenBackground')) return console.log('[patch-android] splash already patched');
  const open = /(<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*>)/;
  if (!open.test(xml)) return console.warn('[patch-android] launch theme not found, splash skipped');
  xml = xml.replace(
    open,
    `$1
        <item name="windowSplashScreenBackground">#000000</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/splash_empty</item>
        <item name="windowSplashScreenIconBackgroundColor">#000000</item>`,
  );
  writeFileSync(file, xml);
  console.log('[patch-android] system splash is now black');
}

// ------------------------------------------------------------------ 2) gallery plugin
function findFile(dir, name) {
  if (!existsSync(dir)) return null;
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) {
      const hit = findFile(p, name);
      if (hit) return hit;
    } else if (entry === name) return p;
  }
  return null;
}

const pluginJava = (pkg) => `package ${pkg};

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Saves an image file into the gallery (Pictures/<album>) using MediaStore. */
@CapacitorPlugin(name = "GallerySaver")
public class GallerySaverPlugin extends Plugin {

    @PluginMethod
    public void save(PluginCall call) {
        String path = call.getString("path");
        String name = call.getString("name");
        String mime = call.getString("mime", "image/png");
        String album = call.getString("album", "MY BOOKS");

        if (path == null || name == null) {
            call.reject("path and name are required");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Older Android: the app falls back to the share sheet.
            call.reject("UNSUPPORTED_ANDROID");
            return;
        }

        ContentResolver resolver = getContext().getContentResolver();
        Uri target = null;
        try {
            String filePath = Uri.parse(path).getPath();
            File source = new File(filePath);
            if (!source.exists()) {
                call.reject("source file not found");
                return;
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, mime);
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + album);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);

            target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (target == null) {
                call.reject("could not create the gallery entry");
                return;
            }

            OutputStream out = resolver.openOutputStream(target);
            if (out == null) {
                resolver.delete(target, null, null);
                call.reject("could not open the gallery entry");
                return;
            }
            InputStream in = new FileInputStream(source);
            try {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) > 0) {
                    out.write(buffer, 0, read);
                }
                out.flush();
            } finally {
                in.close();
                out.close();
            }

            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(target, done, null, null);

            JSObject result = new JSObject();
            result.put("uri", target.toString());
            call.resolve(result);
        } catch (Exception e) {
            if (target != null) {
                try {
                    resolver.delete(target, null, null);
                } catch (Exception ignored) {
                    // nothing else to do
                }
            }
            call.reject(e.getMessage() == null ? "save failed" : e.getMessage());
        }
    }
}
`;

const mainJava = (pkg) => `package ${pkg};

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(GallerySaverPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`;

function patchGallery() {
  const main = findFile(javaRoot, 'MainActivity.java');
  if (!main) return console.warn('[patch-android] MainActivity.java not found, gallery plugin skipped');
  const m = readFileSync(main, 'utf8').match(/package\s+([\w.]+)\s*;/);
  if (!m) return console.warn('[patch-android] package name not found, gallery plugin skipped');
  const pkg = m[1];
  const dir = main.slice(0, main.lastIndexOf('MainActivity.java'));
  writeFileSync(join(dir, 'GallerySaverPlugin.java'), pluginJava(pkg));
  writeFileSync(main, mainJava(pkg));
  console.log('[patch-android] gallery plugin installed in package ' + pkg);
}

patchSplash();
patchGallery();
