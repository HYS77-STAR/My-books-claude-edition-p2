import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  build: { target: 'esnext', chunkSizeWarningLimit: 3000 },
  optimizeDeps: { esbuildOptions: { target: 'esnext' } },
});
