import { Component, ReactNode, useEffect, useRef, useState } from 'react';
import { AnimatePresence, HTMLMotionProps, motion, useDragControls, useIsPresent, usePresence } from 'framer-motion';
import { useBack } from './back';
import { t } from './i18n';

const P = {
  plus: 'M12 5v14M5 12h14',
  sliders: 'M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4',
  back: 'M15 18l-6-6 6-6',
  more: 'M12 5h.01M12 12h.01M12 19h.01',
  folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  file: 'M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3',
  check: 'M5 12l5 5 9-10',
  x: 'M6 6l12 12M18 6L6 18',
  save: 'M12 3v12M7 10l5 5 5-5M5 21h14',
  edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z',
  open: 'M5 12h14M13 6l6 6-6 6',
  book: 'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 19a2 2 0 0 1 2-2h13',
  rotate: 'M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5',
  grip: 'M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01',
  image: 'M4 5h16v14H4zM4 16l4-4 4 4 3-3 5 5M9 9h.01',
  up: 'M6 15l6-6 6 6',
  down: 'M6 9l6 6 6-6',
  merge: 'M5 4v3c0 3 3 5 7 5M19 4v3c0 3-3 5-7 5M12 12v8M8.5 16.5L12 20l3.5-3.5',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z',
};
export type IconName = keyof typeof P;

export function Icon({ n, size = 22, sw = 2 }: { n: IconName; size?: number; sw?: number }) {
  return (
    <svg className={n === 'back' || n === 'open' ? 'dir' : undefined} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
      <path d={P[n]} />
    </svg>
  );
}

export const spring = { type: 'spring', stiffness: 500, damping: 30 } as const;

/**
 * A button that shrinks a little while it is pressed.
 * IMPORTANT: a shrunk button is also a smaller touch target. On a wide row (a whole tablet width), a fixed 8% shrink would
 * move the edges ~80 px inwards, so a tap on the checkbox at the edge landed OUTSIDE the button and did nothing.
 * So the shrink is limited to ~14 px per side (and never more than 8%).
 *
 * The "pressed" state is driven by us (not by a gesture library), and it is cleared by EVERY way a touch can end:
 * finger up, touch cancelled by scrolling, finger slid off the button, scroll, focus lost... so it can never get stuck.
 */
export function PressButton({ onPointerDown, ...props }: HTMLMotionProps<'button'>) {
  const [down, setDown] = useState(false);
  const el = useRef<HTMLButtonElement>(null);
  const pressed = useRef(0.92); // the scale used for this press

  useEffect(() => {
    if (!down) return;
    const end = () => setDown(false);
    const move = (e: PointerEvent) => {
      const b = el.current?.getBoundingClientRect();
      if (!b) return end();
      const m = 10; // finger slid off the button: it is no longer being pressed
      if (e.clientX < b.left - m || e.clientX > b.right + m || e.clientY < b.top - m || e.clientY > b.bottom + m) end();
    };
    const names = ['pointerup', 'pointercancel', 'touchend', 'touchcancel', 'dragstart', 'contextmenu', 'blur', 'scroll'];
    names.forEach((n) => window.addEventListener(n, end, true));
    window.addEventListener('pointermove', move, true);
    const guard = setTimeout(end, 10000);
    return () => {
      names.forEach((n) => window.removeEventListener(n, end, true));
      window.removeEventListener('pointermove', move, true);
      clearTimeout(guard);
    };
  }, [down]);

  return (
    <motion.button
      ref={el}
      initial={false}
      animate={{ scale: down ? pressed.current : 1 }}
      transition={spring}
      onPointerDown={(e) => {
        const b = e.currentTarget.getBoundingClientRect();
        pressed.current = Math.max(0.92, 1 - 28 / Math.max(b.width, b.height, 1));
        setDown(true);
        onPointerDown?.(e);
      }}
      {...props}
    />
  );
}

export function Opt({ icon, label, onClick, danger }: { icon: IconName; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <PressButton className={'opt' + (danger ? ' danger' : '')} onClick={onClick}>
      <Icon n={icon} />
      <span>{label}</span>
    </PressButton>
  );
}

/**
 * Bottom sheet. The top handle + title stay put, the list scrolls in the middle,
 * and `footer` (the main action button) is pinned at the bottom, so it is always on screen, even when the phone is held sideways.
 */
export function Sheet({ onClose, title, children, footer }: { onClose: () => void; title?: string; children: ReactNode; footer?: ReactNode }) {
  const present = useIsPresent(); // false while the exit animation runs
  useBack(present, onClose);
  const controls = useDragControls();
  return (
    <div className="layer">
      <motion.div className="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
      <motion.div
        className={'sheet' + (footer ? ' hasfoot' : '')}
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', stiffness: 380, damping: 38 }}
        drag="y"
        dragControls={controls}
        dragListener={false} // only the top handle drags the sheet, so the list inside scrolls and taps normally
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0, bottom: 0.5 }}
        onDragEnd={(_, i) => {
          if (i.offset.y > 90 || i.velocity.y > 600) onClose();
        }}
      >
        <div className="shead" onPointerDown={(e) => controls.start(e)}>
          <div className="grab" />
          {title && <div className="stitle">{title}</div>}
        </div>
        <div className="sbody">{children}</div>
        {footer && (
          <motion.div className="sfoot" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }}>
            {footer}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}

export interface DialogSpec {
  title: string;
  message?: string;
  input?: { type?: string; initial?: string; placeholder?: string };
  ok: string;
  danger?: boolean;
  onOk: (value: string) => string | void | Promise<string | void>;
  onCancel?: () => void;
}

// How long the closing animation lasts (keep in step with .layer.out in styles.css).
const OUT_MS = 170;

/**
 * The dialog is animated with plain CSS, not with JavaScript springs. A CSS animation of opacity/transform is run by the
 * graphics side of the phone, so it stays perfectly smooth even if the app is busy redrawing something at the same moment.
 * The closing animation is played through AnimatePresence's `usePresence`: the dialog stays on screen until it says it is done.
 */
export function Dialog({ spec, onClose }: { spec: DialogSpec; onClose: () => void }) {
  const [v, setV] = useState(spec.input?.initial ?? '');
  const [err, setErr] = useState('');
  const [work, setWork] = useState(false);
  const [present, safeToRemove] = usePresence();
  const done = useRef(safeToRemove);
  done.current = safeToRemove; // always the latest one, so a redraw during the fade-out cannot restart the timer
  useEffect(() => {
    if (present) return;
    const id = window.setTimeout(() => done.current?.(), OUT_MS);
    return () => clearTimeout(id);
  }, [present]);
  const cancel = () => {
    if (!present) return;
    spec.onCancel?.();
    onClose();
  };
  useBack(present, cancel);
  const submit = async () => {
    if (work || !present) return;
    if (!spec.input) {
      // A plain question (for example "Delete this book?"): the window fades away FIRST, and only then the work is done.
      // The library redraw (cards leaving, the others sliding into place) therefore never competes with the fade-out.
      onClose();
      window.setTimeout(async () => {
        try {
          const e = await spec.onOk('');
          if (typeof e === 'string' && e) showToast(e);
        } catch {
          showToast(t('wentWrong'));
        }
      }, OUT_MS);
      return;
    }
    setWork(true);
    let e: string | void = undefined;
    try {
      e = await spec.onOk(v);
    } catch {
      e = t('wentWrong');
    }
    setWork(false);
    if (e) setErr(e);
    else onClose();
  };
  return (
    <div className={'layer center' + (present ? '' : ' out')}>
      <div className="backdrop fx" onClick={cancel} />
      <div className="dlg fx">
        <div className="dtitle">{spec.title}</div>
        {spec.message && <p className="dmsg">{spec.message}</p>}
        {spec.input && (
          <input
            className="dinput"
            autoFocus
            type={spec.input.type || 'text'}
            inputMode={spec.input.type === 'number' ? 'numeric' : undefined}
            placeholder={spec.input.placeholder}
            value={v}
            onChange={(e) => {
              setV(e.target.value);
              setErr('');
            }}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
          />
        )}
        {err && <div className="derr">{err}</div>}
        <div className="dbtns">
          <PressButton className="dbtn" onClick={cancel}>{t('cancel')}</PressButton>
          <PressButton className={'dbtn primary' + (spec.danger ? ' danger' : '')} onClick={submit}>{spec.ok}</PressButton>
        </div>
      </div>
    </div>
  );
}

// Opens a dialog from anywhere WITHOUT redrawing the whole app: the dialog lives in its own small component.
let dialogOpener: ((s: DialogSpec) => void) | null = null;
export const openDialog = (s: DialogSpec) => dialogOpener?.(s);
export function DialogHost() {
  const [cur, setCur] = useState<{ id: number; spec: DialogSpec } | null>(null);
  const seq = useRef(0);
  useEffect(() => {
    dialogOpener = (spec) => setCur({ id: ++seq.current, spec });
    return () => {
      dialogOpener = null;
    };
  }, []);
  return <AnimatePresence>{cur && <Dialog key={cur.id} spec={cur.spec} onClose={() => setCur((c) => (c && c.id === cur.id ? null : c))} />}</AnimatePresence>;
}

// Short message at the bottom. It lives in its own component (a message never redraws the app) and is animated with CSS.
let toastSet: ((s: { id: number; msg: string; out: boolean } | null) => void) | null = null;
let toastId = 0;
let toastTimers: number[] = [];
export function showToast(msg: string) {
  toastTimers.forEach(clearTimeout);
  const id = ++toastId;
  toastSet?.({ id, msg, out: false });
  toastTimers = [
    window.setTimeout(() => toastSet?.({ id, msg, out: true }), 3200),
    window.setTimeout(() => toastSet?.(null), 3200 + 240),
  ];
}
export function ToastHost() {
  const [s, setS] = useState<{ id: number; msg: string; out: boolean } | null>(null);
  useEffect(() => {
    toastSet = setS;
    return () => {
      toastSet = null;
    };
  }, []);
  return s ? <div key={s.id} className={'toast' + (s.out ? ' out' : '')} role="status">{s.msg}</div> : null;
}

export function Segmented<T extends string | number>({ id, value, options, onChange }: { id?: string; value: T; options: { v: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className={'seg' + (id ? '' : ' plain')}>
      {options.map((o) => (
        <button key={String(o.v)} className={o.v === value ? 'on' : ''} onClick={() => onChange(o.v)}>
          {id && o.v === value && <motion.span layoutId={id} className="segbg" transition={spring} />}
          <span className="segl">{o.label}</span>
        </button>
      ))}
    </div>
  );
}

/** If a screen crashes while rendering, show a way out instead of leaving the app stuck. */
export class Boundary extends Component<{ onClose: () => void; children: ReactNode }, { bad: boolean }> {
  state = { bad: false };
  static getDerivedStateFromError() {
    return { bad: true };
  }
  render() {
    if (!this.state.bad) return this.props.children;
    return (
      <div className="center-fill col" style={{ position: 'absolute', inset: 0 }}>
        <p>{t('screenCrash')}</p>
        <PressButton className="dbtn primary" onClick={this.props.onClose}>{t('close')}</PressButton>
      </div>
    );
  }
}

/** Progress bar with a moving shine, so it never looks frozen. */
export function ProgressBar({ value }: { value: number }) {
  const pct = Math.max(6, Math.min(100, value * 100));
  return (
    <div className="track">
      <motion.div className="bar" initial={false} animate={{ width: `${pct}%` }} transition={{ type: 'spring', stiffness: 140, damping: 22 }}>
        <span className="shine" />
      </motion.div>
    </div>
  );
}

/** Animated "working" card: a floating icon inside spinning rings, plus the shiny progress bar. */
export function Working({ icon, title, label, value }: { icon: IconName; title: string; label: string; value: number }) {
  return (
    <div className="wk">
      <div className="wkorb" aria-hidden="true">
        <span className="wkpulse" />
        <span className="wkring r1" />
        <span className="wkring r2" />
        <span className="orbit"><i className="wkdot" /></span>
        <span className="orbit rev"><i className="wkdot small" /></span>
        <div className="wkicon"><Icon n={icon} size={30} sw={1.9} /></div>
      </div>
      <div className="dtitle">{title}</div>
      <p className="dmsg">{label}</p>
      <ProgressBar value={value} />
      <div className="wkpct" dir="ltr">{Math.round(Math.max(0, Math.min(1, value)) * 100)}%</div>
    </div>
  );
}

/** Small spinner for buttons that are busy saving. */
export function MiniSpin() {
  return <span className="mini-spin" aria-hidden="true" />;
}
