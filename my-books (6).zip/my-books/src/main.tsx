import './styles.css';

// The intro in index.html is already on screen. This tiny file only waits until its first frames have been drawn, and then
// loads the app, so the heavy start-up work never delays the beginning of the intro.
let started = false;
const start = () => {
  if (started) return;
  started = true;
  void import('./start');
};
requestAnimationFrame(() => requestAnimationFrame(start));
setTimeout(start, 400); // safety: some phones hold back animation frames for a moment while the app opens
