import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import type { FileRec, FolderRec } from './db';
import { fmtSize } from './pdf';
import { t } from './i18n';
import { Icon, PressButton } from './ui';
import { useSortable } from './sortable';

export function Thumb({ blob }: { blob: Blob | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!blob) {
      setUrl(null);
      return;
    }
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return url ? <img src={url} alt="" draggable={false} decoding="async" /> : <div className="ph"><Icon n="file" size={28} /></div>;
}

const meta = (f: FileRec) => [f.encrypted ? t('protectedLabel') : f.pages ? t('nPages', { n: f.pages }) : '', fmtSize(f.size)].filter(Boolean).join(' · ');

interface GridProps {
  files: FileRec[];
  view: 'grid' | 'list';
  cols: number;
  sel: Set<string> | null;
  onTap: (f: FileRec) => void;
  onLong: (f: FileRec) => void;
  onMenu: (f: FileRec) => void;
  onReorder: (ids: string[]) => void;
}

function Check({ on }: { on: boolean }) {
  return <div className={'chk' + (on ? ' on' : '')}>{on && <Icon n="check" size={14} sw={3} />}</div>;
}

// The cards are memoised: they only redraw when their own data changes. Opening a dialog or a sheet (which redraws the app)
// therefore costs nothing here, which keeps the page behind it perfectly smooth.
interface CardProps {
  f: FileRec;
  i: number; // 0..10 (only used for the entrance delay)
  selecting: boolean;
  picked: boolean;
  dragging: boolean;
  onTap: (f: FileRec) => void;
  onMenu: (f: FileRec) => void;
}

const FileCard = memo(function FileCard({ f, i, selecting, picked, dragging, onTap, onMenu }: CardProps) {
  const d = i * 0.025;
  return (
    <motion.div
      layout
      data-id={f.id}
      className={'card' + (dragging ? ' dragging' : '')}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      whileTap={{ scale: 0.96 }}
      transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: d }, scale: { type: 'spring', stiffness: 400, damping: 28, delay: d } }}
      onClick={() => onTap(f)}
    >
      <div className={'thumb' + (picked ? ' picked' : '')}>
        <Thumb blob={f.thumb} />
        {selecting && <Check on={picked} />}
        {!selecting && (
          <button className="more" aria-label="Menu" onClick={(e) => { e.stopPropagation(); onMenu(f); }} onPointerDown={(e) => e.stopPropagation()}>
            <Icon n="more" size={20} sw={3.5} />
          </button>
        )}
      </div>
      <div className="cname">{f.name}</div>
      <div className="cmeta">{meta(f)}</div>
    </motion.div>
  );
});

const FileRow = memo(function FileRow({ f, i, selecting, picked, dragging, onTap, onMenu }: CardProps) {
  return (
    <motion.div
      layout
      data-id={f.id}
      className={'row' + (picked ? ' picked' : '') + (dragging ? ' dragging' : '')}
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 40, height: 0 }}
      whileTap={{ scale: 0.98 }}
      transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: i * 0.025 } }}
      onClick={() => onTap(f)}
    >
      <div className="rthumb"><Thumb blob={f.thumb} /></div>
      <div className="rtext">
        <div className="cname">{f.name}</div>
        <div className="cmeta">{meta(f)}</div>
      </div>
      {selecting ? <Check on={picked} /> : (
        <PressButton className="ib" aria-label="Menu" onClick={(e) => { e.stopPropagation(); onMenu(f); }} onPointerDown={(e) => e.stopPropagation()}>
          <Icon n="more" size={22} sw={3.5} />
        </PressButton>
      )}
    </motion.div>
  );
});

export function FileGrid({ files, view, cols, sel, onTap, onLong, onMenu, onReorder }: GridProps) {
  const ids = useMemo(() => files.map((f) => f.id), [files]);
  const byId = useMemo(() => new Map(files.map((f) => [f.id, f] as const)), [files]);
  const { ref, order, dragId } = useSortable<HTMLDivElement>({
    ids,
    onReorder,
    onPick: (id) => {
      const f = byId.get(id);
      if (f) onLong(f);
    },
    version: view + cols,
  });
  // While dragging, the cards are shown in the order the drag is heading to; the others slide out of the way.
  const shown = order ? order.map((id) => byId.get(id)).filter((f): f is FileRec => !!f) : files;
  // Stable handlers (they never change identity), so the memoised cards are not redrawn for nothing.
  const handlers = useRef({ onTap, onMenu });
  handlers.current = { onTap, onMenu };
  const tap = useCallback((f: FileRec) => handlers.current.onTap(f), []);
  const menu = useCallback((f: FileRec) => handlers.current.onMenu(f), []);
  const selecting = sel !== null;

  if (view === 'list') {
    return (
      <div className="list" ref={ref}>
        <AnimatePresence initial={false}>
          {shown.map((f, i) => <FileRow key={f.id} f={f} i={Math.min(i, 10)} selecting={selecting} picked={!!sel?.has(f.id)} dragging={dragId === f.id} onTap={tap} onMenu={menu} />)}
        </AnimatePresence>
      </div>
    );
  }
  return (
    <div className="grid" ref={ref} data-cols={cols} style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gap: cols >= 6 ? 8 : 14 }}>
      <AnimatePresence initial={false}>
        {shown.map((f, i) => <FileCard key={f.id} f={f} i={Math.min(i, 10)} selecting={selecting} picked={!!sel?.has(f.id)} dragging={dragId === f.id} onTap={tap} onMenu={menu} />)}
      </AnimatePresence>
    </div>
  );
}

export function FolderList({ folders, counts, onOpen, onReorder }: { folders: FolderRec[]; counts: Record<string, number>; onOpen: (f: FolderRec) => void; onReorder: (ids: string[]) => void }) {
  const ids = useMemo(() => folders.map((f) => f.id), [folders]);
  const byId = useMemo(() => new Map(folders.map((f) => [f.id, f] as const)), [folders]);
  const { ref, order, dragId } = useSortable<HTMLDivElement>({ ids, onReorder, version: 'folders' });
  const shown = order ? order.map((id) => byId.get(id)).filter((f): f is FolderRec => !!f) : folders;
  return (
    <div className="list" ref={ref}>
      <AnimatePresence initial={false}>
        {shown.map((f, i) => (
          <motion.div
            layout
            key={f.id}
            data-id={f.id}
            className={'row' + (dragId === f.id ? ' dragging' : '')}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40, height: 0 }}
            whileTap={{ scale: 0.98 }}
            transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: Math.min(i, 10) * 0.025 } }}
            onClick={() => onOpen(f)}
          >
            <div className="fico"><Icon n="folder" size={26} /></div>
            <div className="rtext">
              <div className="cname">{f.name}</div>
              <div className="cmeta">{t('nBooks', { n: counts[f.id] || 0 })}</div>
            </div>
            <Icon n="open" size={20} />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
