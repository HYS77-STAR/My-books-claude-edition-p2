import { createRoot } from 'react-dom/client';
import App from './App';
import './back';

createRoot(document.getElementById('root')!).render(<App />);
