import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, Reorder, motion, useDragControls } from 'framer-motion';
import { FileRec, getBlob } from './db';
import { Cancelled, MergeError, mergePdfs, warmConvertLater } from './convert';
import { fmtSize } from './pdf';
import { useBack } from './back';
import { Thumb } from './Cards';
import { Icon, MiniSpin, openDialog, PressButton, Sheet, Working } from './ui';
import { t } from './i18n';

const HEAVY = 80 * 1024 * 1024; // above this much data in total, warn that merging can be slow

function Row({ f, i, n, onUp, onDown, onRemove }: { f: FileRec; i: number; n: number; onUp: () => void; onDown: () => void; onRemove: () => void }) {
  const controls = useDragControls();
  return (
    <Reorder.Item value={f} dragListener={false} dragControls={controls} className="irow" whileDrag={{ scale: 1.03, zIndex: 5, boxShadow: '0 14px 32px rgba(0,0,0,0.35)' }}>
      <div className="inum">{i + 1}</div>
      <div className="mthumb"><Thumb blob={f.thumb} /></div>
      <div className="rtext">
        <div className="cname">{f.name}</div>
        {n > 1 && i === 0 && <span className="mtag">{t('mFirst')}</span>}
        {n > 1 && i === n - 1 && <span className="mtag end">{t('mLast')}</span>}
        <div className="cmeta">{[f.pages ? t('nPages', { n: f.pages }) : '', fmtSize(f.size)].filter(Boolean).join(' · ')}</div>
      </div>
      <div className="mv">
        <PressButton aria-label={t('moveUp')} disabled={i === 0} onClick={onUp}><Icon n="up" size={20} sw={2.6} /></PressButton>
        <PressButton aria-label={t('moveDown')} disabled={i === n - 1} onClick={onDown}><Icon n="down" size={20} sw={2.6} /></PressButton>
      </div>
      <PressButton className="ib sm" aria-label="Remove" onClick={onRemove}><Icon n="trash" /></PressButton>
      <div className="handle slim" aria-label="Drag to reorder" onPointerDown={(e) => controls.start(e)} style={{ touchAction: 'none' }}><Icon n="grip" sw={3.5} /></div>
    </Reorder.Item>
  );
}

export default function MergePdfs({ initial, library, onClose, onCreate, onOpen, onSave, say }: {
  initial: FileRec[];
  library: FileRec[];
  onClose: () => void;
  onCreate: (file: File, folderId: string | null) => Promise<FileRec | null>;
  onOpen: (rec: FileRec) => void;
  onSave: (rec: FileRec) => Promise<void> | void;
  say: (m: string) => void;
}) {
  useEffect(() => warmConvertLater(), []);
  const [items, setItems] = useState<FileRec[]>(initial);
  const [pickOpen, setPickOpen] = useState(false);
  const [picked, setPicked] = useState<string[]>([]); // in the order they were checked: that is the order they are added in
  const [phase, setPhase] = useState<'edit' | 'working' | 'done'>('edit');
  const [prog, setProg] = useState({ files: 0, pages: 0 });
  const [result, setResult] = useState<FileRec | null>(null);
  const [saving, setSaving] = useState(false);
  const [opening, setOpening] = useState(false);
  const cancel = useRef(false);
  const live = useRef({ items, library, onCreate });
  live.current = { items, library, onCreate };

  useBack(true, () => {
    if (phase === 'working') cancel.current = true;
    else onClose();
  });

  // Opened without any books chosen: after the screen has slid in, offer the list of books right away.
  useEffect(() => {
    if (initial.length) return;
    const id = window.setTimeout(() => openPicker(), 380);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openPicker = () => {
    setPicked([]);
    setPickOpen(true);
  };

  const inList = new Set(items.map((x) => x.id));
  const available = library.filter((f) => !inList.has(f.id));

  const togglePick = (id: string) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const addPicked = () => {
    const chosen = picked.map((id) => library.find((f) => f.id === id)).filter((f): f is FileRec => !!f && !f.encrypted);
    setItems((p) => [...p, ...chosen.filter((c) => !p.some((x) => x.id === c.id))]);
    setPickOpen(false);
  };

  const move = (id: string, d: -1 | 1) =>
    setItems((p) => {
      const i = p.findIndex((x) => x.id === id);
      const j = i + d;
      if (i < 0 || j < 0 || j >= p.length) return p;
      const n = p.slice();
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  const remove = (id: string) => setItems((p) => p.filter((x) => x.id !== id));

  const totalPages = items.reduce((a, f) => a + (f.pages || 0), 0);
  const totalSize = items.reduce((a, f) => a + f.size, 0);
  const folderOf = () => {
    const ids = new Set(items.map((x) => x.folderId));
    return ids.size === 1 ? [...ids][0] : null; // all the parts live in one folder: the merged file goes there too
  };

  const run = async (base: string) => {
    const list = live.current.items;
    const folderId = folderOf();
    cancel.current = false;
    setProg({ files: 0, pages: 0 });
    setPhase('working');
    await new Promise<void>((r) => requestAnimationFrame(() => setTimeout(r, 60)));
    try {
      const blob = await mergePdfs(
        list.map((f) => ({ id: f.id, name: f.name, load: () => getBlob(f.id) })),
        base,
        (files, pages) => setProg({ files, pages }),
        () => cancel.current,
      );
      const rec = await live.current.onCreate(new File([blob], base + '.pdf', { type: 'application/pdf' }), folderId);
      if (!rec) {
        setPhase('edit');
        return;
      }
      setResult(rec);
      setPhase('done');
    } catch (e) {
      if (e instanceof Cancelled) say(t('cancelled'));
      else if (e instanceof MergeError) say(e.why === 'protected' ? t('mergeProtected', { name: e.fileName }) : t('mergeBad', { name: e.fileName }));
      else if (e instanceof Error && e.message === 'empty') say(t('mergeNoPages'));
      else say(t('mergeFail'));
      setPhase('edit');
    }
  };

  // "Merge": asks for the name of the new file, then merges.
  const askName = () =>
    openDialog({
      title: t('mergeNameTitle'),
      message: t('mergeNameMsg'),
      input: { placeholder: t('fileName') },
      ok: t('merge'),
      onOk: (v) => {
        const base = v.trim().replace(/\.pdf$/i, '').trim();
        if (!base) return t('enterName');
        if (live.current.library.some((f) => f.name.toLowerCase() === base.toLowerCase())) return t('bookExists');
        run(base);
      },
    });

  const canMerge = items.length >= 2 && phase === 'edit';

  return (
    <>
      <header className="hdr">
        <PressButton className="ib" aria-label="Back" onClick={onClose}><Icon n="back" /></PressButton>
        <div className="title small">{t('mergePdfs')}</div>
        <PressButton className="ib" aria-label={t('chooseToMerge')} onClick={openPicker}><Icon n="plus" size={26} /></PressButton>
      </header>

      <main className="pane">
        {items.length === 0 ? (
          <div className="empty">
            <div className="eico"><Icon n="merge" size={40} sw={1.6} /></div>
            <h3>{t('mergeEmptyT')}</h3>
            <p>{t('mergeEmptyX')}</p>
            <PressButton className="dbtn primary" onClick={openPicker}>{t('choosePdfs')}</PressButton>
          </div>
        ) : (
          <>
            <p className="hint">{t('mergeHint')}</p>
            <Reorder.Group axis="y" values={items} onReorder={setItems} className="ilist">
              {items.map((f, i) => <Row key={f.id} f={f} i={i} n={items.length} onUp={() => move(f.id, -1)} onDown={() => move(f.id, 1)} onRemove={() => remove(f.id)} />)}
            </Reorder.Group>
            {items.length === 1 && <p className="hint">{t('mergeNeedMore')}</p>}
            {totalSize > HEAVY && <div className="warn" style={{ margin: '4px 12px 12px' }}>{t('mergeHeavy')}</div>}
          </>
        )}
      </main>

      <div className="actbar">
        <div className="grow">{t('nFiles', { n: items.length })}{totalPages ? ` · ${t('nPages', { n: totalPages })}` : ''}</div>
        <PressButton className="dbtn primary" disabled={!canMerge} onClick={askName}>{t('merge')}</PressButton>
      </div>

      <AnimatePresence>
        {pickOpen && phase === 'edit' && (
          <Sheet
            key="pick"
            title={t('chooseToMerge')}
            onClose={() => setPickOpen(false)}
            footer={picked.length > 0 ? <PressButton className="dbtn primary wide" onClick={addPicked}>{t('addN', { n: picked.length })}</PressButton> : undefined}
          >
            {available.length === 0 && <p className="hint">{t('allAdded')}</p>}
            {available.map((f) => {
              const k = picked.indexOf(f.id);
              return (
                <PressButton key={f.id} className="opt" disabled={f.encrypted} style={f.encrypted ? { opacity: 0.5 } : undefined} onClick={() => !f.encrypted && togglePick(f.id)}>
                  <span className={'chk inline' + (k >= 0 ? ' on' : '')}>
                    <AnimatePresence initial={false}>
                      {k >= 0 && (
                        <motion.span key="n" className="pk" initial={{ scale: 0.2, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.2, opacity: 0 }} transition={{ type: 'spring', stiffness: 520, damping: 26 }}>
                          {k + 1}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </span>
                  <span className="oname">{f.name}</span>
                  {f.encrypted && <span className="cmeta" style={{ marginInlineStart: 'auto' }}>{t('protectedLabel')}</span>}
                </PressButton>
              );
            })}
          </Sheet>
        )}
      </AnimatePresence>

      {phase === 'working' && (
        <div className="veil">
          <div className="wcard">
            <Working
              icon="merge"
              title={t('merging')}
              label={prog.files >= items.length ? t('saving') : t('mergeXofY', { x: Math.min(prog.files + 1, items.length), y: items.length })}
              value={totalPages ? prog.pages / totalPages : items.length ? prog.files / items.length : 0}
            />
            <PressButton className="dbtn wide" onClick={() => (cancel.current = true)}>{t('cancel')}</PressButton>
          </div>
        </div>
      )}

      {phase === 'done' && result && (
        <div className="veil">
          <motion.div className="wcard" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: 'spring', stiffness: 380, damping: 30 }}>
            <div className="okico"><Icon n="check" size={30} sw={3} /></div>
            <div className="dtitle">{t('merged')}</div>
            <p className="dmsg">{result.name} · {t('nPages', { n: result.pages })} · {fmtSize(result.size)}</p>
            <PressButton className="dbtn primary wide" disabled={opening} onClick={() => { if (opening) return; setOpening(true); onOpen(result); }}>{t('open')}</PressButton>
            <PressButton className="dbtn wide" disabled={saving} onClick={async () => {
              if (saving) return;
              setSaving(true);
              try {
                await Promise.race([Promise.resolve(onSave(result)), new Promise((r) => setTimeout(r, 8000))]);
              } finally {
                setSaving(false);
              }
            }}>{saving ? <><MiniSpin />{t('saving')}</> : t('menuSave')}</PressButton>
            <PressButton className="dbtn wide" onClick={onClose}>{t('done')}</PressButton>
          </motion.div>
        </div>
      )}
    </>
  );
}
