// Runs automatically after `npx cap sync android` (see "capacitor:sync:after" in package.json).
// It adds three small things to the generated Android project. Safe to run many times.
//   1) A black, icon-less system splash (Android 12+ shows one before the app starts).
//   2) A tiny native plugin, "GallerySaver", that saves images into the phone's gallery
//      (Pictures/MY BOOKS) through MediaStore.
//   3) A tiny native plugin, "PdfPicker", that lets the user choose MANY PDF files at once.
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const res = 'android/app/src/main/res';
const javaRoot = 'android/app/src/main/java';

if (!existsSync('android')) {
  console.log('[patch-android] no android project yet, nothing to do');
  process.exit(0);
}

// ------------------------------------------------------------------ 1) system splash
function patchSplash() {
  if (!existsSync(res)) return console.warn('[patch-android] res folder not found, splash skipped');
  mkdirSync(`${res}/drawable`, { recursive: true });
  writeFileSync(
    `${res}/drawable/splash_empty.xml`,
    `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path android:fillColor="#00000000" android:pathData="M0,0h24v24h-24z" />
</vector>
`,
  );
  const file = `${res}/values/styles.xml`;
  if (!existsSync(file)) return console.warn('[patch-android] styles.xml not found, splash skipped');
  let xml = readFileSync(file, 'utf8');
  if (xml.includes('windowSplashScreenBackground')) return console.log('[patch-android] splash already patched');
  const open = /(<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*>)/;
  if (!open.test(xml)) return console.warn('[patch-android] launch theme not found, splash skipped');
  xml = xml.replace(
    open,
    `$1
        <item name="windowSplashScreenBackground">#000000</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/splash_empty</item>
        <item name="windowSplashScreenIconBackgroundColor">#000000</item>`,
  );
  writeFileSync(file, xml);
  console.log('[patch-android] system splash is now black');
}

// ------------------------------------------------------------------ 2) gallery plugin
function findFile(dir, name) {
  if (!existsSync(dir)) return null;
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) {
      const hit = findFile(p, name);
      if (hit) return hit;
    } else if (entry === name) return p;
  }
  return null;
}

const pluginJava = (pkg) => `package ${pkg};

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Saves an image file into the gallery (Pictures/<album>) using MediaStore. */
@CapacitorPlugin(name = "GallerySaver")
public class GallerySaverPlugin extends Plugin {

    @PluginMethod
    public void save(PluginCall call) {
        String path = call.getString("path");
        String name = call.getString("name");
        String mime = call.getString("mime", "image/png");
        String album = call.getString("album", "MY BOOKS");
        // Capture time in ms. Each page gets its own time, so the gallery keeps them in order.
        Long takenArg = call.getLong("taken");
        long taken = takenArg != null ? takenArg.longValue() : System.currentTimeMillis();

        if (path == null || name == null) {
            call.reject("path and name are required");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Older Android: the app falls back to the share sheet.
            call.reject("UNSUPPORTED_ANDROID");
            return;
        }

        ContentResolver resolver = getContext().getContentResolver();
        Uri target = null;
        try {
            String filePath = Uri.parse(path).getPath();
            File source = new File(filePath);
            if (!source.exists()) {
                call.reject("source file not found");
                return;
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, mime);
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + album);
            values.put(MediaStore.Images.Media.DATE_TAKEN, taken);
            values.put(MediaStore.Images.Media.DATE_ADDED, taken / 1000);
            values.put(MediaStore.Images.Media.DATE_MODIFIED, taken / 1000);
            values.put(MediaStore.Images.Media.IS_PENDING, 1);

            target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (target == null) {
                call.reject("could not create the gallery entry");
                return;
            }

            OutputStream out = resolver.openOutputStream(target);
            if (out == null) {
                resolver.delete(target, null, null);
                call.reject("could not open the gallery entry");
                return;
            }
            InputStream in = new FileInputStream(source);
            try {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) > 0) {
                    out.write(buffer, 0, read);
                }
                out.flush();
            } finally {
                in.close();
                out.close();
            }

            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            done.put(MediaStore.Images.Media.DATE_MODIFIED, taken / 1000);
            resolver.update(target, done, null, null);

            JSObject result = new JSObject();
            result.put("uri", target.toString());
            call.resolve(result);
        } catch (Exception e) {
            if (target != null) {
                try {
                    resolver.delete(target, null, null);
                } catch (Exception ignored) {
                    // nothing else to do
                }
            }
            call.reject(e.getMessage() == null ? "save failed" : e.getMessage());
        }
    }
}
`;

const pickerJava = (pkg) => `package ${pkg};

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Lets the user pick MANY PDF files at once with the system file picker (ACTION_OPEN_DOCUMENT + ALLOW_MULTIPLE).
 *  - pick():    opens the picker, returns the list of chosen files (uri, name, size). Nothing is copied yet.
 *  - copy():    copies ONE chosen file into the app cache and returns its path (so a big batch never fills the storage at once).
 *  - release(): deletes that cache copy.
 */
@CapacitorPlugin(name = "PdfPicker")
public class PdfPickerPlugin extends Plugin {

    private File cacheDir() {
        File dir = new File(getContext().getCacheDir(), "picked");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    @PluginMethod
    public void pick(PluginCall call) {
        // Remove leftovers of earlier imports (older than 10 minutes).
        try {
            File[] old = cacheDir().listFiles();
            if (old != null) {
                long limit = System.currentTimeMillis() - 10 * 60 * 1000L;
                for (File f : old) {
                    if (f.lastModified() < limit) f.delete();
                }
            }
        } catch (Exception ignored) {
            // not important
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(call, intent, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSArray files = new JSArray();
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Intent data = result.getData();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri u = clip.getItemAt(i).getUri();
                    if (u != null) files.put(describe(u));
                }
            } else if (data.getData() != null) {
                files.put(describe(data.getData()));
            }
        }
        JSObject ret = new JSObject();
        ret.put("files", files);
        call.resolve(ret);
    }

    private JSObject describe(Uri uri) {
        String name = "document.pdf";
        long size = 0;
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Exception ignored) {
            // keep the defaults
        } finally {
            if (c != null) c.close();
        }
        JSObject o = new JSObject();
        o.put("uri", uri.toString());
        o.put("name", name);
        o.put("size", size);
        return o;
    }

    @PluginMethod
    public void copy(PluginCall call) {
        String uri = call.getString("uri");
        if (uri == null) {
            call.reject("uri is required");
            return;
        }
        File out = new File(cacheDir(), System.nanoTime() + ".pdf");
        try {
            InputStream in = getContext().getContentResolver().openInputStream(Uri.parse(uri));
            if (in == null) {
                call.reject("could not open the file");
                return;
            }
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) > 0) {
                    os.write(buffer, 0, read);
                }
                os.flush();
            } finally {
                in.close();
                os.close();
            }
            JSObject ret = new JSObject();
            ret.put("path", out.getAbsolutePath());
            call.resolve(ret);
        } catch (Exception e) {
            out.delete();
            call.reject(e.getMessage() == null ? "copy failed" : e.getMessage());
        }
    }

    @PluginMethod
    public void release(PluginCall call) {
        try {
            String path = call.getString("path");
            if (path != null) {
                File f = new File(path);
                // only ever delete our own temporary copies
                if (f.getCanonicalPath().startsWith(cacheDir().getCanonicalPath() + File.separator)) f.delete();
            }
        } catch (Exception ignored) {
            // not important
        }
        call.resolve();
    }
}
`;

const mainJava = (pkg) => `package ${pkg};

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(GallerySaverPlugin.class);
        registerPlugin(PdfPickerPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`;

function patchGallery() {
  const main = findFile(javaRoot, 'MainActivity.java');
  if (!main) return console.warn('[patch-android] MainActivity.java not found, gallery plugin skipped');
  const m = readFileSync(main, 'utf8').match(/package\s+([\w.]+)\s*;/);
  if (!m) return console.warn('[patch-android] package name not found, gallery plugin skipped');
  const pkg = m[1];
  const dir = main.slice(0, main.lastIndexOf('MainActivity.java'));
  writeFileSync(join(dir, 'GallerySaverPlugin.java'), pluginJava(pkg));
  writeFileSync(join(dir, 'PdfPickerPlugin.java'), pickerJava(pkg));
  writeFileSync(main, mainJava(pkg));
  console.log('[patch-android] gallery + file picker plugins installed in package ' + pkg);
}

patchSplash();
patchGallery();
