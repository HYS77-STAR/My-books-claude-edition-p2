import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import type { FileRec, FolderRec } from './db';
import { fmtSize } from './pdf';
import { t } from './i18n';
import { Icon, PressButton } from './ui';
import { useSortable } from './sortable';

function Thumb({ blob }: { blob: Blob | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!blob) {
      setUrl(null);
      return;
    }
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  return url ? <img src={url} alt="" draggable={false} /> : <div className="ph"><Icon n="file" size={28} /></div>;
}

const meta = (f: FileRec) => [f.encrypted ? t('protectedLabel') : f.pages ? t('nPages', { n: f.pages }) : '', fmtSize(f.size)].filter(Boolean).join(' · ');

interface GridProps {
  files: FileRec[];
  view: 'grid' | 'list';
  cols: number;
  sel: Set<string> | null;
  onTap: (f: FileRec) => void;
  onLong: (f: FileRec) => void;
  onMenu: (f: FileRec) => void;
  onReorder: (ids: string[]) => void;
}

function Check({ on }: { on: boolean }) {
  return <div className={'chk' + (on ? ' on' : '')}>{on && <Icon n="check" size={14} sw={3} />}</div>;
}

function FileCard({ f, i, sel, dragging, onTap, onMenu }: { f: FileRec; i: number; sel: Set<string> | null; dragging: boolean; onTap: () => void; onMenu: () => void }) {
  const d = Math.min(i, 10) * 0.025;
  return (
    <motion.div
      layout
      data-id={f.id}
      className={'card' + (dragging ? ' dragging' : '')}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      whileTap={{ scale: 0.96 }}
      transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: d }, scale: { type: 'spring', stiffness: 400, damping: 28, delay: d } }}
      onClick={onTap}
    >
      <div className={'thumb' + (sel?.has(f.id) ? ' picked' : '')}>
        <Thumb blob={f.thumb} />
        {sel && <Check on={sel.has(f.id)} />}
        {!sel && (
          <button className="more" aria-label="Menu" onClick={(e) => { e.stopPropagation(); onMenu(); }} onPointerDown={(e) => e.stopPropagation()}>
            <Icon n="more" size={20} sw={3.5} />
          </button>
        )}
      </div>
      <div className="cname">{f.name}</div>
      <div className="cmeta">{meta(f)}</div>
    </motion.div>
  );
}

function FileRow({ f, i, sel, dragging, onTap, onMenu }: { f: FileRec; i: number; sel: Set<string> | null; dragging: boolean; onTap: () => void; onMenu: () => void }) {
  return (
    <motion.div
      layout
      data-id={f.id}
      className={'row' + (sel?.has(f.id) ? ' picked' : '') + (dragging ? ' dragging' : '')}
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 40, height: 0 }}
      whileTap={{ scale: 0.98 }}
      transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: Math.min(i, 10) * 0.025 } }}
      onClick={onTap}
    >
      <div className="rthumb"><Thumb blob={f.thumb} /></div>
      <div className="rtext">
        <div className="cname">{f.name}</div>
        <div className="cmeta">{meta(f)}</div>
      </div>
      {sel ? <Check on={sel.has(f.id)} /> : (
        <PressButton className="ib" aria-label="Menu" onClick={(e) => { e.stopPropagation(); onMenu(); }} onPointerDown={(e) => e.stopPropagation()}>
          <Icon n="more" size={22} sw={3.5} />
        </PressButton>
      )}
    </motion.div>
  );
}

export function FileGrid({ files, view, cols, sel, onTap, onLong, onMenu, onReorder }: GridProps) {
  const ids = useMemo(() => files.map((f) => f.id), [files]);
  const byId = useMemo(() => new Map(files.map((f) => [f.id, f] as const)), [files]);
  const { ref, order, dragId } = useSortable<HTMLDivElement>({
    ids,
    onReorder,
    onPick: (id) => {
      const f = byId.get(id);
      if (f) onLong(f);
    },
    version: view + cols,
  });
  // While dragging, the cards are shown in the order the drag is heading to; the others slide out of the way.
  const shown = order ? order.map((id) => byId.get(id)).filter((f): f is FileRec => !!f) : files;

  if (view === 'list') {
    return (
      <div className="list" ref={ref}>
        <AnimatePresence initial={false}>
          {shown.map((f, i) => <FileRow key={f.id} f={f} i={i} sel={sel} dragging={dragId === f.id} onTap={() => onTap(f)} onMenu={() => onMenu(f)} />)}
        </AnimatePresence>
      </div>
    );
  }
  return (
    <div className="grid" ref={ref} data-cols={cols} style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gap: cols >= 6 ? 8 : 14 }}>
      <AnimatePresence initial={false}>
        {shown.map((f, i) => <FileCard key={f.id} f={f} i={i} sel={sel} dragging={dragId === f.id} onTap={() => onTap(f)} onMenu={() => onMenu(f)} />)}
      </AnimatePresence>
    </div>
  );
}

export function FolderList({ folders, counts, onOpen, onReorder }: { folders: FolderRec[]; counts: Record<string, number>; onOpen: (f: FolderRec) => void; onReorder: (ids: string[]) => void }) {
  const ids = useMemo(() => folders.map((f) => f.id), [folders]);
  const byId = useMemo(() => new Map(folders.map((f) => [f.id, f] as const)), [folders]);
  const { ref, order, dragId } = useSortable<HTMLDivElement>({ ids, onReorder, version: 'folders' });
  const shown = order ? order.map((id) => byId.get(id)).filter((f): f is FolderRec => !!f) : folders;
  return (
    <div className="list" ref={ref}>
      <AnimatePresence initial={false}>
        {shown.map((f, i) => (
          <motion.div
            layout
            key={f.id}
            data-id={f.id}
            className={'row' + (dragId === f.id ? ' dragging' : '')}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40, height: 0 }}
            whileTap={{ scale: 0.98 }}
            transition={{ layout: { type: 'spring', stiffness: 420, damping: 36 }, opacity: { delay: Math.min(i, 10) * 0.025 } }}
            onClick={() => onOpen(f)}
          >
            <div className="fico"><Icon n="folder" size={26} /></div>
            <div className="rtext">
              <div className="cname">{f.name}</div>
              <div className="cmeta">{t('nBooks', { n: counts[f.id] || 0 })}</div>
            </div>
            <Icon n="open" size={20} />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
