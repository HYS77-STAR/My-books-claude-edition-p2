import { Capacitor, registerPlugin } from '@capacitor/core';

// A tiny native plugin (added to the Android project by scripts/patch-android.mjs).
// The web <input type="file" multiple> of some file apps only lets you tick ONE file, so on the phone
// we open the system picker ourselves with "allow multiple" switched on.
interface PdfPickerPlugin {
  pick(): Promise<{ files: { uri: string; name: string; size: number }[] }>;
  copy(o: { uri: string }): Promise<{ path: string }>;
  release(o: { path: string }): Promise<void>;
}
const PdfPicker = registerPlugin<PdfPickerPlugin>('PdfPicker');

/** A chosen PDF. Its bytes are only read when `load()` is called, one file at a time. */
export type Picked = { name: string; size: number; load: () => Promise<File> };

/**
 * Opens the system picker and lets the user choose many PDFs at once.
 * Returns [] if the user cancelled, or null when the native picker is not available
 * (then the caller falls back to the normal web file input).
 */
export async function pickPdfs(): Promise<Picked[] | null> {
  if (!Capacitor.isNativePlatform()) return null;
  let res: { files: { uri: string; name: string; size: number }[] };
  try {
    res = await PdfPicker.pick();
  } catch {
    return null;
  }
  return (res.files || []).map((f) => ({
    name: f.name,
    size: f.size,
    load: async () => {
      const { path } = await PdfPicker.copy({ uri: f.uri });
      try {
        const r = await fetch(Capacitor.convertFileSrc(path));
        if (!r.ok) throw new Error('read');
        const blob = await r.blob();
        return new File([blob], f.name, { type: 'application/pdf' });
      } finally {
        PdfPicker.release({ path }).catch(() => {});
      }
    },
  }));
}
