import { useEffect, useRef, useState } from 'react';

/**
 * Drag-and-drop ordering for a grid or a list.
 *
 *  - Press and hold an item (about 0.4 s), then drag it. The item "lifts" (a floating copy follows the finger),
 *    the others slide out of the way with a spring animation, and when you let go the copy glides into its new place.
 *  - Moving the finger BEFORE the hold is over just scrolls the page as usual.
 *  - Near the top/bottom edge the page scrolls by itself.
 *  - The new order is handed to `onReorder` (the caller saves it).
 *
 * The container element needs `ref`, and every draggable child needs a `data-id` attribute.
 */

let sortingUntil = 0;
/** True while something is being dragged (and for a moment afterwards), so other gestures (tab swipe) stay quiet. */
export const isSorting = () => Date.now() < sortingUntil;

const HOLD_MS = 420;
const SLOP = 10; // finger travel (px) that turns the press into a normal scroll
const EDGE = 84; // distance from the top/bottom edge where auto-scroll starts
const SETTLE_MS = 260;

const moveItem = <X,>(a: X[], from: number, to: number): X[] => {
  const r = a.slice();
  const [x] = r.splice(from, 1);
  r.splice(to, 0, x);
  return r;
};

interface Slot {
  left: number;
  top: number;
  w: number;
  h: number;
}
interface Gesture {
  id: string;
  pid: number;
  el: HTMLElement;
  x0: number;
  y0: number;
  x: number;
  y: number;
  timer: number;
  raf: number;
  armed: boolean;
  done: boolean;
  sc: HTMLElement | null;
  slots: Slot[];
  base: string[];
  from: number;
  cur: number;
  ghost: HTMLElement | null;
  w: number;
  h: number;
  grabX: number;
  grabY: number;
}

export function useSortable<T extends HTMLElement>(opts: { ids: string[]; onReorder: (ids: string[]) => void; onPick?: (id: string) => void; version: string }) {
  const ref = useRef<T>(null);
  const [order, setOrder] = useState<string[] | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const latest = useRef(opts);
  latest.current = opts;

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    let g: Gesture | null = null;
    let blockClick = false;
    let unblock = 0;

    const preventTouchScroll = (e: TouchEvent) => {
      if (e.cancelable) e.preventDefault();
    };

    const detach = () => {
      window.removeEventListener('pointermove', onMove, true);
      window.removeEventListener('pointerup', onUp, true);
      window.removeEventListener('pointercancel', onCancel, true);
      window.removeEventListener('touchmove', preventTouchScroll);
    };

    const abort = () => {
      if (!g) return;
      clearTimeout(g.timer);
      cancelAnimationFrame(g.raf);
      g.ghost?.remove();
      detach();
      if (g.armed) {
        setOrder(null);
        setDragId(null);
        sortingUntil = Date.now() + 300;
      }
      g = null;
    };

    // ---------------------------------------------------------------- pick up
    const arm = () => {
      const s = g;
      if (!s || s.armed || s.done) return;
      const els: HTMLElement[] = Array.from<HTMLElement>(root.querySelectorAll<HTMLElement>('[data-id]'));
      const base = els.map((e) => e.dataset.id as string);
      const from = base.indexOf(s.id);
      if (from < 0) return abort();
      s.armed = true;
      blockClick = true;
      sortingUntil = Infinity;
      const sc = root.closest<HTMLElement>('.pane');
      const sr = sc ? sc.getBoundingClientRect() : { left: 0, top: 0 };
      s.sc = sc;
      // The slots are measured once. Every card has the same size, so slot i is always the same place on screen.
      s.slots = els.map((e) => {
        const r = e.getBoundingClientRect();
        return { left: r.left - sr.left + (sc?.scrollLeft ?? 0), top: r.top - sr.top + (sc?.scrollTop ?? 0), w: r.width, h: r.height };
      });
      s.base = base;
      s.from = from;
      s.cur = from;

      // Size of the floating copy and where the finger holds it.
      const r = s.el.getBoundingClientRect();
      s.w = s.el.offsetWidth || r.width;
      s.h = s.el.offsetHeight || r.height;
      s.grabX = s.x - (r.left + r.width / 2 - s.w / 2);
      s.grabY = s.y - (r.top + r.height / 2 - s.h / 2);

      window.addEventListener('touchmove', preventTouchScroll, { passive: false });
      setDragId(s.id);
      latest.current.onPick?.(s.id);
      s.raf = requestAnimationFrame(tick);
      // One frame later (after the card shows its new "selected" state) the floating copy is made from it.
      requestAnimationFrame(() => {
        if (g === s && !s.done) buildGhost(s);
      });
    };

    const buildGhost = (s: Gesture) => {
      const ghost = document.createElement('div');
      ghost.className = 'dragghost ' + (root.classList.contains('grid') ? 'grid' : 'list');
      const cols = root.getAttribute('data-cols');
      if (cols) ghost.setAttribute('data-cols', cols);
      ghost.style.width = s.w + 'px';
      ghost.style.height = s.h + 'px';
      ghost.style.transform = `translate3d(${s.x - s.grabX}px, ${s.y - s.grabY}px, 0)`;
      const clone = s.el.cloneNode(true) as HTMLElement;
      clone.removeAttribute('data-id');
      clone.removeAttribute('style');
      clone.classList.remove('dragging');
      ghost.appendChild(clone);
      document.body.appendChild(ghost);
      s.ghost = ghost;
      requestAnimationFrame(() => ghost.classList.add('lift'));
    };

    // ---------------------------------------------------------------- while dragging
    const tick = () => {
      const s = g;
      if (!s || !s.armed || s.done) return;
      if (s.ghost) s.ghost.style.transform = `translate3d(${s.x - s.grabX}px, ${s.y - s.grabY}px, 0)`;

      const sc = s.sc;
      const sr = sc ? sc.getBoundingClientRect() : { left: 0, top: 0, bottom: window.innerHeight };
      if (sc) {
        let v = 0;
        if (s.y < sr.top + EDGE) v = -(1 - Math.max(0, s.y - sr.top) / EDGE);
        else if (s.y > sr.bottom - EDGE) v = 1 - Math.max(0, sr.bottom - s.y) / EDGE;
        if (v) sc.scrollTop += v * 16;
      }

      // Which slot is the finger over?
      const px = s.x - sr.left + (sc?.scrollLeft ?? 0);
      const py = s.y - sr.top + (sc?.scrollTop ?? 0);
      let best = s.cur;
      let bd = Infinity;
      for (let i = 0; i < s.slots.length; i++) {
        const sl = s.slots[i];
        const d = (px - (sl.left + sl.w / 2)) ** 2 + (py - (sl.top + sl.h / 2)) ** 2;
        if (d < bd) {
          bd = d;
          best = i;
        }
      }
      if (best !== s.cur) {
        s.cur = best;
        setOrder(moveItem(s.base, s.from, best));
      }
      s.raf = requestAnimationFrame(tick);
    };

    // ---------------------------------------------------------------- drop
    const finish = (cancelled: boolean) => {
      const s = g;
      if (!s) return;
      clearTimeout(s.timer);
      detach();
      if (!s.armed) {
        g = null;
        return;
      }
      cancelAnimationFrame(s.raf);
      s.done = true;
      const target = cancelled ? s.from : s.cur;
      const sl = s.slots[target];
      const sc = s.sc;
      const sr = sc ? sc.getBoundingClientRect() : { left: 0, top: 0 };
      const tx = sl.left - (sc?.scrollLeft ?? 0) + sr.left;
      const ty = sl.top - (sc?.scrollTop ?? 0) + sr.top;
      const ghost = s.ghost;
      if (ghost) {
        ghost.classList.remove('lift');
        ghost.classList.add('drop');
        ghost.style.transform = `translate3d(${tx}px, ${ty}px, 0)`;
      }
      const next = moveItem(s.base, s.from, target);
      if (!cancelled && target !== s.from) latest.current.onReorder(next);
      setOrder(cancelled ? s.base : next);
      window.setTimeout(() => {
        ghost?.remove();
        setDragId(null);
        setOrder(null);
        sortingUntil = Date.now() + 400;
        if (g === s) g = null;
      }, SETTLE_MS);
      clearTimeout(unblock);
      unblock = window.setTimeout(() => (blockClick = false), 500);
    };

    function onMove(e: PointerEvent) {
      const s = g;
      if (!s || e.pointerId !== s.pid) return;
      s.x = e.clientX;
      s.y = e.clientY;
      if (!s.armed && Math.hypot(s.x - s.x0, s.y - s.y0) > SLOP) abort(); // the finger moved first: it is a normal scroll
    }
    function onUp() {
      finish(false);
    }
    function onCancel() {
      if (g?.armed) finish(true);
      else abort();
    }

    // ---------------------------------------------------------------- press
    const onDown = (e: PointerEvent) => {
      if (g) {
        if (g.done) return; // the last drop is still settling
        abort();
      }
      if (!e.isPrimary || (e.pointerType === 'mouse' && e.button !== 0)) return;
      const target = e.target as HTMLElement;
      if (target.closest('button, a, input, textarea')) return; // e.g. the "more" button of a card
      const el = target.closest<HTMLElement>('[data-id]');
      if (!el || !root.contains(el) || !el.dataset.id) return;
      blockClick = false;
      g = {
        id: el.dataset.id,
        pid: e.pointerId,
        el,
        x0: e.clientX,
        y0: e.clientY,
        x: e.clientX,
        y: e.clientY,
        timer: window.setTimeout(arm, HOLD_MS),
        raf: 0,
        armed: false,
        done: false,
        sc: null,
        slots: [],
        base: [],
        from: 0,
        cur: 0,
        ghost: null,
        w: 0,
        h: 0,
        grabX: 0,
        grabY: 0,
      };
      window.addEventListener('pointermove', onMove, true);
      window.addEventListener('pointerup', onUp, true);
      window.addEventListener('pointercancel', onCancel, true);
    };

    // A drop (or a long press) must never count as a tap that opens a book.
    const onClickCapture = (e: MouseEvent) => {
      if (blockClick) {
        e.stopPropagation();
        e.preventDefault();
      }
    };
    const onContext = (e: Event) => e.preventDefault();

    root.addEventListener('pointerdown', onDown);
    root.addEventListener('click', onClickCapture, true);
    root.addEventListener('contextmenu', onContext);
    return () => {
      root.removeEventListener('pointerdown', onDown);
      root.removeEventListener('click', onClickCapture, true);
      root.removeEventListener('contextmenu', onContext);
      clearTimeout(unblock);
      abort();
    };
  }, [opts.version]);

  return { ref, order, dragId };
}
