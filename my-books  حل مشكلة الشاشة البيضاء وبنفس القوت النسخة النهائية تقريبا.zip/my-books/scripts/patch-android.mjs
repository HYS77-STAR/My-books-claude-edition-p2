// Runs automatically after `npx cap sync android` (see "capacitor:sync:after" in package.json).
// Android 12+ always shows a system splash (launcher icon on a light background) BEFORE the app
// starts. This makes that screen pure black with no icon, so it flows straight into the app's own
// black animated splash. Safe to run many times.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';

const res = 'android/app/src/main/res';
if (!existsSync(res)) {
  console.log('[patch-android] no android project yet, nothing to do');
  process.exit(0);
}

// 1) a fully transparent "icon" for the system splash
mkdirSync(`${res}/drawable`, { recursive: true });
writeFileSync(
  `${res}/drawable/splash_empty.xml`,
  `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path android:fillColor="#00000000" android:pathData="M0,0h24v24h-24z" />
</vector>
`,
);

// 2) black background + the empty icon, on the launch theme
const file = `${res}/values/styles.xml`;
if (!existsSync(file)) {
  console.warn('[patch-android] styles.xml not found, skipped');
  process.exit(0);
}
let xml = readFileSync(file, 'utf8');
if (xml.includes('windowSplashScreenBackground')) {
  console.log('[patch-android] already patched');
  process.exit(0);
}
const open = /(<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*>)/;
if (!open.test(xml)) {
  console.warn('[patch-android] launch theme not found, skipped');
  process.exit(0);
}
xml = xml.replace(
  open,
  `$1
        <item name="windowSplashScreenBackground">#000000</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/splash_empty</item>
        <item name="windowSplashScreenIconBackgroundColor">#000000</item>`,
);
writeFileSync(file, xml);
console.log('[patch-android] system splash is now black');
